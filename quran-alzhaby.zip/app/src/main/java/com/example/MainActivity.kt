package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import com.example.ui.screens.MainQuranScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.QuranViewModel
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.messaging.FirebaseMessaging
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    private lateinit var viewModel: QuranViewModel
    private lateinit var firebaseAnalytics: FirebaseAnalytics

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // 1. Initialize ViewModel
        viewModel = ViewModelProvider(this)[QuranViewModel::class.java]

        // 2. Initialize Firebase Analytics
        firebaseAnalytics = FirebaseAnalytics.getInstance(this)
        val bundle = Bundle().apply {
            putString(FirebaseAnalytics.Param.ITEM_ID, "app_start")
            putString(FirebaseAnalytics.Param.ITEM_NAME, "MainActivity Open")
        }
        firebaseAnalytics.logEvent(FirebaseAnalytics.Event.APP_OPEN, bundle)

        // 3. Subscribe to global FCM topic
        FirebaseMessaging.getInstance().subscribeToTopic("all")
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    Log.d("MainActivity", "Subscribed to global FCM topic successfully")
                } else {
                    Log.e("MainActivity", "Failed to subscribe to FCM topic", task.exception)
                }
            }

        // 4. Request Post Notification Permission dynamically for Android 13+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
            }
        }

        // 5. Register real-time in-app notification receiver
        MyFirebaseMessagingService.onNotificationReceived = { title, body, url ->
            viewModel.saveNotification(title, body, url)
        }

        // 6. Handle Intent from Notification Click (if launched from a notification)
        handleIntent(intent, viewModel)

        setContent {
            val isDarkTheme by viewModel.isDarkTheme.collectAsState()
            val showInAppNotification by viewModel.showInAppNotification.collectAsState()
            val latestTitle by viewModel.latestNotificationTitle.collectAsState()
            val latestBody by viewModel.latestNotificationBody.collectAsState()
            val latestUrl by viewModel.latestNotificationUrl.collectAsState()

            MyApplicationTheme(darkTheme = isDarkTheme) {
                Box(modifier = Modifier.fillMaxSize()) {
                    Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                        MainQuranScreen(
                            viewModel = viewModel,
                            modifier = Modifier.padding(innerPadding)
                        )
                    }

                    if (showInAppNotification && !latestTitle.isNullOrBlank()) {
                        SwipeableNotificationBanner(
                            title = latestTitle ?: "",
                            body = latestBody ?: "",
                            url = latestUrl,
                            isDark = isDarkTheme,
                            onDismiss = { viewModel.dismissInAppNotification() }
                        )
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent, viewModel)
    }

    private fun handleIntent(intent: Intent?, viewModel: QuranViewModel) {
        val title = intent?.getStringExtra("title")
        val body = intent?.getStringExtra("body")
        val url = intent?.getStringExtra("url") ?: intent?.getStringExtra("link") ?: intent?.getStringExtra("uri")

        Log.d("MainActivity", "Received Intent URL: $url, Title: $title, Body: $body")

        if (!title.isNullOrBlank() || !body.isNullOrBlank() || !url.isNullOrBlank()) {
            viewModel.saveNotification(title, body, url)
        }

        if (!url.isNullOrBlank()) {
            try {
                val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                startActivity(browserIntent)
            } catch (e: Exception) {
                Log.e("MainActivity", "Failed to open notification URL: $url", e)
            }
        }
    }
}

@Composable
fun SwipeableNotificationBanner(
    title: String,
    body: String,
    url: String?,
    isDark: Boolean,
    onDismiss: () -> Unit
) {
    var offsetX by remember { mutableStateOf(0f) }
    var width by remember { mutableStateOf(0) }
    val animatedOffsetX by animateFloatAsState(targetValue = offsetX, label = "offset")

    val maxDragDistance = 400f
    val alpha = (1f - (kotlin.math.abs(animatedOffsetX) / maxDragDistance)).coerceIn(0f, 1f)

    if (kotlin.math.abs(offsetX) > maxDragDistance) {
        LaunchedEffect(Unit) {
            onDismiss()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(16.dp)
            .onSizeChanged { width = it.width }
            .offset { IntOffset(animatedOffsetX.roundToInt(), 0) }
            .alpha(alpha)
            .pointerInput(Unit) {
                detectDragGestures(
                    onDrag = { change, dragAmount ->
                        change.consume()
                        offsetX += dragAmount.x
                    },
                    onDragEnd = {
                        if (kotlin.math.abs(offsetX) > width * 0.4f) {
                            onDismiss()
                        } else {
                            offsetX = 0f
                        }
                    },
                    onDragCancel = {
                        offsetX = 0f
                    }
                )
            }
    ) {
        val goldPrimary = if (isDark) Color(0xFFD4AF37) else Color(0xFF900C3F)
        val containerColor = if (isDark) Color(0xFF1A1A1A) else Color(0xFFFFFFFF)
        val textSecondary = if (isDark) Color.LightGray else Color.DarkGray
        val context = LocalContext.current

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(8.dp, RoundedCornerShape(12.dp)),
            colors = CardDefaults.cardColors(containerColor = containerColor),
            border = BorderStroke(1.5.dp, goldPrimary.copy(alpha = 0.8f)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        if (!url.isNullOrBlank()) {
                            try {
                                val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                context.startActivity(browserIntent)
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }
                        }
                        onDismiss()
                    }
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Notifications,
                    contentDescription = null,
                    tint = goldPrimary,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = goldPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = body,
                        fontSize = 12.sp,
                        color = textSecondary,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(onClick = onDismiss) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "إغلاق",
                        tint = textSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}
