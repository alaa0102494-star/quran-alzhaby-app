package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import com.example.data.api.ApiTranslationResource
import com.example.data.db.ChapterEntity
import com.example.data.db.BookmarkEntity
import com.example.data.db.TafsirEntity
import com.example.data.db.VerseEntity
import com.example.data.db.WordMeaning
import com.example.ui.theme.*
import com.example.ui.viewmodel.QuranViewModel
import androidx.compose.ui.platform.LocalContext
import android.content.Intent
import android.net.Uri
import com.example.ui.viewmodel.recitersList
import androidx.compose.animation.core.*

// 1. Holy Names Color replacements
fun stripPrefixes(word: String): String {
    var w = word
    if (w.startsWith("وبال")) w = w.substring(4)
    else if (w.startsWith("فبال")) w = w.substring(4)
    else if (w.startsWith("بال")) w = w.substring(3)
    else if (w.startsWith("وال")) w = w.substring(3)
    else if (w.startsWith("فال")) w = w.substring(3)
    else if (w.startsWith("لل")) w = w.substring(2)
    else if (w.startsWith("ال")) w = w.substring(2)
    else if (w.startsWith("و") && w.length > 3) w = w.substring(1)
    else if (w.startsWith("ف") && w.length > 3) w = w.substring(1)
    else if (w.startsWith("ب") && w.length > 3) w = w.substring(1)
    else if (w.startsWith("ل") && w.length > 3) w = w.substring(1)
    return w
}

fun isNameOfAllahWithContext(
    cleanWord: String,
    chapterId: Int?,
    verseNumber: Int?,
    wordIndex: Int?,
    wordsInSentence: List<String>?
): Boolean {
    val normalized = cleanWord.replace("ٱ", "ا")
    if (normalized.isEmpty()) return false

    // Explicitly check for Allah names "الله" or "لله" or "اللهم"
    if (normalized == "الله" || normalized == "لله" || normalized == "اللهم" || 
        normalized == "والله" || normalized == "فالله" || normalized == "بالله" || 
        normalized == "تالله" || normalized == "أبالله" || normalized == "أالله") {
        return true
    }

    // Strip prefixes to get the core root word
    val root = stripPrefixes(normalized)

    val hasAlPrefix = normalized.startsWith("ال") || 
                      normalized.startsWith("لل") || 
                      normalized.startsWith("وال") || 
                      normalized.startsWith("بال") || 
                      normalized.startsWith("فال") || 
                      normalized.startsWith("وبال") || 
                      normalized.startsWith("فبال")

    // 1. Check for "رب" (Lord) variations
    val robRoots = setOf("رب", "ربنا", "ربك", "ربكم", "ربهم", "ربي", "ربى", "به", "ربه")
    if (robRoots.contains(root)) {
        // Exclude Yusuf: 41, 42, 50 where "رب" refers to king/master
        if (chapterId == 12 && (verseNumber == 41 || verseNumber == 42 || verseNumber == 50)) {
            return false
        }
        return true
    }

    // 2. Names of Allah that always refer to Allah (no contextual ambiguity)
    val unconditionalRoots = setOf(
        "رحمن", "قدوس", "مهيمن", "بارئ", "مصور", "وهاب", "رزاق", "فتاح", "قيوم", "صمد"
    )
    if (unconditionalRoots.contains(root)) {
        return true
    }

    // 3. "واحد" / "واحدا"
    if (root == "واحد" || root == "واحدا") {
        if (hasAlPrefix) return true // "الواحد" is always Allah
        // Indefinite: check if preceded or followed by "إله"
        if (wordsInSentence != null && wordIndex != null) {
            val prev = if (wordIndex > 0) wordsInSentence[wordIndex - 1].replace(Regex("[^\\u0621-\\u064A\\u0671]"), "").replace("ٱ", "ا") else ""
            val next = if (wordIndex < wordsInSentence.size - 1) wordsInSentence[wordIndex + 1].replace(Regex("[^\\u0621-\\u064A\\u0671]"), "").replace("ٱ", "ا") else ""
            if (prev == "اله" || prev == "الها" || prev == "الهكم" || next == "اله" || next == "الها" || next == "الهكم") {
                return true
            }
        }
        return false
    }

    // 4. "أحد" / "أحدا"
    if (root == "احد" || root == "احدا") {
        // "قل هو الله أحد" -> Surah 112 Verse 1
        return chapterId == 112 && verseNumber == 1
    }

    // 5. "كبير" / "كبيرا" / "الكبير"
    if (root == "كبير" || root == "كبيرا") {
        if (hasAlPrefix) return true
        // Only refers to Allah in An-Nisa 4:34
        return chapterId == 4 && verseNumber == 34
    }

    // 6. "كريم" / "كريما" / "الكريم"
    if (root == "كريم" || root == "كريما") {
        if (hasAlPrefix) {
            // In the Quran, "الكريم" refers to Allah in 82:6 and 27:40. 
            // In 23:116 ("رب العرش الكريم") it describes the Arsh (Throne).
            return (chapterId == 82 && verseNumber == 6) || (chapterId == 27 && verseNumber == 40)
        }
        return chapterId == 27 && verseNumber == 40
    }

    // 7. "عظيم" / "عظيما" / "العظيم"
    if (root == "عظيم" || root == "عظيما") {
        // Only refers to Allah if it has "ال" prefix
        return hasAlPrefix
    }

    // 8. "رحيم" / "رحيما" / "الرحيم"
    if (root == "رحيم" || root == "رحيما") {
        // Refers to Allah except in 9:128 (Prophet)
        return !(chapterId == 9 && verseNumber == 128)
    }

    // 9. "رؤوف" / "رءوف" / "الرؤوف"
    if (root == "رؤوف" || root == "رءوف") {
        // Refers to Allah except in 9:128 (Prophet)
        return !(chapterId == 9 && verseNumber == 128)
    }

    // 10. "حليم" / "حليما" / "الحليم"
    if (root == "حليم" || root == "حليما") {
        // Refers to Allah except in 11:87 (Shuaib) and 37:101 (Ishmael)
        return !(chapterId == 11 && verseNumber == 87) && !(chapterId == 37 && verseNumber == 101)
    }

    // 11. "عليم" / "عليما" / "العليم"
    if (root == "عليم" || root == "عليما") {
        // Refers to Allah except in:
        // 7:112, 10:79, 26:34, 26:37 (magician)
        // 15:53, 51:28 (Isaac)
        if (chapterId == 7 && verseNumber == 112) return false
        if (chapterId == 10 && verseNumber == 79) return false
        if (chapterId == 26 && verseNumber == 34) return false
        if (chapterId == 26 && verseNumber == 37) return false
        if (chapterId == 15 && verseNumber == 53) return false
        if (chapterId == 51 && verseNumber == 28) return false
        return true
    }

    // 12. "حكيم" / "حكيما" / "الحكيم"
    if (root == "حكيم" || root == "حكيما") {
        // Refers to Allah except when describing Quran/Book/Affair:
        // 3:58, 10:1, 31:2, 36:2, 44:4
        if (chapterId == 3 && verseNumber == 58) return false
        if (chapterId == 10 && verseNumber == 1) return false
        if (chapterId == 31 && verseNumber == 2) return false
        if (chapterId == 36 && verseNumber == 2) return false
        if (chapterId == 44 && verseNumber == 4) return false
        return true
    }

    // 13. "قوي" / "قويا" / "القوي"
    if (root == "قوي" || root == "قويا") {
        // Refers to Allah except in 28:26 (Moses)
        return !(chapterId == 28 && verseNumber == 26)
    }

    // 14. "غني" / "غنيا" / "الغني"
    if (root == "غني" || root == "غنيا") {
        // Refers to Allah except in 4:135 (rich person)
        return !(chapterId == 4 && verseNumber == 135)
    }

    // 15. "حميد" / "حميدا" / "الحميد"
    if (root == "حميد" || root == "حميدا") {
        return true
    }

    // 16. "مجيد" / "مجيدا" / "المجيد"
    if (root == "مجيد" || root == "مجيدا") {
        // Only refers to Allah in 11:73 and 85:15
        return (chapterId == 11 && verseNumber == 73) || (chapterId == 85 && verseNumber == 15)
    }

    // 17. "سلام" / "السلام"
    if (root == "سلام") {
        return hasAlPrefix && chapterId == 59 && verseNumber == 23
    }

    // 18. "مؤمن" / "المؤمن"
    if (root == "مؤمن") {
        return hasAlPrefix && chapterId == 59 && verseNumber == 23
    }

    // 19. "جبار" / "الجبار"
    if (root == "جبار") {
        return hasAlPrefix && chapterId == 59 && verseNumber == 23
    }

    // 20. "متكبر" / "المتكبر"
    if (root == "متكبر") {
        return hasAlPrefix && chapterId == 59 && verseNumber == 23
    }

    // 21. "حق" / "الحق"
    if (root == "حق") {
        if (hasAlPrefix) {
            if (chapterId == 22 && (verseNumber == 6 || verseNumber == 62)) return true
            if (chapterId == 31 && verseNumber == 30) return true
            if (chapterId == 24 && verseNumber == 25) return true
            
            if (wordsInSentence != null && wordIndex != null) {
                val prev = if (wordIndex > 0) wordsInSentence[wordIndex - 1].replace(Regex("[^\\u0621-\\u064A\\u0671]"), "").replace("ٱ", "ا") else ""
                val prevRoot = stripPrefixes(prev)
                val holyPrecursors = setOf("الله", "لله", "رب", "ربكم", "ربنا", "هو", "مولى", "مولاهم", "ملك", "الملك")
                if (holyPrecursors.contains(prev) || holyPrecursors.contains(prevRoot)) {
                    return true
                }
            }
        }
        return false
    }

    // 22. "نور" / "النور"
    if (root == "نور") {
        return chapterId == 24 && verseNumber == 35 && wordIndex == 1
    }

    // 23. Other beautiful names of Allah
    val otherSpecificNames = setOf(
        "ملك", "عزيز", "خالق", "غفار", "قهار", "سميع", "بصير", "حكم", "لطيف", 
        "خبير", "شكور", "علي", "حفيظ", "مقيت", "حسيب", "جليل", "رقيب", "مجيب", "واسع", 
        "حكيم", "ودود", "شهيد", "وكيل", "متين", "ولي", "محيي", "متعال", "تواب", "عفو"
    )
    if (otherSpecificNames.contains(root)) {
        return true
    }

    return false
}

fun isNameOfAllah(cleanWord: String): Boolean {
    return isNameOfAllahWithContext(cleanWord, null, null, null, null)
}

fun buildQuranicText(
    text: String,
    isDarkMode: Boolean,
    chapterId: Int? = null,
    verseNumber: Int? = null,
    wordIndex: Int? = null,
    wordsInSentence: List<String>? = null
): AnnotatedString {
    val builder = AnnotatedString.Builder()
    val words = text.split(" ")
    words.forEachIndexed { index, word ->
        val cleanWord = word.replace(Regex("[^\\u0621-\\u064A\\u0671]"), "")
        val actualIndex = wordIndex ?: index
        val actualSentence = wordsInSentence ?: words
        val isAllahName = isNameOfAllahWithContext(
            cleanWord = cleanWord,
            chapterId = chapterId,
            verseNumber = verseNumber,
            wordIndex = actualIndex,
            wordsInSentence = actualSentence
        )

        if (isAllahName) {
            builder.withStyle(
                SpanStyle(
                    color = if (isDarkMode) Color(0xFF4CAF50) else Color(0xFFE53935),
                    fontWeight = FontWeight.Bold
                )
            ) {
                append(word)
            }
        } else {
            builder.append(word)
        }
        if (index < words.size - 1) {
            builder.append(" ")
        }
    }
    return builder.toAnnotatedString()
}

// 2. Secondary Page showing Tafseer and Nuzul
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TafseerSubScreen(
    chapter: ChapterEntity?,
    verses: List<VerseEntity>,
    tafsirs: List<TafsirEntity>,
    isDark: Boolean,
    onBack: () -> Unit,
    allChapters: List<ChapterEntity> = emptyList(),
    onChapterSelected: (ChapterEntity) -> Unit = {},
    initialVerseNumber: Int? = null
) {
    var searchText by remember { mutableStateOf("") }
    var showSurahIndexInTafseer by remember { mutableStateOf(false) }

    val filteredVerses = remember(verses, searchText) {
        if (searchText.isBlank()) {
            verses
        } else {
            verses.filter { 
                it.textUthmani.contains(searchText, ignoreCase = true) ||
                (tafsirs.find { t -> t.verseKey == it.verseKey }?.tafsirText?.contains(searchText, ignoreCase = true) == true)
            }
        }
    }

    val tafseerListState = rememberLazyListState()

    LaunchedEffect(initialVerseNumber, filteredVerses) {
        if (initialVerseNumber != null && initialVerseNumber > 0) {
            val vIdx = filteredVerses.indexOfFirst { it.verseNumber == initialVerseNumber }
            if (vIdx >= 0) {
                // Since there are 2 static items at the top of the LazyColumn (the title and the search textfield),
                // the item index in LazyColumn is vIdx + 2.
                tafseerListState.scrollToItem(vIdx + 2)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable { showSurahIndexInTafseer = true }
                    ) {
                        Text(
                            text = "التفسير الميسر - ${chapter?.nameArabic ?: ""}", 
                            fontWeight = FontWeight.Bold, 
                            fontSize = 18.sp, 
                            color = if (isDark) DarkGoldPrimary else LightGoldPrimary
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.Default.ArrowDropDown, 
                            contentDescription = "فهرس السور", 
                            tint = if (isDark) DarkGoldPrimary else LightGoldPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع", tint = if (isDark) DarkGoldPrimary else LightGoldPrimary)
                    }
                },
                actions = {
                    IconButton(onClick = { showSurahIndexInTafseer = true }) {
                        Icon(Icons.Default.FormatListNumbered, contentDescription = "فهرس السور", tint = if (isDark) DarkGoldPrimary else LightGoldPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = if (isDark) DarkGoldSurface else LightGoldSurface)
            )
        },
        containerColor = if (isDark) DarkGoldBackground else LightGoldBackground
    ) { padding ->
        LazyColumn(
            state = tafseerListState,
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text(
                    text = "سورة ${chapter?.nameArabic ?: ""} - التفسير الميسر",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isDark) DarkGoldPrimary else LightGoldPrimary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                )
            }

            item {
                OutlinedTextField(
                    value = searchText,
                    onValueChange = { searchText = it },
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                    placeholder = { Text("بحث عن آية أو كلمة أو تفسير...", color = (if (isDark) DarkGoldText else LightGoldText).copy(alpha = 0.5f)) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "بحث", tint = if (isDark) DarkGoldPrimary else LightGoldPrimary) },
                    trailingIcon = {
                        if (searchText.isNotEmpty()) {
                            IconButton(onClick = { searchText = "" }) {
                                Icon(Icons.Default.Close, contentDescription = "مسح", tint = if (isDark) DarkGoldPrimary else LightGoldPrimary)
                            }
                        }
                    },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = if (isDark) DarkGoldPrimary else LightGoldPrimary,
                        unfocusedBorderColor = (if (isDark) DarkGoldPrimary else LightGoldPrimary).copy(alpha = 0.4f),
                        focusedLabelColor = if (isDark) DarkGoldPrimary else LightGoldPrimary,
                        cursorColor = if (isDark) DarkGoldPrimary else LightGoldPrimary,
                        focusedTextColor = if (isDark) DarkGoldText else LightGoldText,
                        unfocusedTextColor = if (isDark) DarkGoldText else LightGoldText
                    ),
                    shape = RoundedCornerShape(12.dp)
                )
            }

            if (filteredVerses.isEmpty()) {
                item {
                    Text(
                        text = "لا توجد نتائج بحث مطابقة لـ \"$searchText\"",
                        modifier = Modifier.fillMaxWidth().padding(top = 24.dp),
                        textAlign = TextAlign.Center,
                        color = (if (isDark) DarkGoldText else LightGoldText).copy(alpha = 0.6f)
                    )
                }
            } else {
                items(filteredVerses) { verse ->
                    val tafsir = tafsirs.find { it.verseKey == verse.verseKey }
                    Card(
                        colors = CardDefaults.cardColors(containerColor = if (isDark) DarkGoldSurface else LightGoldSurface),
                        shape = RoundedCornerShape(12.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "${verse.textUthmani} (${verse.verseNumber})",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (isDark) DarkGoldText else LightGoldText,
                                textAlign = TextAlign.Right,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            
                            // Tafseer Text
                            Text(
                                text = "التفسير الميسر:",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isDark) DarkGoldPrimary else LightGoldPrimary,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Text(
                                text = tafsir?.tafsirText ?: "جاري تحميل التفسير...",
                                fontSize = 15.sp,
                                color = if (isDark) DarkGoldText.copy(alpha = 0.8f) else LightGoldText.copy(alpha = 0.8f),
                                modifier = Modifier.fillMaxWidth()
                            )
                            
                            // Asbab Al-Nuzul
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "سبب النزول ومقاصد الآية:",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = AccentGreen,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Text(
                                text = tafsir?.asbabAlNuzul ?: "جاري تحميل سبب النزول...",
                                fontSize = 15.sp,
                                color = AccentGreen.copy(alpha = 0.9f),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }
        }
    }

    if (showSurahIndexInTafseer && allChapters.isNotEmpty()) {
        SurahIndexDialog(
            chapters = allChapters,
            isDark = isDark,
            onChapterSelected = { ch ->
                onChapterSelected(ch)
                showSurahIndexInTafseer = false
            },
            onClose = { showSurahIndexInTafseer = false }
        )
    }
}

// 3. Audio Player Panel Component
@Composable
fun AudioPlayerPanel(
    viewModel: QuranViewModel,
    selectedChapter: ChapterEntity?,
    isDark: Boolean,
    onChooseReciter: () -> Unit
) {
    val isPlaying by viewModel.isPlaying.collectAsState()
    val progress by viewModel.currentAudioProgress.collectAsState()
    val selectedReciterIdx by viewModel.selectedReciterIndex.collectAsState()
    var showReciterChooser by remember { mutableStateOf(false) }

    val reciter = recitersList.getOrNull(selectedReciterIdx)

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
        color = if (isDark) DarkGoldSurface else LightGoldSurface,
        tonalElevation = 8.dp,
        shadowElevation = 8.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Left: Reciter Choice clicker
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { showReciterChooser = true }
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.RecordVoiceOver, contentDescription = "القارئ", tint = if (isDark) DarkGoldPrimary else LightGoldPrimary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = reciter?.nameArabic ?: "اختر القارئ",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isDark) DarkGoldPrimary else LightGoldPrimary
                    )
                    Icon(Icons.Default.ArrowDropDown, contentDescription = "dropdown", tint = if (isDark) DarkGoldPrimary else LightGoldPrimary)
                }

                // Center/Right Info
                Text(
                    text = "سماع سورة ${selectedChapter?.nameArabic ?: ""}",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isDark) DarkGoldText else LightGoldText
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Progress Slider
            Slider(
                value = progress,
                onValueChange = {},
                colors = SliderDefaults.colors(
                    activeTrackColor = if (isDark) DarkGoldPrimary else LightGoldPrimary,
                    inactiveTrackColor = (if (isDark) DarkGoldPrimary else LightGoldPrimary).copy(alpha = 0.2f),
                    thumbColor = if (isDark) DarkGoldPrimary else LightGoldPrimary
                ),
                modifier = Modifier.fillMaxWidth()
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Prev Surah
                IconButton(onClick = { viewModel.prevSurah() }) {
                    Icon(Icons.Default.SkipPrevious, contentDescription = "السورة السابقة", tint = if (isDark) DarkGoldPrimary else LightGoldPrimary)
                }

                // Rewind 10s
                IconButton(onClick = { viewModel.rewindAudio() }) {
                    Icon(Icons.Default.Replay10, contentDescription = "تأخير 10 ثواني", tint = if (isDark) DarkGoldPrimary else LightGoldPrimary)
                }

                // Play / Pause
                FloatingActionButton(
                    onClick = {
                        if (isPlaying) {
                            viewModel.pauseAudio()
                        } else {
                            selectedChapter?.let { viewModel.playFullSurah(it.id, selectedReciterIdx) }
                        }
                    },
                    containerColor = if (isDark) DarkGoldPrimary else LightGoldPrimary,
                    contentColor = if (isDark) DarkGoldBackground else LightGoldBackground,
                    shape = CircleShape
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = "تشغيل",
                        modifier = Modifier.size(36.dp)
                    )
                }

                // Forward 10s
                IconButton(onClick = { viewModel.forwardAudio() }) {
                    Icon(Icons.Default.Forward10, contentDescription = "تقديم 10 ثواني", tint = if (isDark) DarkGoldPrimary else LightGoldPrimary)
                }

                // Next Surah
                IconButton(onClick = { viewModel.nextSurah() }) {
                    Icon(Icons.Default.SkipNext, contentDescription = "السورة التالية", tint = if (isDark) DarkGoldPrimary else LightGoldPrimary)
                }
            }
        }
    }

    if (showReciterChooser) {
        Dialog(onDismissRequest = { showReciterChooser = false }) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = if (isDark) DarkGoldSurface else LightGoldSurface,
                modifier = Modifier.fillMaxWidth().padding(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "اختر القارئ للمصحف المرتل",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isDark) DarkGoldPrimary else LightGoldPrimary,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )
                    recitersList.forEachIndexed { index, rec ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable {
                                        showReciterChooser = false
                                        selectedChapter?.let { viewModel.playFullSurah(it.id, index) }
                                    }
                                    .padding(vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Person, contentDescription = null, tint = if (isDark) DarkGoldPrimary else LightGoldPrimary)
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = rec.nameArabic,
                                    fontSize = 16.sp,
                                    color = if (isDark) DarkGoldText else LightGoldText
                                )
                            }
                            
                            selectedChapter?.let { chapter ->
                                val downloadKey = "${rec.id}_${chapter.id}"
                                val progressMap = viewModel.audioDownloadProgress.collectAsState().value
                                val downloadedSet = viewModel.downloadedAudios.collectAsState().value
                                val isDownloaded = downloadedSet.contains(downloadKey)
                                val currentProgress = progressMap[downloadKey]

                                if (currentProgress != null) {
                                    Box(modifier = Modifier.size(36.dp), contentAlignment = Alignment.Center) {
                                        CircularProgressIndicator(
                                            progress = currentProgress,
                                            color = if (isDark) DarkGoldPrimary else LightGoldPrimary,
                                            strokeWidth = 2.dp,
                                            modifier = Modifier.size(24.dp)
                                        )
                                    }
                                } else if (isDownloaded) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = "تم التحميل",
                                        tint = AccentGreen,
                                        modifier = Modifier.padding(8.dp).size(20.dp)
                                    )
                                } else {
                                    IconButton(
                                        onClick = {
                                            viewModel.downloadAudioForSurah(rec.id, chapter.id)
                                        }
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Download,
                                            contentDescription = "تحميل التلاوة",
                                            tint = if (isDark) DarkGoldPrimary else LightGoldPrimary,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// 4. Page Header controls line
@Composable
fun PageHeaderControl(
    chapter: ChapterEntity?,
    activeTranslationId: Int?,
    isDark: Boolean,
    onTranslationClick: () -> Unit,
    onBookmarkPage: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = (if (isDark) DarkGoldSurface else LightGoldSurface).copy(alpha = 0.5f)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Left: Chapter name
            Text(
                text = "سُورَةُ ${chapter?.nameArabic ?: ""}",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = if (isDark) DarkGoldPrimary else LightGoldPrimary
            )

            // Right: Bookmark Page flag
            IconButton(onClick = onBookmarkPage) {
                Icon(
                    imageVector = Icons.Default.BookmarkBorder,
                    contentDescription = "حفظ علامة توقف",
                    tint = if (isDark) DarkGoldPrimary else LightGoldPrimary
                )
            }
        }
    }
}

// 5. Verse Card presenting Uthmani text, contrasted index, click actions and translations
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun VerseCardItem(
    verse: VerseEntity,
    translationText: String?,
    textSize: Float,
    isDark: Boolean,
    isHighlighted: Boolean,
    textColor: Color,
    onVerseClick: () -> Unit,
    onWordClick: (WordMeaning) -> Unit,
    onLongPressVerse: () -> Unit,
    viewModel: QuranViewModel
) {
    val wordMeanings = remember(verse) {
        viewModel.parseWordMeanings(verse.wordMeaningsJson)
            .filter { word ->
                // Filter out word if it represents the verse number symbol/number (it is numeric/punctuated)
                val cleaned = word.textUthmani.replace(Regex("[0-9\\u0660-\\u0669\\u06F0-\\u06F9\\uFD3E\\uFD3F\\s\\p{Punct}]"), "")
                cleaned.isNotEmpty() && word.textUthmani.trim().isNotEmpty()
            }
    }
    val highlightedWord = viewModel.highlightedWordText.collectAsState().value
    val bookmarksState = viewModel.bookmarks.collectAsState().value
    val isBookmarkedByMe = remember(bookmarksState, verse) {
        bookmarksState.any { it.chapterId == verse.chapterId && it.verseNumber == verse.verseNumber }
    }

    // Borderless transparent background block for a clean printed-page look
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                if (isHighlighted) {
                    (if (isDark) Color(0xFF4CAF50) else Color(0xFFE53935)).copy(alpha = 0.08f)
                } else {
                    Color.Transparent
                }
            )
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { onVerseClick() },
                    onLongPress = { onLongPressVerse() }
                )
            }
            .padding(vertical = 12.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Words Wrap Flow - Right to Left
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Start,
                    verticalArrangement = Arrangement.Center
                ) {
                    if (wordMeanings.isNotEmpty()) {
                        wordMeanings.forEach { word ->
                            val isWordHighlighted = highlightedWord == word.textUthmani
                            Box(
                                modifier = Modifier
                                    .padding(horizontal = 1.dp, vertical = 2.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(
                                        if (isWordHighlighted) {
                                            Color(0xFFFFEB3B).copy(alpha = 0.45f) // Beautiful transparent yellow highlight
                                        } else {
                                            Color.Transparent
                                        }
                                    )
                                    .pointerInput(word) {
                                        detectTapGestures(
                                            onTap = { onVerseClick() }, // Tap triggers the verse click (e.g. play audio in Teacher Mode)
                                            onLongPress = { onWordClick(word) } // Long-press shows the word meaning/synonyms
                                        )
                                    }
                                    .padding(horizontal = 3.dp, vertical = 1.dp)
                            ) {
                                Text(
                                    text = buildQuranicText(
                                        text = word.textUthmani,
                                        isDarkMode = isDark,
                                        chapterId = verse.chapterId,
                                        verseNumber = verse.verseNumber,
                                        wordIndex = wordMeanings.indexOf(word),
                                        wordsInSentence = wordMeanings.map { it.textUthmani }
                                    ),
                                    fontSize = textSize.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = if (isWordHighlighted) {
                                        if (isDark) Color.White else Color.Black
                                    } else {
                                        textColor
                                    },
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    } else {
                        // Fallback whole verse text
                        Text(
                            text = buildQuranicText(
                                text = verse.textUthmani,
                                isDarkMode = isDark,
                                chapterId = verse.chapterId,
                                verseNumber = verse.verseNumber
                            ),
                            fontSize = textSize.sp,
                            fontWeight = FontWeight.Medium,
                            color = textColor,
                            textAlign = TextAlign.Right,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onVerseClick() }
                        )
                    }

                    // Elegant, authentic Mushaf-style verse number icon appended right after the words!
                    // Green in Dark Mode, Red in Light Mode
                    val iconColor = if (isDark) Color(0xFF4CAF50) else Color(0xFFE53935)
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .padding(horizontal = 4.dp, vertical = 2.dp)
                            .size(28.dp)
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val path = androidx.compose.ui.graphics.Path().apply {
                                val radius = size.minDimension / 2f
                                val centerX = size.width / 2f
                                val centerY = size.height / 2f
                                val numPoints = 8
                                val innerRadius = radius * 0.75f
                                val outerRadius = radius
                                for (i in 0 until 2 * numPoints) {
                                    val r = if (i % 2 == 0) outerRadius else innerRadius
                                    val angle = (i * kotlin.math.PI / numPoints).toFloat()
                                    val x = centerX + r * kotlin.math.cos(angle)
                                    val y = centerY + r * kotlin.math.sin(angle)
                                    if (i == 0) moveTo(x, y) else lineTo(x, y)
                                }
                                close()
                            }
                            drawPath(
                                path = path,
                                color = iconColor,
                                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.5.dp.toPx())
                            )
                        }
                        Text(
                            text = verse.verseNumber.toString(),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = iconColor,
                            textAlign = TextAlign.Center
                        )
                    }

                    if (isBookmarkedByMe) {
                        Icon(
                            imageVector = Icons.Default.Bookmark,
                            contentDescription = "علامة توقف",
                            tint = if (isDark) DarkGoldPrimary else LightGoldPrimary,
                            modifier = Modifier
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                                .size(24.dp)
                                .clickable {
                                    viewModel.toggleBookmark(verse.chapterId, verse.verseNumber)
                                }
                        )
                    }
                }
            }

            // Translation subtitle (appears automatically under the verse if active)
            translationText?.let { trans ->
                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = (if (isDark) DarkGoldPrimary else LightGoldPrimary).copy(alpha = 0.1f))
                Spacer(modifier = Modifier.height(6.dp))
                val isArabicTrans = trans.any { it in '\u0600'..'\u06FF' }
                Text(
                    text = trans,
                    fontSize = (textSize - 6).sp,
                    color = if (isDark) Color(0xFF4CAF50) else Color(0xFF1B5E20), // Beautiful distinct green color
                    textAlign = if (isArabicTrans) TextAlign.Right else TextAlign.Left,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                )
            }
        }
    }
}

fun getArabicWordMeaning(englishMeaning: String, wordText: String): String {
    val cleanMeaning = englishMeaning.trim()
    val hasLatin = cleanMeaning.any { it in 'a'..'z' || it in 'A'..'Z' }
    if (!hasLatin) {
        return cleanMeaning
    }

    val cleanEnglish = cleanMeaning.lowercase().replace(Regex("[.,;:?\"']"), "").trim()
    val mapping = mapOf(
        "in the name of" to "بِاسْمِ",
        "allah" to "اللهِ (الْمَعْبُودِ بِحَقٍّ الْجَامِعِ لِصِفَاتِ الْجَلالِ)",
        "the entirely merciful" to "الرَّحْمَنِ (الَّذِي وَسِعَتْ رَحْمَتُهُ كُلَّ شَيْءٍ)",
        "the especially merciful" to "الرَّحِيمِ (الْمُنْعِمِ عَلَى عِبَادِهِ الْمُؤْمِنِينَ بِالْقُرْآنِ وَالْهِدَايَةِ)",
        "all praise" to "الْحَمْدُ (كُلُّ الثَّناءِ الجَميلِ والتَّعْظِيمِ للهِ وحده)",
        "lord" to "رَبِّ (الخالِقِ المالِكِ الـمُرَبِّي الـمُتَصَرِّفِ)",
        "of the worlds" to "العالَمينَ (جَميعِ الـمَخلوقاتِ والـبَشَرِ)",
        "sovereign" to "مالِكِ (صاحِبِ الـمُلْكِ والـتَّصَرُّفِ)",
        "day" to "يَوْمِ",
        "of recompense" to "الدّينِ (الـجَزاءِ والـحِسابِ يَوْمَ القِيامَةِ)",
        "it is you" to "إِيَّاكَ (نَخُصُّكَ أَنْتَ وحْدَكَ بِالعِبادَةِ والتَّعْظِيمِ)",
        "we worship" to "نَعْبُدُ (نَخْضَعُ ونَذِلُّ لَكَ مَحَبَّةً وطاعَةً)",
        "we ask for help" to "نَسْتَعينُ (نَطْلُبُ العَوْنَ والتَّوْفِيقَ مِنْكَ وحْدَكَ)",
        "guide us" to "اهْدِنا (أَرْشِدْنا ووفِّقْنا وثَبِّتْنا)",
        "the path" to "الصِّراطَ (الطَّريقَ الواضِحَ)",
        "straight" to "الـمُسْتَقيمَ (الَّذي لا عِوَجَ فيهِ، وهو الإِسلامُ)",
        "those" to "الَّذينَ",
        "you have bestowed favor" to "أَنْعَمْتَ (تَفَضَّلْتَ عَلَيْهِمْ بِالهِدايَةِ كالنَّبِيِّينَ والصَّالِحينَ)",
        "upon them" to "عَلَيْهِمْ",
        "not" to "غَيْرِ (سِوى طَريقِ)",
        "of those who have earned anger" to "الـمَغْضوبِ عَلَيْهِمْ (الَّذينَ عَرَفوا الـحَقَّ وعانَدوا كاليَهودِ)",
        "of those who are astray" to "الضَّالّينَ (الَّذينَ فَقَدوا العِلْمَ فَضَلّوا كالنَّصارى)",
        "alif lam mim" to "الم (حُروفٌ مُقَطَّعَةٌ لِلإِعْجازِ والتَّحَدِّي)",
        "this" to "ذلِكَ / هذا",
        "book" to "الـكِتابُ (القُرآنُ العَظيمُ)",
        "no doubt" to "لا رَيْبَ (لا شَكَّ فيهِ أَنَّهُ مِنْ عِنْدِ اللهِ)",
        "in it" to "فيهِ",
        "a guidance" to "هُدًى (مُرْشِدٌ ودَليلٌ إلى الـحَقِّ والـجَنَّةِ)",
        "for the God-fearing" to "لِلْمُتَّقينَ (الَّذينَ يَجْتَنِبونَ الـمَعاصي طَمَعاً في المَثوبَةِ)",
        "who" to "الَّذينَ",
        "believe" to "يُؤْمِنونَ (يُصَدِّقونَ تَصْديقاً جازِماً)",
        "in the unseen" to "بِالغَيْبِ (بِكُلِّ ما غابَ عَنِ الـحَواسِّ كالـمَلائِكَةِ والـجَنَّةِ)",
        "and establish" to "ويُقيمونَ",
        "prayer" to "الصَّلاةَ (يُؤَدُّونَها بِأَرْكانِها وخُشوعِها)",
        "and out of what" to "ومِمَّا",
        "we have provided them" to "رَزَقْناهُمْ (ما أَعْطَيْناهُمْ مِنَ الـمالِ والرِّزْقِ)",
        "they spend" to "يُنْفِقونَ (في سَبيلِ اللهِ كالزَّكاةِ والصَّدَقَةِ)",
        "was sent down" to "أُنْزِلَ",
        "to you" to "إِلَيْكَ",
        "before you" to "مِنْ قَبْلِكَ (مِنَ الرُّسُلِ والـكُتُبِ السَّابِقَةِ)",
        "and in the Hereafter" to "obِالآخِرَةِ (دارِ الـجَزاءِ بَعْدَ الـمَوْتِ)",
        "they" to "هُمْ",
        "are certain" to "يوقِنونَ (يُؤْمِنونَ إيماناً ثابِتاً لا شَكَّ فيهِ)",
        "sealed" to "خَتَمَ (طَبَعَ اللهُ على قُلوبِهِمْ فَلَا يَدْخُلُها إيمانٌ)",
        "on their hearts" to "على قُلوبِهِمْ",
        "and on" to "وعلى",
        "their hearing" to "سَمْعِهِمْ",
        "their vision" to "أَبْصارِهِمْ",
        "a veil" to "غِشاوَةٌ (حِجابٌ غَليظٌ عَنِ الـحَقِّ)",
        "and" to "وَ (حَرْفُ عَطْفٍ)",
        "he" to "هُوَ (لِلْمُفْرَدِ الغائِبِ)",
        "they" to "هُمْ (لِلْجَمْعِ الغائِبِ)",
        "she" to "هِيَ",
        "you" to "أَنْتَ / أَنْتُمْ",
        "we" to "نَحْنُ",
        "i" to "أَنَا",
        "from" to "مِنْ (حَرْفُ جَرٍّ)",
        "to" to "إِلَى (حَرْفُ جَرٍّ)",
        "in" to "فِي (حَرْفُ جَرٍّ)",
        "on" to "عَلَى (حَرْفُ جَرٍّ)",
        "with" to "مَعَ / بِـ (حَرْفُ جَرٍّ)",
        "by" to "بِـ / عَنْ (حَرْفُ جَرٍّ)",
        "for" to "لِـ (حَرْفُ جَرٍّ)",
        "indeed" to "إِنَّ (حَرْفُ تَوْكيدٍ ونَصْبٍ)",
        "surely" to "قَدْ / إِنَّ (لِلتَّأْكيدِ والتَّحْقيقِ)",
        "verily" to "حَقًّا / إِنَّ (لِلتَّأْكيدِ والتَّحْقيقِ)",
        "no" to "لا (لِلنَّفْيِ)",
        "nay" to "كَلَّا (حَرْفُ رَدْعٍ وزَجْرٍ)",
        "except" to "إِلَّا (أَداةُ اسْتِثْناءٍ)",
        "but" to "لكِنْ (لِلِاسْتِدْراكِ)",
        "savior" to "مُنْقِذٌ / ناصِرٌ",
        "heavens" to "السَّماواتِ (الـمَخلوقاتِ العُلْوِيَّةِ المَرْفوعَةِ)",
        "heaven" to "السَّماءِ",
        "sky" to "السَّماءِ",
        "earth" to "الأَرْضِ (الـمُمَهَّدَةِ لِلْمَعِيشَةِ)",
        "water" to "الـماءِ (أَصْلِ الـحَياةِ والـمَطَرِ)",
        "fire" to "النَّارِ (عَذابِ جَهَنَّمَ لِلْكافِرينَ)",
        "hellfire" to "نارِ جَهَنَّمَ (مَثْوى الكافِرينَ)",
        "garden" to "الـجَنَّةِ (دارِ النَّعيمِ لِلْمُتَّقينَ)",
        "gardens" to "جَنَّاتِ النَّعيمِ",
        "paradise" to "الفِرْدَوْسِ / الـجَنَّةِ",
        "punishment" to "العَذابِ (العُقوبَةِ العادِلَةِ لِلْعُصاةِ)",
        "chastisement" to "العَذابِ الأَليمِ",
        "torment" to "العَذابِ الشَّديدِ",
        "mercy" to "الرَّحْمَةِ (الـخَيْرِ والإِحْسانِ)",
        "merciful" to "الرَّحيمِ / الرَّحْمنِ",
        "forgiving" to "الغَفورِ (الَّذي يَسْتُرُ الذُّنوبَ ويَعْفو عَنْها)",
        "forgiveness" to "الـمَغْفِرَةِ (العَفْوِ وسَتْرِ الذَّنْبِ)",
        "wise" to "الـحَكيمِ (ذو الـحِكْمَةِ والـتَّدْبيرِ السَّديدِ)",
        "all-knowing" to "العَليمِ (الَّذي يَعْلَمُ السِّرَّ وأَخْفَى)",
        "knowing" to "عالِمٌ / عَليمٌ",
        "knowledge" to "العِلْمِ (الـمَعْرِفَةِ الـحَقَّةِ)",
        "mighty" to "العَزيزِ (الغالِبِ الَّذي لا يُقْهَرُ)",
        "almighty" to "القَديرِ العَزيزِ",
        "praise" to "الـحَمْدِ (الثَّناءِ بِالـجَميلِ على اللهِ)",
        "lord" to "الرَّبِّ (الـخالِقِ والـمُرَبِّي والـسَّيِّدِ)",
        "master" to "الـمَوْلى / السَّيِّدِ",
        "messenger" to "الرَّسولِ (الـمُرْسَلِ بِالوَحْيِ لِهِدايَةِ الناسِ)",
        "religion" to "الدّينِ (الإِسْلامِ وعِبَادَةِ اللهِ وحْدَهُ)",
        "blessing" to "النِّعْمَةِ ورَغَدِ العَيْشِ",
        "favor" to "الفَضْلِ والإحْسانِ",
        "grace" to "الفَضْلِ العَظيمِ والـمِنَّةِ",
        "fear" to "الـخَوْفِ والتَّقْوى والـخَشْيَةِ",
        "hope" to "الرَّجاءِ في رَحْمَةِ اللهِ",
        "love" to "الـمَحَبَّةِ والـوُدِّ لِلَّهِ ولِلْخَيْرِ",
        "good" to "الـخَيْرِ والنَّفْعِ وبِرِّ المَعْروفِ",
        "righteous" to "الصَّالِحِ الـمُطِيعِ لِرَبِّهِ",
        "evil" to "الشَّرِّ والـمَعْصِيَةِ والضَّرَرِ",
        "great" to "العَظيمِ / الكَبيرِ الـقَدْرِ",
        "grand" to "الـجَليلِ العَظيمِ",
        "glory" to "الـجَلالِ والتَّعْظيمِ والتَّسْبيحِ",
        "glorified" to "الـمُنَزَّهِ عَنِ النَّقْصِ",
        "glorify" to "يُسَبِّحُ ويُعَظِّمُ تَنْزيهاً للهِ",
        "praising" to "الـحَمْدِ والشُّكْرِ والـثَّناءِ",
        "remember" to "يَذْكُرُ (يَسْتَحْضِرُ في قَلْبِهِ ولِسانِهِ)",
        "remembrance" to "الذِّكْرِ الـمُنَجِّي مِنَ العَذابِ",
        "supplication" to "الدُّعاءِ والتَّضَرُّعِ",
        "call" to "الدُّعاءِ والنِّداءِ لِلَّهِ وحْدَهُ",
        "prayer" to "الصَّلاةِ الـمَفْروضَةِ",
        "prayers" to "الصَّلَواتِ الـخَمْسِ",
        "charity" to "الزَّكاةِ الـمَفْروضَةِ / الصَّدَقَةِ",
        "fasting" to "الصِّيامِ لِلَّهِ رَبِّ العالَمينَ",
        "pilgrimage" to "الـحَجُّ لِبَيْتِ اللهِ الـحَرامِ",
        "create" to "يَخْلُقُ مِنَ العَدَمِ",
        "created" to "الـمَخلوقِ الـمُوجَدِ",
        "creator" to "الـخالِقِ البارِئِ الـمُصَوِّرِ",
        "all-hearing" to "السَّميعِ (الَّذي يَسْمَعُ السِّرَّ والـنَّجْوى)",
        "all-seeing" to "البَصيرِ (الَّذي لا يَخْفَى عَلَيْهِ شَيْءٌ)",
        "say" to "قُلْ (أَمْرٌ لِلنَّبِيِّ بِالتَّبْليغِ)",
        "he said" to "قَالَ",
        "they said" to "قَالُوا"
    )

    val directMatch = mapping[cleanEnglish]
    if (directMatch != null) return directMatch

    for ((eng, ar) in mapping) {
        if (cleanEnglish == eng || cleanEnglish.contains(eng) || eng.contains(cleanEnglish)) {
            return ar
        }
    }
    return "معنى كلمة (${wordText}): $cleanMeaning"
}

// 6. Word details meanings Dialog Popup
@Composable
fun WordMeaningDialog(
    wordText: String,
    meaning: String,
    isDark: Boolean,
    onClose: () -> Unit
) {
    val arabicMeaning = remember(meaning, wordText) { getArabicWordMeaning(meaning, wordText) }

    Dialog(onDismissRequest = onClose) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (isDark) DarkGoldSurface else LightGoldSurface
            ),
            border = BorderStroke(1.dp, if (isDark) DarkGoldPrimary else LightGoldPrimary),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "معنى الكلمة والتفسير الميسر",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = (if (isDark) DarkGoldPrimary else LightGoldPrimary).copy(alpha = 0.6f),
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(12.dp))
                
                // The Word itself in clean Uthmani
                Text(
                    text = buildQuranicText(wordText, isDark),
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isDark) DarkGoldPrimary else LightGoldPrimary,
                    textAlign = TextAlign.Center
                )
                
                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider(color = (if (isDark) DarkGoldPrimary else LightGoldPrimary).copy(alpha = 0.15f))
                Spacer(modifier = Modifier.height(16.dp))
                
                // The Translation/Meaning in Arabic
                Text(
                    text = arabicMeaning,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium,
                    color = if (isDark) DarkGoldText else LightGoldText,
                    textAlign = TextAlign.Center,
                    lineHeight = 22.sp
                )
                
                Spacer(modifier = Modifier.height(20.dp))
                
                // Elegant close button
                Button(
                    onClick = onClose,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isDark) DarkGoldPrimary else LightGoldPrimary,
                        contentColor = if (isDark) DarkGoldSurface else Color.White
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth(0.6f)
                ) {
                    Text(
                        text = "إغلاق",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

fun getSurahStartPage(surahId: Int): Int {
    val startPages = intArrayOf(
        1, 2, 50, 77, 106, 128, 151, 177, 187, 208,
        221, 235, 249, 255, 262, 267, 282, 293, 305, 312,
        322, 332, 342, 350, 359, 367, 377, 385, 396, 404,
        411, 415, 418, 428, 434, 440, 446, 453, 458, 467,
        477, 483, 489, 496, 499, 502, 507, 511, 515, 518,
        520, 523, 526, 528, 531, 534, 537, 542, 545, 549,
        551, 553, 554, 556, 558, 560, 562, 564, 566, 568,
        570, 572, 574, 575, 577, 578, 580, 582, 583, 585,
        586, 587, 587, 589, 590, 591, 591, 592, 593, 594,
        595, 595, 596, 596, 597, 597, 598, 598, 599, 599,
        600, 600, 601, 601, 601, 602, 602, 602, 603, 603,
        603, 604, 604, 604
    )
    return startPages.getOrNull(surahId - 1) ?: 1
}

fun getSurahStartJuz(surahId: Int): Int {
    val startJuzs = intArrayOf(
        1, 1, 3, 4, 6, 7, 8, 9, 10, 11,
        11, 12, 13, 13, 14, 14, 15, 15, 16, 16,
        17, 17, 18, 18, 18, 19, 19, 20, 20, 21,
        21, 21, 21, 22, 22, 22, 23, 23, 23, 24,
        24, 25, 25, 25, 25, 26, 26, 26, 26, 26,
        26, 27, 27, 27, 27, 27, 27, 28, 28, 28,
        28, 28, 28, 28, 28, 28, 29, 29, 29, 29,
        29, 29, 29, 29, 29, 29, 29, 30, 30, 30,
        30, 30, 30, 30, 30, 30, 30, 30, 30, 30,
        30, 30, 30, 30, 30, 30, 30, 30, 30, 30,
        30, 30, 30, 30, 30, 30, 30, 30, 30, 30,
        30, 30, 30, 30
    )
    return startJuzs.getOrNull(surahId - 1) ?: 1
}

// Dialog Component for Surah selection Index
@Composable
fun SurahIndexDialog(
    chapters: List<ChapterEntity>,
    isDark: Boolean,
    onChapterSelected: (ChapterEntity) -> Unit,
    onClose: () -> Unit
) {
    Dialog(onDismissRequest = onClose) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = if (isDark) DarkGoldSurface else LightGoldSurface,
            border = BorderStroke(1.dp, (if (isDark) DarkGoldPrimary else LightGoldPrimary).copy(alpha = 0.3f)),
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.8f)
                .padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "فهرس السور الكريمة",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isDark) DarkGoldPrimary else LightGoldPrimary,
                    modifier = Modifier.padding(bottom = 16.dp)
                )

                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(chapters) { ch ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { onChapterSelected(ch) }
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "${ch.id}.",
                                    fontSize = 14.sp,
                                    color = if (isDark) DarkGoldPrimary else LightGoldPrimary,
                                    modifier = Modifier.width(28.dp)
                                )
                                Text(
                                    text = ch.nameArabic,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isDark) DarkGoldText else LightGoldText
                                )
                            }
                            Text(
                                text = "${ch.versesCount} آية",
                                fontSize = 13.sp,
                                color = (if (isDark) DarkGoldText else LightGoldText).copy(alpha = 0.6f)
                            )
                        }
                    }
                }
            }
        }
    }
}

// Dialog Component for Juz Index list
data class JuzInfo(val number: Int, val name: String, val startSurahId: Int)

@Composable
fun JuzIndexDialog(
    chapters: List<ChapterEntity>,
    isDark: Boolean,
    onChapterSelected: (ChapterEntity) -> Unit,
    onClose: () -> Unit
) {
    val juzList = remember {
        listOf(
            JuzInfo(1, "الجزء الأول (الفاتحة)", 1),
            JuzInfo(2, "الجزء الثاني (سيقول السفهاء - البقرة آية ١٤٢)", 2),
            JuzInfo(3, "الجزء الثالث (تلك الرسل - البقرة آية ٢٥٣)", 2),
            JuzInfo(4, "الجزء الرابع (لن تنالوا - آل عمران آية ٩٣)", 3),
            JuzInfo(5, "الجزء الخامس (والمحصنات - النساء آية ٢٤)", 4),
            JuzInfo(6, "الجزء السادس (لا يحب الله - النساء آية ١٤٨)", 4),
            JuzInfo(7, "الجزء السابع (وإذا سمعوا - المائدة آية ٨٢)", 5),
            JuzInfo(8, "الجزء الثامن (ولو أننا - الأنعام آية ١١١)", 6),
            JuzInfo(9, "الجزء التاسع (قال الملأ - الأعراف آية ٨٨)", 7),
            JuzInfo(10, "الجزء العاشر (واعلموا - الأنفال آية ٤١)", 8),
            JuzInfo(11, "الجزء الحادي عشر (يعتذرون - التوبة آية ٩٤)", 9),
            JuzInfo(12, "الجزء الثاني عشر (وما من دابة - هود آية ٦)", 11),
            JuzInfo(13, "الجزء الثالث عشر (وما أبرئ نفسي - يوسف آية ٥٣)", 12),
            JuzInfo(14, "الجزء الرابع عشر (ربما - الحجر آية ١)", 15),
            JuzInfo(15, "الجزء الخامس عشر (سبحان الذي - الإسراء آية ١)", 17),
            JuzInfo(16, "الجزء السادس عشر (قال ألم - الكهف آية ٧٥)", 18),
            JuzInfo(17, "الجزء السابع عشر (اقترب للناس - الأنبياء آية ١)", 21),
            JuzInfo(18, "الجزء الثامن عشر (قد أفلح - المؤمنون آية ١)", 23),
            JuzInfo(19, "الجزء التاسع عشر (وقال الذين لا يرجون - الفرقان آية ٢١)", 25),
            JuzInfo(20, "الجزء العشرون (أمن خلق - النمل آية ٦٠)", 27),
            JuzInfo(21, "الجزء الحادي والعشرون (اتل ما أوحي - العنكبوت آية ٤٦)", 29),
            JuzInfo(22, "الجزء الثاني والعشرون (ومن يقنت - الأحزاب آية ٣١)", 33),
            JuzInfo(23, "الجزء الثالث والعشرون (وما لي لا أعبد - يس آية ٢٢)", 36),
            JuzInfo(24, "الجزء الرابع والعشرون (فمن أظلم - الزمر آية ٣٢)", 39),
            JuzInfo(25, "الجزء الخامس والعشرون (إليه يرد - فصلت آية ٤٧)", 41),
            JuzInfo(26, "الجزء السادس والعشرون (حم - الأحقاف آية ١)", 46),
            JuzInfo(27, "الجزء السابع والعشرون (قال فما خطبكم - الذاريات آية ٣١)", 51),
            JuzInfo(28, "الجزء الثامن والعشرون (قد سمع الله - المجادلة آية ١)", 58),
            JuzInfo(29, "الجزء التاسع والعشرون (تبارك الذي - الملك آية ١)", 67),
            JuzInfo(30, "الجزء الثلاثون (عمّ يتساءلون - النبأ آية ١)", 78)
        )
    }

    Dialog(onDismissRequest = onClose) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = if (isDark) DarkGoldSurface else LightGoldSurface,
            border = BorderStroke(1.dp, (if (isDark) DarkGoldPrimary else LightGoldPrimary).copy(alpha = 0.3f)),
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.7f)
                .padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "فهرس الأجزاء والأحزاب الثلاثين",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isDark) DarkGoldPrimary else LightGoldPrimary,
                    modifier = Modifier.padding(bottom = 16.dp)
                )

                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(juzList) { juz ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    val ch = chapters.find { it.id == juz.startSurahId }
                                    if (ch != null) {
                                        onChapterSelected(ch)
                                        onClose()
                                    }
                                }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.GridOn, contentDescription = null, tint = if (isDark) DarkGoldPrimary else LightGoldPrimary)
                            Spacer(modifier = Modifier.width(16.dp))
                            Text(
                                text = "الجزء ${juz.number}: ${juz.name}",
                                fontSize = 15.sp,
                                color = if (isDark) DarkGoldText else LightGoldText
                            )
                        }
                    }
                }
            }
        }
    }
}

// Dialog component for translation languages
@Composable
fun TranslationSelectionDialog(
    viewModel: QuranViewModel,
    currentId: Int?,
    options: List<ApiTranslationResource>,
    isDark: Boolean,
    onSelect: (Int?) -> Unit,
    onClose: () -> Unit
) {
    val downloadProgress by viewModel.translationDownloadProgress.collectAsState()

    Dialog(onDismissRequest = onClose) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = if (isDark) DarkGoldSurface else LightGoldSurface,
            border = BorderStroke(1.dp, (if (isDark) DarkGoldPrimary else LightGoldPrimary).copy(alpha = 0.3f)),
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.7f)
                .padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "اختر لغة الترجمة للآيات",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isDark) DarkGoldPrimary else LightGoldPrimary,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                if (downloadProgress != null) {
                    Column(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                        Text(
                            text = "جاري تحميل الترجمة للعمل دون اتصال... ${((downloadProgress ?: 0f) * 100).toInt()}%",
                            fontSize = 12.sp,
                            color = if (isDark) DarkGoldPrimary else LightGoldPrimary,
                            modifier = Modifier.padding(bottom = 4.dp)
                        )
                        LinearProgressIndicator(
                            progress = { downloadProgress ?: 0f },
                            color = if (isDark) DarkGoldPrimary else LightGoldPrimary,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onSelect(null)
                                    onClose()
                                }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = currentId == null, onClick = { onSelect(null); onClose() })
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(text = "بدون ترجمة (عرض النص العربي فقط)", fontSize = 15.sp, color = if (isDark) DarkGoldText else LightGoldText)
                        }
                    }

                    items(options) { opt ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable {
                                        onSelect(opt.id)
                                        onClose()
                                    }
                                    .padding(vertical = 12.dp, horizontal = 4.dp),
                                 verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(selected = currentId == opt.id, onClick = { onSelect(opt.id); onClose() })
                                Spacer(modifier = Modifier.width(12.dp))
                                val nativeLang = when (opt.languageName.lowercase()) {
                                    "arabic" -> "العربية"
                                    "english" -> "English"
                                    "french" -> "Français"
                                    "spanish" -> "Español"
                                    "turkish" -> "Türkçe"
                                    "urdu" -> "اردو"
                                    "indonesian" -> "Bahasa Indonesia"
                                    "persian", "farsi" -> "فارسی"
                                    "russian" -> "Русский"
                                    "german" -> "Deutsch"
                                    "italian" -> "Italiano"
                                    "swedish" -> "Svenska"
                                    "bengali" -> "বাংলা"
                                    "hindi" -> "हिन्दी"
                                    "chinese" -> "中文"
                                    "bosnian" -> "Bosanski"
                                    "albanian" -> "Shqip"
                                    "thai" -> "ไทย"
                                    "japanese" -> "日本語"
                                    "korean" -> "한국어"
                                    "portuguese" -> "Português"
                                    "dutch" -> "Nederlands"
                                    "somali" -> "Soomaali"
                                    "swahili" -> "Kiswahili"
                                    "tamil" -> "தமிழ்"
                                    "malayalam" -> "മലയാളം"
                                    else -> opt.languageName.replaceFirstChar { it.uppercase() }
                                }
                                Text(
                                    text = "$nativeLang - ${opt.name}",
                                    fontSize = 14.sp,
                                    color = if (isDark) DarkGoldText else LightGoldText,
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            IconButton(
                                onClick = { viewModel.downloadTranslationOffline(opt.id) },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CloudDownload,
                                    contentDescription = "تحميل الترجمة للعمل دون اتصال",
                                    tint = if (isDark) DarkGoldPrimary else LightGoldPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// Customizations settings control Dialog
@Composable
fun SettingsControlDialog(
    viewModel: QuranViewModel,
    textSize: Float,
    brightness: Float,
    isDark: Boolean,
    teacherReciterFolder: String,
    onClose: () -> Unit
) {
    val appLanguage by viewModel.appLanguage.collectAsState()

    Dialog(onDismissRequest = onClose) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = if (isDark) DarkGoldSurface else LightGoldSurface,
            border = BorderStroke(1.dp, (if (isDark) DarkGoldPrimary else LightGoldPrimary).copy(alpha = 0.3f)),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 16.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = getAppString("settings", appLanguage),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isDark) DarkGoldPrimary else LightGoldPrimary,
                    modifier = Modifier.padding(bottom = 16.dp)
                )

                // Dark mode toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = getAppString("dark_mode", appLanguage),
                        fontSize = 15.sp,
                        color = if (isDark) DarkGoldText else LightGoldText
                    )
                    Switch(
                        checked = isDark,
                        onCheckedChange = { viewModel.toggleDarkMode() },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = if (isDark) DarkGoldPrimary else LightGoldPrimary
                        )
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider(color = (if (isDark) DarkGoldPrimary else LightGoldPrimary).copy(alpha = 0.15f))
                Spacer(modifier = Modifier.height(12.dp))

                // App Language Selector Section
                Text(
                    text = getAppString("app_language", appLanguage),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isDark) DarkGoldPrimary else LightGoldPrimary,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                val langs = listOf(
                    "ar" to "العربية",
                    "en" to "English",
                    "fr" to "Français",
                    "es" to "Español",
                    "tr" to "Türkçe",
                    "ur" to "اردو",
                    "id" to "Bahasa Indonesia"
                )

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val chunkedLangs = listOf(
                        listOf("ar" to "العربية", "en" to "English", "fr" to "Français"),
                        listOf("es" to "Español", "tr" to "Türkçe", "ur" to "اردو"),
                        listOf("id" to "Bahasa Indonesia")
                    )
                    chunkedLangs.forEach { rowLangs ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            rowLangs.forEach { (code, name) ->
                                val isSelected = appLanguage == code
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(
                                            if (isSelected) {
                                                (if (isDark) DarkGoldPrimary else LightGoldPrimary).copy(alpha = 0.2f)
                                            } else {
                                                Color.Transparent
                                            }
                                        )
                                        .border(
                                            width = 1.dp,
                                            color = if (isSelected) {
                                                if (isDark) DarkGoldPrimary else LightGoldPrimary
                                            } else {
                                                (if (isDark) DarkGoldPrimary else LightGoldPrimary).copy(alpha = 0.25f)
                                            },
                                            shape = RoundedCornerShape(10.dp)
                                        )
                                        .clickable {
                                            viewModel.setAppLanguage(code)
                                        }
                                        .padding(vertical = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = name,
                                        fontSize = 12.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) {
                                            if (isDark) DarkGoldPrimary else LightGoldPrimary
                                        } else {
                                            if (isDark) DarkGoldText else LightGoldText
                                        }
                                    )
                                }
                            }
                            if (rowLangs.size < 3) {
                                repeat(3 - rowLangs.size) {
                                    Spacer(modifier = Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider(color = (if (isDark) DarkGoldPrimary else LightGoldPrimary).copy(alpha = 0.15f))
                Spacer(modifier = Modifier.height(12.dp))

                // Text Size Adjuster
                Text(
                    text = "${getAppString("text_size", appLanguage)}: ${textSize.toInt()}sp",
                    fontSize = 14.sp,
                    color = if (isDark) DarkGoldText else LightGoldText
                )
                Slider(
                    value = textSize,
                    onValueChange = { viewModel.updateTextSize(it) },
                    valueRange = 18f..40f,
                    colors = SliderDefaults.colors(
                        activeTrackColor = if (isDark) DarkGoldPrimary else LightGoldPrimary,
                        thumbColor = if (isDark) DarkGoldPrimary else LightGoldPrimary
                    )
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Brightness Overlay Adjuster
                Text(
                    text = "${getAppString("brightness_control", appLanguage)}: ${(100 - (brightness * 100).toInt())}%",
                    fontSize = 14.sp,
                    color = if (isDark) DarkGoldText else LightGoldText
                )
                Slider(
                    value = brightness,
                    onValueChange = { viewModel.updateBrightness(it) },
                    valueRange = 0f..0.8f,
                    colors = SliderDefaults.colors(
                        activeTrackColor = if (isDark) DarkGoldPrimary else LightGoldPrimary,
                        thumbColor = if (isDark) DarkGoldPrimary else LightGoldPrimary
                    )
                )

                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider(color = (if (isDark) DarkGoldPrimary else LightGoldPrimary).copy(alpha = 0.15f))
                Spacer(modifier = Modifier.height(12.dp))

                // Teacher Reciter Selection
                Text(
                    text = getAppString("teacher_reciter", appLanguage),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isDark) DarkGoldPrimary else LightGoldPrimary
                )
                
                val defaultFolders = listOf(
                    "Alafasy_128kbps" to "الشيخ مشاري العفاسي",
                    "Abdul_Basit_Murattal_192kbps" to "الشيخ عبد الباسط",
                    "Husary_128kbps" to "الشيخ الحصري المعلم",
                    "MaherAlMuaiqly128kbps" to "الشيخ ماهر المعيقلي"
                )
                val customFolders = viewModel.customTeacherReciters.collectAsState().value
                val allFolders = defaultFolders + customFolders

                var showAddReciterDialog by remember { mutableStateOf(false) }

                val downloadedFolders by viewModel.downloadedTeacherReciters.collectAsState()
                val downloadingFolders by viewModel.downloadingTeacherReciters.collectAsState()

                Column(modifier = Modifier.fillMaxWidth()) {
                    allFolders.forEach { f ->
                        val isDownloaded = downloadedFolders.contains(f.first)
                        val progress = downloadingFolders[f.first]

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.setTeacherReciter(f.first) }
                                .padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = teacherReciterFolder == f.first,
                                onClick = { viewModel.setTeacherReciter(f.first) },
                                colors = RadioButtonDefaults.colors(
                                    selectedColor = if (isDark) DarkGoldPrimary else LightGoldPrimary
                                )
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = f.second,
                                    fontSize = 14.sp,
                                    color = if (isDark) DarkGoldText else LightGoldText,
                                    fontWeight = if (teacherReciterFolder == f.first) FontWeight.Bold else FontWeight.Normal
                                )
                                if (isDownloaded) {
                                    Text(
                                        text = if (appLanguage == "ar") "✓ متاح بدون إنترنت" else "✓ Available offline",
                                        fontSize = 11.sp,
                                        color = if (isDark) Color(0xFF81C784) else Color(0xFF2E7D32)
                                    )
                                }
                                if (progress != null) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    LinearProgressIndicator(
                                        progress = { progress },
                                        color = if (isDark) DarkGoldPrimary else LightGoldPrimary,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                            }
                            
                            Spacer(modifier = Modifier.width(8.dp))

                            if (progress != null) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    color = if (isDark) DarkGoldPrimary else LightGoldPrimary,
                                    strokeWidth = 2.dp
                                )
                            } else {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    if (!isDownloaded) {
                                        IconButton(
                                            onClick = {
                                                viewModel.downloadTeacherReciterAudio(f.first, f.second)
                                            },
                                            modifier = Modifier.size(36.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Download,
                                                contentDescription = "تنزيل الملفات الصوتية",
                                                tint = if (isDark) DarkGoldPrimary else LightGoldPrimary,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    } else {
                                        IconButton(
                                            onClick = {
                                                viewModel.deleteTeacherReciterAudio(f.first)
                                            },
                                            modifier = Modifier.size(36.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Delete,
                                                contentDescription = "حذف الملفات الصوتية",
                                                tint = Color.Red.copy(alpha = 0.8f),
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                Button(
                    onClick = { showAddReciterDialog = true },
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isDark) DarkGoldPrimary else LightGoldPrimary
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null, tint = Color.Black)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (appLanguage == "ar") "إضافة وتنزيل قارئ معلم جديد" else "Add & Download Teacher Reciter",
                        color = Color.Black,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }

                if (showAddReciterDialog) {
                    val availablePool = listOf(
                        "Ghamadi_40kbps" to "الشيخ سعد الغامدي",
                        "Minshawi_Mujawwad_192kbps" to "الشيخ محمد صديق المنشاوي",
                        "Shatri_128kbps" to "الشيخ أبو بكر الشاطري",
                        "Ajamy_128kbps" to "الشيخ أحمد بن علي العجمي",
                        "Fares_128kbps" to "الشيخ فارس عباد",
                        "Yasser_Ad-Dussary_128kbps" to "الشيخ ياسر الدوسري"
                    ).filter { poolItem -> allFolders.none { it.first == poolItem.first } }

                    Dialog(onDismissRequest = { showAddReciterDialog = false }) {
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (isDark) DarkGoldSurface else LightGoldSurface
                            ),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth().padding(16.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = if (appLanguage == "ar") "تنزيل وإضافة قارئ جديد" else "Download & Add Reciter",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp,
                                    color = if (isDark) DarkGoldPrimary else LightGoldPrimary,
                                    modifier = Modifier.padding(bottom = 12.dp)
                                )
                                
                                if (availablePool.isEmpty()) {
                                    Text(
                                        text = if (appLanguage == "ar") "تم تنزيل جميع القراء المتاحين." else "All available reciters are already downloaded.",
                                        fontSize = 14.sp,
                                        color = if (isDark) DarkGoldText else LightGoldText,
                                        modifier = Modifier.padding(vertical = 12.dp)
                                    )
                                } else {
                                    LazyColumn(
                                        verticalArrangement = Arrangement.spacedBy(8.dp),
                                        modifier = Modifier.heightIn(max = 250.dp)
                                    ) {
                                        items(availablePool) { item ->
                                            val progress = viewModel.downloadingTeacherReciters.collectAsState().value[item.first]
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .background(Color.Black.copy(alpha = 0.1f), RoundedCornerShape(8.dp))
                                                    .padding(8.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(
                                                        text = item.second,
                                                        fontSize = 14.sp,
                                                        fontWeight = FontWeight.SemiBold,
                                                        color = if (isDark) DarkGoldText else LightGoldText
                                                    )
                                                    if (progress != null) {
                                                        Spacer(modifier = Modifier.height(4.dp))
                                                        LinearProgressIndicator(
                                                            progress = { progress },
                                                            color = if (isDark) DarkGoldPrimary else LightGoldPrimary,
                                                            modifier = Modifier.fillMaxWidth()
                                                        )
                                                    }
                                                }
                                                Spacer(modifier = Modifier.width(8.dp))
                                                if (progress == null) {
                                                    IconButton(onClick = {
                                                        viewModel.downloadTeacherReciterAudio(item.first, item.second)
                                                    }) {
                                                        Icon(
                                                            imageVector = Icons.Default.Download,
                                                            contentDescription = "تنزيل",
                                                            tint = if (isDark) DarkGoldPrimary else LightGoldPrimary
                                                        )
                                                    }
                                                } else {
                                                    CircularProgressIndicator(
                                                        modifier = Modifier.size(24.dp),
                                                        color = if (isDark) DarkGoldPrimary else LightGoldPrimary,
                                                        strokeWidth = 2.dp
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(16.dp))
                                Button(
                                    onClick = { showAddReciterDialog = false },
                                    modifier = Modifier.align(Alignment.End),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (isDark) DarkGoldPrimary else LightGoldPrimary
                                    )
                                ) {
                                    Text(
                                        text = if (appLanguage == "ar") "إغلاق" else "Close",
                                        color = Color.Black,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider(color = (if (isDark) DarkGoldPrimary else LightGoldPrimary).copy(alpha = 0.15f))
                Spacer(modifier = Modifier.height(12.dp))

                // Notification & Update UI
                val context = LocalContext.current
                val latestTitle by viewModel.latestNotificationTitle.collectAsState()
                val latestBody by viewModel.latestNotificationBody.collectAsState()
                val latestUrl by viewModel.latestNotificationUrl.collectAsState()

                Text(
                    text = if (appLanguage == "ar") "تحديثات وإشعارات التطبيق" else "App Updates & Notifications",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isDark) DarkGoldPrimary else LightGoldPrimary,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                // 1. Update App Button
                Button(
                    onClick = {
                        try {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://thegoldenquran.blogspot.com/2026/07/blog-post.html"))
                            context.startActivity(intent)
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = (if (isDark) DarkGoldPrimary else LightGoldPrimary),
                        contentColor = Color.Black
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                ) {
                    Icon(imageVector = Icons.Default.SystemUpdate, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (appLanguage == "ar") "تحديث التطبيق الحالي" else "Update Application",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // 2. Latest Notification Display Card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = (if (isDark) DarkGoldSurface else LightGoldSurface).copy(alpha = 0.5f)
                    ),
                    border = BorderStroke(1.dp, (if (isDark) DarkGoldPrimary else LightGoldPrimary).copy(alpha = 0.2f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(
                                imageVector = Icons.Default.Notifications,
                                contentDescription = null,
                                tint = if (isDark) DarkGoldPrimary else LightGoldPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (appLanguage == "ar") "آخر إشعار مستلم:" else "Latest received notification:",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isDark) DarkGoldPrimary else LightGoldPrimary
                            )
                        }
                        
                        Spacer(modifier = Modifier.height(8.dp))

                        if (!latestTitle.isNullOrBlank() || !latestBody.isNullOrBlank()) {
                            if (!latestTitle.isNullOrBlank()) {
                                Text(
                                    text = latestTitle ?: "",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isDark) Color.White else Color.Black
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                            }
                            if (!latestBody.isNullOrBlank()) {
                                Text(
                                    text = latestBody ?: "",
                                    fontSize = 12.sp,
                                    color = if (isDark) DarkGoldText else LightGoldText
                                )
                            }
                            
                            if (!latestUrl.isNullOrBlank()) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Button(
                                    onClick = {
                                        try {
                                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(latestUrl ?: ""))
                                            context.startActivity(intent)
                                        } catch (e: Exception) {
                                            e.printStackTrace()
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = (if (isDark) DarkGoldPrimary else LightGoldPrimary).copy(alpha = 0.15f),
                                        contentColor = if (isDark) DarkGoldPrimary else LightGoldPrimary
                                    ),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.align(Alignment.End),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.OpenInBrowser, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (appLanguage == "ar") "فتح الرابط المرفق" else "Open Attached Link",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        } else {
                            Text(
                                text = if (appLanguage == "ar") "لا توجد إشعارات جديدة حالياً." else "No new notifications currently.",
                                fontSize = 12.sp,
                                color = (if (isDark) DarkGoldText else LightGoldText).copy(alpha = 0.7f),
                                modifier = Modifier.padding(vertical = 4.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = onClose,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = if (isDark) DarkGoldPrimary else LightGoldPrimary)
                ) {
                    Text(text = getAppString("save_confirm", appLanguage), color = if (isDark) DarkGoldBackground else LightGoldBackground, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// Dialog component for word and verse search
@Composable
fun SearchVerseDialog(
    query: String,
    results: List<VerseEntity>,
    isDark: Boolean,
    onQueryChange: (String) -> Unit,
    onSelectVerse: (VerseEntity) -> Unit,
    onClose: () -> Unit
) {
    Dialog(onDismissRequest = onClose) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = if (isDark) DarkGoldSurface else LightGoldSurface,
            border = BorderStroke(1.dp, (if (isDark) DarkGoldPrimary else LightGoldPrimary).copy(alpha = 0.3f)),
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.8f)
                .padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "البحث السريع بالكلمات والآيات",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isDark) DarkGoldPrimary else LightGoldPrimary,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                TextField(
                    value = query,
                    onValueChange = onQueryChange,
                    placeholder = { Text("اكتب الكلمة أو جزء من الآية للبحث...") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent
                    )
                )

                Spacer(modifier = Modifier.height(16.dp))

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(results) { verse ->
                        Card(
                            onClick = { onSelectVerse(verse) },
                            colors = CardDefaults.cardColors(containerColor = (if (isDark) DarkGoldPrimary else LightGoldPrimary).copy(alpha = 0.05f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = verse.textUthmani,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isDark) DarkGoldText else LightGoldText,
                                    textAlign = TextAlign.Right,
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "سورة ${verse.verseKey.split(":").firstOrNull() ?: ""} - آية ${verse.verseNumber}",
                                    fontSize = 12.sp,
                                    color = (if (isDark) DarkGoldPrimary else LightGoldPrimary),
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// Dialog presentation of user bookmarks
@Composable
fun BookmarksDialog(
    bookmarks: List<BookmarkEntity>,
    isDark: Boolean,
    currentChapterId: Int?,
    currentVerseNumber: Int?,
    onAddBookmark: (Int, Int) -> Unit,
    onSelectBookmark: (BookmarkEntity) -> Unit,
    onDeleteBookmark: (BookmarkEntity) -> Unit,
    onClose: () -> Unit
) {
    Dialog(onDismissRequest = onClose) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = if (isDark) DarkGoldSurface else LightGoldSurface,
            border = BorderStroke(1.dp, (if (isDark) DarkGoldPrimary else LightGoldPrimary).copy(alpha = 0.3f)),
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.55f)
                .padding(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "علامات التوقف والحفظ الخاصة بك",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isDark) DarkGoldPrimary else LightGoldPrimary,
                    modifier = Modifier.padding(bottom = 12.dp),
                    textAlign = TextAlign.Center
                )

                // Row of Buttons: Add Bookmark & Go to Previous
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Add Stop Mark Button
                    Button(
                        onClick = {
                            if (currentChapterId != null && currentVerseNumber != null) {
                                onAddBookmark(currentChapterId, currentVerseNumber)
                            }
                        },
                        enabled = currentChapterId != null && currentVerseNumber != null,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isDark) DarkGoldPrimary else LightGoldPrimary,
                            contentColor = if (isDark) DarkGoldBackground else LightGoldBackground
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "إضافة علامة توقف",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Go to Previous Mark Button
                    Button(
                        onClick = {
                            if (bookmarks.isNotEmpty()) {
                                onSelectBookmark(bookmarks.first())
                            }
                        },
                        enabled = bookmarks.isNotEmpty(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isDark) AccentGreen else Color(0xFF2E7D32),
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "الذهاب للعلامة السابقة",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // List of Bookmarks
                if (bookmarks.isEmpty()) {
                    Box(
                        modifier = Modifier.fillMaxSize().weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "لا توجد علامات حفظ محفوظة حالياً.\n(اضغط مطولاً على الآية لحفظها)",
                            textAlign = TextAlign.Center,
                            fontSize = 14.sp,
                            color = (if (isDark) DarkGoldText else LightGoldText).copy(alpha = 0.5f)
                        )
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        items(bookmarks) { bmk ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isDark) Color.Black.copy(alpha = 0.15f) else Color.White.copy(alpha = 0.5f))
                                    .padding(horizontal = 8.dp, vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { onSelectBookmark(bmk) }
                                        .padding(vertical = 8.dp)
                                ) {
                                    Icon(
                                        imageVector = if (bmk.type == "reading") Icons.Default.MenuBook else Icons.Default.Bookmark,
                                        contentDescription = null,
                                        tint = if (isDark) DarkGoldPrimary else LightGoldPrimary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = bmk.title,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = if (isDark) DarkGoldText else LightGoldText
                                    )
                                }
                                
                                IconButton(
                                    onClick = { onDeleteBookmark(bmk) },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "حذف العلامة",
                                        tint = if (isDark) Color(0xFFEF5350) else Color(0xFFD32F2F),
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = onClose,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isDark) DarkGoldPrimary else LightGoldPrimary,
                        contentColor = if (isDark) DarkGoldBackground else LightGoldBackground
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                ) {
                    Text("إغلاق", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// Duaa Khatm Al-Quran layout presentation
@Composable
fun DuaaKhatmDialog(
    isDark: Boolean,
    onClose: () -> Unit
) {
    Dialog(onDismissRequest = onClose) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = if (isDark) DarkGoldSurface else LightGoldSurface,
            border = BorderStroke(1.dp, (if (isDark) DarkGoldPrimary else LightGoldPrimary).copy(alpha = 0.3f)),
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f)
                .padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "دعاء ختم القرآن الكريم",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isDark) DarkGoldPrimary else LightGoldPrimary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)
                )

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    val duaaVerses = listOf(
                        "اللَّهُمَّ ارْحَمْنِي بِالقُرْآنِ وَاجْعَلْهُ لِي إِمَاماً وَنُوراً وَهُدًى وَرَحْمَةً",
                        "اللَّهُمَّ ذَكِّرْنِي مِنْهُ مَا نَسِيتُ وَعَلِّمْنِي مِنْهُ مَا جَهِلْتُ",
                        "وَارْزُقْنِي تِلاَوَتَهُ آنَاءَ اللَّيْلِ وَأَطْرَافَ النَّهَارِ وَاجْعَلْهُ لِي حُجَّةً يَا رَبَّ العَالَمِينَ",
                        "اللَّهُمَّ أَصْلِحْ لِي دِينِي الَّذِي هُوَ عِصْمَةُ أَمْرِي، وَأَصْلِحْ لِي دُنْيَايَ الَّتِي فِيهَا مَعَاشِي",
                        "وَأَصْلِحْ لِي آخِرَتِي الَّتِي فِيهَا مَعَادِي، وَاجْعَلِ الحَيَاةَ زِيَادَةً لِي فِي كُلِّ خَيْرٍ وَاجْعَلِ المَوْتَ رَاحَةً لِي مِنْ كُلِّ شَرٍّ",
                        "اللَّهُمَّ اجْعَلْ خَيْرَ عُمْرِي آخِرَهُ وَخَيْرَ عَمَلِي خَوَاتِمَهُ وَخَيْرَ أَيَّامِي يَوْمَ أَلْقَاكَ فِيهِ"
                    )
                    items(duaaVerses) { verse ->
                        Text(
                            text = verse,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium,
                            lineHeight = 24.sp,
                            color = if (isDark) DarkGoldText else LightGoldText,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = onClose,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = if (isDark) DarkGoldPrimary else LightGoldPrimary)
                ) {
                    Text(
                        text = "تقبل الله منا ومنكم صالح الأعمال",
                        color = if (isDark) DarkGoldBackground else LightGoldBackground,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

// Beautiful Islamic silver/green dashboard welcome screen
@Composable
fun WelcomeDashboardScreen(
    viewModel: QuranViewModel,
    isDark: Boolean,
    onStartReading: () -> Unit
) {
    var showHadithDialog by remember { mutableStateOf(false) }
    var showRadioDialog by remember { mutableStateOf(false) }
    var showAzkarDialog by remember { mutableStateOf(false) }

    // Animation for golden floating Quran icon
    val infiniteTransition = androidx.compose.animation.core.rememberInfiniteTransition(label = "floating")
    val floatY by infiniteTransition.animateFloat(
        initialValue = -8f,
        targetValue = 8f,
        animationSpec = androidx.compose.animation.core.infiniteRepeatable(
            animation = androidx.compose.animation.core.tween(2000, easing = androidx.compose.animation.core.FastOutSlowInEasing),
            repeatMode = androidx.compose.animation.core.RepeatMode.Reverse
        ),
        label = "yOffset"
    )

    // Silver and Green Islamic Palette
    val emeraldGreen = Color(0xFF1B5E20)
    val lightEmerald = Color(0xFF2E7D32)
    val silverColor = Color(0xFFE0E0E0)
    val darkSilver = Color(0xFF90A4AE)
    val shinyGold = Color(0xFFD4AF37)

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = if (isDark) Color(0xFF0C140E) else Color(0xFFF1F8F3) // Subtle deep green dark, soft green-white light
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            // Elegant geometric canvas decorations
            androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                val decorationColor = if (isDark) lightEmerald.copy(alpha = 0.12f) else darkSilver.copy(alpha = 0.12f)
                
                // Draw Islamic concentric arches and geometric circular patterns
                drawCircle(
                    color = decorationColor,
                    radius = w * 0.45f,
                    center = androidx.compose.ui.geometry.Offset(w / 2f, h * 0.28f),
                    style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2.dp.toPx())
                )
                drawCircle(
                    color = decorationColor,
                    radius = w * 0.42f,
                    center = androidx.compose.ui.geometry.Offset(w / 2f, h * 0.28f),
                    style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.dp.toPx())
                )
                // Bottom decorative pattern
                drawCircle(
                    color = decorationColor,
                    radius = w * 0.3f,
                    center = androidx.compose.ui.geometry.Offset(w / 2f, h * 1.05f),
                    style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.5.dp.toPx())
                )
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Top header ornament + Moving Golden Book Icon
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(top = 40.dp)
                ) {
                    // Floating golden book icon
                    Box(
                        modifier = Modifier
                            .offset(y = floatY.dp)
                            .size(100.dp)
                            .background(
                                brush = Brush.radialGradient(
                                    colors = listOf(shinyGold.copy(alpha = 0.25f), Color.Transparent)
                                ),
                                shape = CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.MenuBook,
                            contentDescription = "القرآن الكريم",
                            tint = shinyGold,
                            modifier = Modifier.size(64.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Title
                    Text(
                        text = "الْقُرْآنُ الْكَرِيمُ الذَّهَبِيُّ",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        color = shinyGold,
                        textAlign = TextAlign.Center,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "The Holy Quran - Golden Edition",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Light,
                        color = if (isDark) silverColor.copy(alpha = 0.5f) else Color.DarkGray.copy(alpha = 0.5f),
                        textAlign = TextAlign.Center
                    )
                }

                // Middle ornamental divider
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 40.dp)
                ) {
                    HorizontalDivider(modifier = Modifier.weight(1f), color = if (isDark) lightEmerald.copy(alpha = 0.3f) else darkSilver.copy(alpha = 0.3f))
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = null,
                        tint = shinyGold.copy(alpha = 0.7f),
                        modifier = Modifier.size(18.dp).padding(horizontal = 4.dp)
                    )
                    HorizontalDivider(modifier = Modifier.weight(1f), color = if (isDark) lightEmerald.copy(alpha = 0.3f) else darkSilver.copy(alpha = 0.3f))
                }

                // Bottom list with buttons
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 32.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // 1. Read Quran Button (Takes to Surah Al-Fatiha or last saved bookmark)
                    Button(
                        onClick = onStartReading,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = emeraldGreen,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.5.dp, shinyGold),
                        modifier = Modifier
                            .fillMaxWidth(0.85f)
                            .height(56.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.MenuBook, contentDescription = null, tint = shinyGold)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text("اقرأ القرآن الكريم", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // 2. Prophet's Hadith Button (Prophetic tradition display)
                    Button(
                        onClick = { showHadithDialog = true },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isDark) Color(0xFF1E2F21) else silverColor,
                            contentColor = if (isDark) Color.White else Color.Black
                        ),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, if (isDark) lightEmerald else darkSilver),
                        modifier = Modifier
                            .fillMaxWidth(0.85f)
                            .height(52.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = shinyGold)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text("حديث النبي صلى الله عليه وسلم", fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }

                    // 3. Quran Radio Live Streaming Button
                    Button(
                        onClick = { showRadioDialog = true },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isDark) Color(0xFF1E2F21) else silverColor,
                            contentColor = if (isDark) Color.White else Color.Black
                        ),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, if (isDark) lightEmerald else darkSilver),
                        modifier = Modifier
                            .fillMaxWidth(0.85f)
                            .height(52.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Radio, contentDescription = null, tint = shinyGold)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text("إذاعة القرآن الكريم مباشر", fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }

                    // 4. Azkar Counter Button
                    Button(
                        onClick = { showAzkarDialog = true },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isDark) Color(0xFF1E2F21) else silverColor,
                            contentColor = if (isDark) Color.White else Color.Black
                        ),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, if (isDark) lightEmerald else darkSilver),
                        modifier = Modifier
                            .fillMaxWidth(0.85f)
                            .height(52.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.VolunteerActivism, contentDescription = null, tint = shinyGold)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text("أذكار المسلم اليومية", fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }
    }

    // Modal dialog overlays
    if (showHadithDialog) {
        HadithDialog(isDark = isDark, onClose = { showHadithDialog = false })
    }

    if (showRadioDialog) {
        QuranRadioDialog(viewModel = viewModel, isDark = isDark, onClose = { showRadioDialog = false })
    }

    if (showAzkarDialog) {
        AzkarDialog(isDark = isDark, onClose = { showAzkarDialog = false })
    }
}

// Dialog to let users choose if they bookmark for Reading or Memorizing
@Composable
fun AddBookmarkDialog(
    chapterId: Int,
    verseNumber: Int,
    isDark: Boolean,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = if (isDark) DarkGoldSurface else LightGoldSurface,
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "حفظ علامة التوقف",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isDark) DarkGoldPrimary else LightGoldPrimary,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                Text(
                    text = "هل تريد إضافة علامة تلاوة لمكان وقوفك في القراءة أم في الحفظ والمراجعة؟",
                    fontSize = 15.sp,
                    textAlign = TextAlign.Center,
                    color = if (isDark) DarkGoldText else LightGoldText,
                    modifier = Modifier.padding(bottom = 20.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = { onConfirm("reading") },
                        colors = ButtonDefaults.buttonColors(containerColor = if (isDark) DarkGoldPrimary else LightGoldPrimary),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("علامة قراءة", color = if (isDark) DarkGoldBackground else LightGoldBackground)
                    }

                    Button(
                        onClick = { onConfirm("memorization") },
                        colors = ButtonDefaults.buttonColors(containerColor = AccentGreen),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("علامة حفظ", color = Color.White)
                    }
                }
            }
        }
    }
}

// Surah Title Card matching the Elegant Dark design
@Composable
fun SurahTitleCard(
    chapter: ChapterEntity?,
    isDark: Boolean
) {
    chapter?.let { ch ->
        Card(
            colors = CardDefaults.cardColors(
                containerColor = if (isDark) DarkGoldSurface else LightGoldSurface
            ),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, (if (isDark) DarkGoldPrimary else LightGoldPrimary).copy(alpha = 0.4f)),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "سُورَةُ ${ch.nameArabic}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isDark) DarkGoldPrimary else LightGoldPrimary,
                    letterSpacing = 2.sp,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "عدد آياتها: ${ch.versesCount} • نزولها: ${if (ch.revelationPlace == "makkah") "مكية" else "مدنية"}",
                    fontSize = 12.sp,
                    color = (if (isDark) DarkGoldText else LightGoldText).copy(alpha = 0.7f),
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

