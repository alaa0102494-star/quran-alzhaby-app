package com.example.ui.viewmodel

import android.app.Application
import android.media.MediaPlayer
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.api.QuranApiService
import com.example.data.api.ApiTranslationResource
import com.example.data.db.*
import com.example.data.repository.QuranRepository
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.URL

data class Reciter(
    val id: Int,
    val nameArabic: String,
    val folder: String, // For EveryAyah (Verse-by-Verse)
    val baseUrl: String // For Full Surah Audio
)

val recitersList = listOf(
    Reciter(1, "مشاري العفاسي", "Alafasy_128kbps", "https://server8.mp3quran.net/afs/"),
    Reciter(2, "عبد الباسط عبد الصمد", "Abdul_Basit_Murattal_192kbps", "https://server7.mp3quran.net/basit/"),
    Reciter(3, "محمود خليل الحصري", "Husary_128kbps", "https://server13.mp3quran.net/husr/"),
    Reciter(4, "سعد الغامدي", "Ghamadi_40kbps", "https://server7.mp3quran.net/s_gmd/"),
    Reciter(5, "ماهر المعيقلي", "MaherAlMuaiqly128kbps", "https://server12.mp3quran.net/maher/")
)

class QuranViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = application.getSharedPreferences("quran_prefs", android.content.Context.MODE_PRIVATE)
    val customTeacherReciters = MutableStateFlow<List<Pair<String, String>>>(emptyList())
    val downloadingTeacherReciters = MutableStateFlow<Map<String, Float>>(emptyMap())
    val downloadedTeacherReciters = MutableStateFlow<Set<String>>(emptySet())

    private val repository: QuranRepository
    private val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
    private val wordMeaningListAdapter = moshi.adapter<List<WordMeaning>>(
        Types.newParameterizedType(List::class.java, WordMeaning::class.java)
    )

    // Data streams
    val chapters = MutableStateFlow<List<ChapterEntity>>(emptyList())
    val verses = MutableStateFlow<List<VerseEntity>>(emptyList())
    val translations = MutableStateFlow<List<TranslationEntity>>(emptyList())
    val tafsirs = MutableStateFlow<List<TafsirEntity>>(emptyList())
    val bookmarks = MutableStateFlow<List<BookmarkEntity>>(emptyList())

    // Selected Chapter
    val selectedChapter = MutableStateFlow<ChapterEntity?>(null)
    val showWelcomeDashboard = MutableStateFlow(true)
    val appLanguage = MutableStateFlow("ar") // "ar", "en", "fr", "es", "tr", "ur", "id" etc.
    val isTeacherModeEnabled = MutableStateFlow(false)

    fun setAppLanguage(lang: String) {
        appLanguage.value = lang
    }

    fun toggleTeacherMode() {
        isTeacherModeEnabled.value = !isTeacherModeEnabled.value
    }

    // Translation Config
    val translationLanguageId = MutableStateFlow<Int?>(null) // null means no translations shown under verses
    val availableTranslations = MutableStateFlow<List<ApiTranslationResource>>(emptyList())

    // Settings States
    val textSize = MutableStateFlow(24f)
    val bgColor = MutableStateFlow(0xFF0D0D0D) // Default Elegant Dark background
    val brightness = MutableStateFlow(0f) // Black overlay transparency (0f to 0.8f)
    val isDarkTheme = MutableStateFlow(true) // Default to Elegant Dark
    val teacherReciterFolder = MutableStateFlow("Alafasy_128kbps")
    val lastRestoredScrollIndex = MutableStateFlow(0)

    val latestNotificationTitle = MutableStateFlow<String?>(null)
    val latestNotificationBody = MutableStateFlow<String?>(null)
    val latestNotificationUrl = MutableStateFlow<String?>(null)
    val showInAppNotification = MutableStateFlow<Boolean>(false)

    // Active Interactive Verse Highlights
    val highlightedVerseKey = MutableStateFlow<String?>(null)
    val highlightedWordText = MutableStateFlow<String?>(null)
    val activeWordMeaning = MutableStateFlow<String?>(null)

    // Search
    val searchQuery = MutableStateFlow("")
    val searchResults = MutableStateFlow<List<VerseEntity>>(emptyList())

    // Loading / Toast notifications
    val isLoading = MutableStateFlow(false)
    val errorMessage = MutableStateFlow<String?>(null)

    // Offline Data Download progress states
    val downloadProgress = MutableStateFlow<Float?>(null) // null means not active, 0.0 to 1.0 means downloading
    val translationDownloadProgress = MutableStateFlow<Float?>(null)
    val externalApiImportProgress = MutableStateFlow<Float?>(null)
    val audioDownloadProgress = MutableStateFlow<Map<String, Float>>(emptyMap()) // key: "reciterId_surahNum", value: progress
    val downloadedAudios = MutableStateFlow<Set<String>>(emptySet()) // key: "reciterId_surahNum"

    // Audio Playback
    private var mediaPlayer: MediaPlayer? = null
    private val playerLock = Any()
    val isPlaying = MutableStateFlow(false)
    val currentAudioProgress = MutableStateFlow(0f)
    val audioDuration = MutableStateFlow(0)
    val currentAudioTime = MutableStateFlow(0)
    val isRadioBuffering = MutableStateFlow(false)
    val activeRadioStationName = MutableStateFlow<String?>(null)
    
    val selectedReciterIndex = MutableStateFlow(0)
    val isVerseAudioPlaying = MutableStateFlow(false)

    private var progressJob: Job? = null
    private var prepareJob: Job? = null
    private var prepareTimeoutJob: Job? = null
    private var versesJob: Job? = null
    private var translationsJob: Job? = null
    private var tafsirsJob: Job? = null

    init {
        val database = AppDatabase.getDatabase(application)
        val apiService = QuranApiService.create()
        repository = QuranRepository(application, database.quranDao(), apiService)

        // Load bookmarks
        viewModelScope.launch {
            repository.getAllBookmarks().collect {
                bookmarks.value = it
            }
        }

        // Restore saved translation ID
        val savedLangId = prefs.getInt("translation_lang_id", -1)
        if (savedLangId != -1) {
            translationLanguageId.value = savedLangId
        } else {
            translationLanguageId.value = null
        }

        // Restore custom teacher reciters
        loadCustomTeacherReciters()

        // Initial Load Chapters
        loadChapters()

        // Load available translation options
        loadAvailableTranslations()

        // Sync downloaded audios set
        updateDownloadedAudios()
        updateDownloadedTeacherReciters()
        predownloadDefaultReciters()
        refreshLatestNotification()
    }

    fun refreshLatestNotification() {
        latestNotificationTitle.value = prefs.getString("latest_notification_title", null)
        latestNotificationBody.value = prefs.getString("latest_notification_body", null)
        latestNotificationUrl.value = prefs.getString("latest_notification_url", null)
    }

    fun saveNotification(title: String?, body: String?, url: String?) {
        prefs.edit().apply {
            putString("latest_notification_title", title)
            putString("latest_notification_body", body)
            putString("latest_notification_url", url)
            apply()
        }
        refreshLatestNotification()
        if (!title.isNullOrBlank() || !body.isNullOrBlank()) {
            showInAppNotification.value = true
        }
    }

    fun dismissInAppNotification() {
        showInAppNotification.value = false
    }

    fun loadChapters() {
        isLoading.value = true
        viewModelScope.launch {
            repository.getChapters().collect {
                chapters.value = it
                isLoading.value = false
                // Auto-select first chapter if nothing is selected
                if (selectedChapter.value == null && it.isNotEmpty()) {
                    val savedChapterId = prefs.getInt("last_read_chapter_id", -1)
                    val savedScrollIndex = prefs.getInt("last_read_scroll_index", 0)
                    if (savedChapterId != -1) {
                        val savedCh = it.find { ch -> ch.id == savedChapterId }
                        if (savedCh != null) {
                            lastRestoredScrollIndex.value = savedScrollIndex
                            selectedChapter.value = savedCh
                            selectChapter(savedCh)
                            return@collect
                        }
                    }
                    selectChapter(it.first())
                }
            }
        }
    }

    private fun loadAvailableTranslations() {
        viewModelScope.launch {
            val list = repository.getAvailableTranslations()
            val sortedList = list.sortedWith(compareByDescending<ApiTranslationResource> {
                val lang = it.languageName.lowercase()
                lang == "english" || lang == "malay" || lang == "indonesian" || lang == "french"
            }.thenBy {
                val lang = it.languageName.lowercase()
                when (lang) {
                    "english" -> 0
                    "malay" -> 1
                    "indonesian" -> 2
                    "french" -> 3
                    else -> 4
                }
            }.thenBy { it.languageName })
            availableTranslations.value = sortedList
        }
    }

    fun selectChapter(chapter: ChapterEntity) {
        selectedChapter.value = chapter
        highlightedVerseKey.value = null
        highlightedWordText.value = null
        activeWordMeaning.value = null

        // Stop any active audio
        stopAudio()

        // Fetch verses
        versesJob?.cancel()
        versesJob = viewModelScope.launch {
            isLoading.value = true
            repository.getVersesByChapter(chapter.id).collect {
                verses.value = it
                isLoading.value = false
            }
        }

        // Fetch translation overlays if any is active
        loadTranslationOverlay(chapter.id)

        // Fetch tafseer
        loadTafseers(chapter.id)
    }

    fun setTranslationLanguage(langId: Int?) {
        translationLanguageId.value = langId
        if (langId != null) {
            prefs.edit().putInt("translation_lang_id", langId).apply()
        } else {
            prefs.edit().remove("translation_lang_id").apply()
        }
        val currentChapterId = selectedChapter.value?.id ?: return
        loadTranslationOverlay(currentChapterId)
    }

    private fun loadTranslationOverlay(chapterId: Int) {
        val langId = translationLanguageId.value
        if (langId == null) {
            translations.value = emptyList()
            return
        }

        translationsJob?.cancel()
        translationsJob = viewModelScope.launch {
            repository.getTranslationsForChapter(chapterId, langId).collect {
                translations.value = it
            }
        }
    }

    private fun loadTafseers(chapterId: Int) {
        tafsirsJob?.cancel()
        tafsirsJob = viewModelScope.launch {
            repository.getTafsirsForChapter(chapterId, 16).collect { // 16 is Al-Tafseer Al-Muyassar
                tafsirs.value = it
            }
        }
    }

    // Toggle styling features
    fun toggleDarkMode() {
        isDarkTheme.value = !isDarkTheme.value
        if (isDarkTheme.value) {
            bgColor.value = 0xFF0D0D0D // Elegant Dark obsidian
        } else {
            bgColor.value = 0xFFFAF6F0 // warm cream
        }
    }

    fun updateBgColor(colorVal: Long) {
        bgColor.value = colorVal
    }

    fun updateTextSize(sizeVal: Float) {
        textSize.value = sizeVal
    }

    fun updateBrightness(valIn: Float) {
        brightness.value = valIn
    }

    fun setTeacherReciter(folder: String) {
        teacherReciterFolder.value = folder
    }

    // Bookmarks management
    fun toggleBookmark(chapterId: Int, verseNum: Int) {
        viewModelScope.launch {
            val isBookmarked = bookmarks.value.any { it.chapterId == chapterId && it.verseNumber == verseNum }
            if (isBookmarked) {
                repository.removeBookmark(chapterId, verseNum)
            } else {
                repository.addBookmark(
                    chapterId = chapterId,
                    verseNumber = verseNum,
                    pageNumber = (verseNum / 10) + 1, // approximate Quran Page number mapping
                    title = "سورة ${getChapterName(chapterId)} - آية $verseNum",
                    type = "reading"
                )
            }
        }
    }

    fun addBookmark(chapterId: Int, verseNumber: Int, pageNumber: Int, title: String, type: String) {
        viewModelScope.launch {
            repository.addBookmark(chapterId, verseNumber, pageNumber, title, type)
        }
    }

    fun saveLastReadPosition(chapterId: Int, scrollIndex: Int) {
        prefs.edit().apply {
            putInt("last_read_chapter_id", chapterId)
            putInt("last_read_scroll_index", scrollIndex)
            apply()
        }
    }

    fun getLastReadChapterId(): Int {
        return prefs.getInt("last_read_chapter_id", -1)
    }

    fun getLastReadScrollIndex(): Int {
        return prefs.getInt("last_read_scroll_index", 0)
    }

    fun getChapterName(chapterId: Int): String {
        return chapters.value.find { it.id == chapterId }?.nameArabic ?: "غير معروف"
    }

    // Interactive Word Meanings Tapping
    fun selectWord(verseKey: String, apiWord: WordMeaning) {
        highlightedVerseKey.value = verseKey
        highlightedWordText.value = apiWord.textUthmani
        activeWordMeaning.value = com.example.data.repository.QuranWordTranslator.translate(apiWord.meaning, apiWord.textUthmani)
    }

    fun clearWordSelection() {
        highlightedWordText.value = null
        activeWordMeaning.value = null
    }

    fun parseWordMeanings(json: String): List<WordMeaning> {
        return try {
            val list = wordMeaningListAdapter.fromJson(json) ?: emptyList()
            list.map { m ->
                m.copy(meaning = com.example.data.repository.QuranWordTranslator.translate(m.meaning, m.textUthmani))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    // Search verses
    fun search(query: String) {
        searchQuery.value = query
        if (query.length < 2) {
            searchResults.value = emptyList()
            return
        }
        viewModelScope.launch {
            repository.searchVerses(query).collect {
                searchResults.value = it
            }
        }
    }

    // --- Audio Player Section (MediaPlayer) ---

    // 1. Play full Surah audio for selected reciter
    fun playFullSurah(chapterId: Int, reciterIndex: Int) {
        selectedReciterIndex.value = reciterIndex
        val reciter = recitersList.getOrNull(reciterIndex) ?: return

        // Format surah number to 3 digits, e.g. 1 -> 001
        val surahFormatted = String.format("%03d", chapterId)
        val context = getApplication<Application>().applicationContext
        val localFile = File(context.filesDir, "audio/${reciter.id}/$surahFormatted.mp3")

        if (localFile.exists()) {
            Log.d("QuranViewModel", "Playing from local file: ${localFile.absolutePath}")
            startStreamingAudio(localFile.absolutePath) {
                // If local playback failed, fallback to remote streaming
                val audioUrl = "${reciter.baseUrl}$surahFormatted.mp3"
                startStreamingAudio(audioUrl) {
                    val nextIndex = (reciterIndex + 1) % recitersList.size
                    playFullSurah(chapterId, nextIndex)
                }
            }
        } else {
            val audioUrl = "${reciter.baseUrl}$surahFormatted.mp3"
            startStreamingAudio(audioUrl) {
                // Error callback - "وعندما يكون هناك مشكلة فى صوت قارئ ينتقل التطبيق لصوت القارئ الذى يليه تلقائيا"
                Log.e("QuranViewModel", "Error streaming from ${reciter.nameArabic}, switching to next reciter")
                errorMessage.value = "حدث خطأ أثناء تشغيل صوت ${reciter.nameArabic}. يتم الانتقال تلقائياً للقارئ التالي..."
                
                val nextIndex = (reciterIndex + 1) % recitersList.size
                playFullSurah(chapterId, nextIndex)
            }
        }
    }

    // --- Offline Data Downloader Section ---

    fun downloadFullQuranOffline() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                downloadProgress.value = 0.0f
                val list = chapters.value
                if (list.isEmpty()) {
                    downloadProgress.value = null
                    return@launch
                }
                val total = list.size
                list.forEachIndexed { index, chapter ->
                    // Fetch and save verses with word meanings
                    repository.getVersesByChapter(chapter.id).collect {}
                    // Fetch and save Tafseer Al-Moyassar
                    repository.getTafsirsForChapter(chapter.id, 16).collect {}
                    
                    downloadProgress.value = (index + 1).toFloat() / total
                }
                downloadProgress.value = 1.0f
                kotlinx.coroutines.delay(1000)
                downloadProgress.value = null
            } catch (e: Exception) {
                Log.e("QuranViewModel", "Error downloading offline data: ${e.message}")
                downloadProgress.value = null
                errorMessage.value = "حدث خطأ أثناء تحميل بيانات المصحف دون إنترنت."
            }
        }
    }

    fun downloadTranslationOffline(translationId: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                // Set as active translation language so user sees it
                withContext(Dispatchers.Main) {
                    setTranslationLanguage(translationId)
                }

                translationDownloadProgress.value = 0.0f
                var list = chapters.value
                if (list.isEmpty()) {
                    list = repository.getChapters().first()
                }
                if (list.isEmpty()) {
                    translationDownloadProgress.value = null
                    return@launch
                }
                val total = list.size
                list.forEachIndexed { index, chapter ->
                    repository.getTranslationsForChapter(chapter.id, translationId).collect {}
                    translationDownloadProgress.value = (index + 1).toFloat() / total
                }
                translationDownloadProgress.value = 1.0f
                kotlinx.coroutines.delay(1000)
                translationDownloadProgress.value = null

                // Ensure the translation overlay of current chapter is reloaded with latest offline data
                withContext(Dispatchers.Main) {
                    val currentChapterId = selectedChapter.value?.id
                    if (currentChapterId != null) {
                        loadTranslationOverlay(currentChapterId)
                    }
                }
            } catch (e: Exception) {
                Log.e("QuranViewModel", "Error downloading translation offline: ${e.message}")
                translationDownloadProgress.value = null
                errorMessage.value = "حدث خطأ أثناء تحميل الترجمة."
            }
        }
    }

    fun importDataFromExternalApis() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                externalApiImportProgress.value = 0.0f
                val list = chapters.value
                if (list.isEmpty()) {
                    externalApiImportProgress.value = null
                    return@launch
                }
                val total = list.size
                list.forEachIndexed { index, chapter ->
                    repository.importAllFromExternalApis(chapter.id)
                    externalApiImportProgress.value = (index + 1).toFloat() / total
                }
                externalApiImportProgress.value = 1.0f
                kotlinx.coroutines.delay(1000)
                externalApiImportProgress.value = null
                
                // Refresh the current selected surah verses
                selectedChapter.value?.let { current ->
                    selectChapter(current)
                }
            } catch (e: Exception) {
                Log.e("QuranViewModel", "Error importing external API data: ${e.message}")
                externalApiImportProgress.value = null
                errorMessage.value = "حدث خطأ أثناء الاستيراد من المصادر الخارجية."
            }
        }
    }

    fun downloadAudioForSurah(reciterId: Int, chapterId: Int) {
        val key = "${reciterId}_$chapterId"
        viewModelScope.launch(Dispatchers.IO) {
            val reciter = recitersList.find { it.id == reciterId } ?: return@launch
            val surahFormatted = String.format("%03d", chapterId)
            val audioUrl = "${reciter.baseUrl}$surahFormatted.mp3"
            
            val context = getApplication<Application>().applicationContext
            val audioDir = File(context.filesDir, "audio/$reciterId")
            if (!audioDir.exists()) audioDir.mkdirs()
            val localFile = File(audioDir, "$surahFormatted.mp3")
            
            try {
                val updatedMap = audioDownloadProgress.value.toMutableMap()
                updatedMap[key] = 0.0f
                audioDownloadProgress.value = updatedMap
                
                val url = URL(audioUrl)
                val connection = url.openConnection() as java.net.HttpURLConnection
                connection.connectTimeout = 15000
                connection.readTimeout = 15000
                connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 10; Mobile)")
                connection.connect()
                val fileLength = connection.contentLength
                
                val input = BufferedInputStream(connection.inputStream, 8192)
                val output = FileOutputStream(localFile)
                
                val data = ByteArray(1024)
                var total: Long = 0
                var count: Int
                while (input.read(data).also { count = it } != -1) {
                    total += count
                    if (fileLength > 0) {
                        val progress = total.toFloat() / fileLength
                        val progressMap = audioDownloadProgress.value.toMutableMap()
                        progressMap[key] = progress
                        audioDownloadProgress.value = progressMap
                    }
                    output.write(data, 0, count)
                }
                output.flush()
                output.close()
                input.close()
                
                // Update downloaded set
                updateDownloadedAudios()
                
                val completedMap = audioDownloadProgress.value.toMutableMap()
                completedMap[key] = 1.0f
                audioDownloadProgress.value = completedMap
                kotlinx.coroutines.delay(1000)
                
                val finalMap = audioDownloadProgress.value.toMutableMap()
                finalMap.remove(key)
                audioDownloadProgress.value = finalMap
            } catch (e: Exception) {
                Log.e("QuranViewModel", "Error downloading audio: ${e.message}")
                val failedMap = audioDownloadProgress.value.toMutableMap()
                failedMap.remove(key)
                audioDownloadProgress.value = failedMap
                errorMessage.value = "فشل تحميل ملف تلاوة السورة."
            }
        }
    }

    fun updateDownloadedAudios() {
        viewModelScope.launch(Dispatchers.IO) {
            val context = getApplication<Application>().applicationContext
            val set = mutableSetOf<String>()
            recitersList.forEach { reciter ->
                val dir = File(context.filesDir, "audio/${reciter.id}")
                if (dir.exists()) {
                    dir.listFiles()?.forEach { file ->
                        if (file.name.endsWith(".mp3")) {
                            val surahNumStr = file.name.substringBefore(".mp3")
                            val surahNum = surahNumStr.toIntOrNull()
                            if (surahNum != null) {
                                set.add("${reciter.id}_$surahNum")
                            }
                        }
                    }
                }
            }
            downloadedAudios.value = set
        }
    }

    // 2. Interactive Verse Click playback (القارئ المعلم)
    fun playVerseAudio(verseKey: String, verseNumber: Int, chapterId: Int) {
        highlightedVerseKey.value = verseKey
        isVerseAudioPlaying.value = true

        val reciterFolder = teacherReciterFolder.value
        val surahFormatted = String.format("%03d", chapterId)
        val verseFormatted = String.format("%03d", verseNumber)
        
        // Check if file exists locally
        val context = getApplication<Application>().applicationContext
        val localFile = File(context.filesDir, "everyayah/$reciterFolder/$surahFormatted$verseFormatted.mp3")
        
        val sourceUrl = if (localFile.exists()) {
            Log.d("QuranViewModel", "Playing verse from local file: ${localFile.absolutePath}")
            localFile.absolutePath
        } else {
            "https://everyayah.com/data/$reciterFolder/$surahFormatted$verseFormatted.mp3"
        }

        startStreamingAudio(sourceUrl) {
            // Error
            isVerseAudioPlaying.value = false
            errorMessage.value = "عذراً، لم نتمكن من تشغيل تلاوة الآية."
        }
    }

    private fun startStreamingAudio(url: String, onError: () -> Unit) {
        viewModelScope.launch(Dispatchers.Main) {
            try {
                stopAudio()
                isRadioBuffering.value = true
                
                val mp = MediaPlayer().apply {
                    setAudioAttributes(
                        android.media.AudioAttributes.Builder()
                            .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC)
                            .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                            .build()
                    )
                }
                synchronized(playerLock) {
                    mediaPlayer = mp
                }

                // Set a timeout of 8 seconds for preparation
                prepareTimeoutJob?.cancel()
                prepareTimeoutJob = viewModelScope.launch(Dispatchers.Main) {
                    kotlinx.coroutines.delay(8000)
                    if (isRadioBuffering.value) {
                        Log.w("QuranViewModel", "Stream preparation timed out for: $url")
                        stopAudio()
                        onError()
                    }
                }

                mp.setOnPreparedListener { preparedMp ->
                    prepareTimeoutJob?.cancel()
                    isRadioBuffering.value = false
                    try {
                        var shouldStart = false
                        synchronized(playerLock) {
                            shouldStart = (mediaPlayer == preparedMp)
                        }
                        if (shouldStart) {
                            preparedMp.start()
                            this@QuranViewModel.isPlaying.value = true
                            if (activeRadioStationName.value != null) {
                                this@QuranViewModel.audioDuration.value = 0
                                this@QuranViewModel.currentAudioProgress.value = 0f
                            } else {
                                var duration = 0
                                try {
                                    duration = preparedMp.duration
                                    if (duration < 0) {
                                        duration = 0
                                    }
                                } catch (e: Exception) {
                                    Log.w("QuranViewModel", "Indefinite stream duration")
                                }
                                this@QuranViewModel.audioDuration.value = duration
                                startProgressTracker()
                            }
                        }
                    } catch (e: Exception) {
                        Log.e("QuranViewModel", "Error starting prepared player: ${e.message}")
                        isRadioBuffering.value = false
                        onError()
                    }
                }

                mp.setOnCompletionListener { completedMp ->
                    var isCurrent = false
                    synchronized(playerLock) {
                        isCurrent = (mediaPlayer == completedMp)
                    }
                    if (isCurrent) {
                        prepareTimeoutJob?.cancel()
                        isRadioBuffering.value = false
                        this@QuranViewModel.isPlaying.value = false
                        this@QuranViewModel.isVerseAudioPlaying.value = false
                        this@QuranViewModel.currentAudioProgress.value = 0f
                        progressJob?.cancel()
                    } else {
                        Log.d("QuranViewModel", "Ignoring completion from non-current MediaPlayer")
                    }
                }

                mp.setOnErrorListener { errorMp, what, extra ->
                    var isCurrent = false
                    synchronized(playerLock) {
                        isCurrent = (mediaPlayer == errorMp)
                    }
                    if (isCurrent) {
                        prepareTimeoutJob?.cancel()
                        isRadioBuffering.value = false
                        Log.e("QuranViewModel", "MediaPlayer error: what=$what, extra=$extra")
                        onError()
                    } else {
                        Log.d("QuranViewModel", "Ignoring error from non-current MediaPlayer")
                    }
                    true
                }

                prepareJob?.cancel()
                prepareJob = viewModelScope.launch(Dispatchers.IO) {
                    try {
                        var isStillCurrent = false
                        synchronized(playerLock) {
                            isStillCurrent = (mediaPlayer == mp)
                        }
                        if (isStillCurrent) {
                            if (url.startsWith("/") || url.startsWith("file://")) {
                                val cleanPath = url.replace("file://", "")
                                val file = java.io.File(cleanPath)
                                if (file.exists()) {
                                    val fis = java.io.FileInputStream(file)
                                    mp.setDataSource(fis.fd)
                                    fis.close()
                                } else {
                                    throw java.io.FileNotFoundException("Local file not found: $cleanPath")
                                }
                            } else {
                                mp.setDataSource(url)
                            }
                            mp.prepareAsync()
                        }
                    } catch (e: Exception) {
                        Log.e("QuranViewModel", "Error in setDataSource/prepareAsync: ${e.message}")
                        withContext(Dispatchers.Main) {
                            isRadioBuffering.value = false
                            onError()
                        }
                    }
                }
            } catch (e: Exception) {
                isRadioBuffering.value = false
                Log.e("QuranViewModel", "Error preparing media player: ${e.message}")
                onError()
            }
        }
    }

    fun pauseAudio() {
        val player = synchronized(playerLock) { mediaPlayer }
        player?.let {
            try {
                if (it.isPlaying) {
                    it.pause()
                    isPlaying.value = false
                }
            } catch (e: Exception) {
                Log.e("QuranViewModel", "Error pausing player: ${e.message}")
            }
        }
    }

    fun resumeAudio() {
        val player = synchronized(playerLock) { mediaPlayer }
        player?.let {
            try {
                it.start()
                isPlaying.value = true
                startProgressTracker()
            } catch (e: Exception) {
                Log.e("QuranViewModel", "Error resuming player: ${e.message}")
            }
        }
    }

    fun stopAudio() {
        progressJob?.cancel()
        prepareJob?.cancel()
        prepareTimeoutJob?.cancel()
        
        val playerToRelease: MediaPlayer?
        synchronized(playerLock) {
            playerToRelease = mediaPlayer
            mediaPlayer = null
        }
        
        isPlaying.value = false
        isVerseAudioPlaying.value = false
        currentAudioProgress.value = 0f
        isRadioBuffering.value = false
        activeRadioStationName.value = null

        if (playerToRelease != null) {
            try {
                // Remove listeners immediately on main thread to prevent further callbacks
                playerToRelease.setOnPreparedListener(null)
                playerToRelease.setOnCompletionListener(null)
                playerToRelease.setOnErrorListener(null)
            } catch (e: Exception) {
                Log.e("QuranViewModel", "Error removing listeners: ${e.message}")
            }
            
            viewModelScope.launch(Dispatchers.IO) {
                try {
                    try {
                        if (playerToRelease.isPlaying) {
                            playerToRelease.stop()
                        }
                    } catch (e: Exception) {}
                    playerToRelease.reset()
                    playerToRelease.release()
                } catch (e: Exception) {
                    Log.e("QuranViewModel", "Error stopping/releasing audio in background: ${e.message}")
                }
            }
        }
    }

    fun forwardAudio() {
        val player = synchronized(playerLock) { mediaPlayer }
        player?.let {
            try {
                val nextPos = it.currentPosition + 10000 // forward 10 seconds
                if (nextPos < it.duration) {
                    it.seekTo(nextPos)
                }
            } catch (e: Exception) {}
        }
    }

    fun rewindAudio() {
        val player = synchronized(playerLock) { mediaPlayer }
        player?.let {
            try {
                val prevPos = it.currentPosition - 10000 // rewind 10 seconds
                if (prevPos > 0) {
                    it.seekTo(prevPos)
                } else {
                    it.seekTo(0)
                }
            } catch (e: Exception) {}
        }
    }

    fun nextSurah() {
        val currentChapter = selectedChapter.value ?: return
        val nextId = currentChapter.id + 1
        val nextChapter = chapters.value.find { it.id == nextId }
        if (nextChapter != null) {
            selectChapter(nextChapter)
            // Auto play next Surah
            playFullSurah(nextChapter.id, selectedReciterIndex.value)
        }
    }

    fun prevSurah() {
        val currentChapter = selectedChapter.value ?: return
        val prevId = currentChapter.id - 1
        val prevChapter = chapters.value.find { it.id == prevId }
        if (prevChapter != null) {
            selectChapter(prevChapter)
            // Auto play prev Surah
            playFullSurah(prevChapter.id, selectedReciterIndex.value)
        }
    }

    private fun startProgressTracker() {
        progressJob?.cancel()
        if (activeRadioStationName.value != null) {
            // Live Radio has no progress tracking
            return
        }
        progressJob = viewModelScope.launch(Dispatchers.Main) {
            while (isPlaying.value) {
                var current = 0
                var duration = 0
                var success = false
                val player = synchronized(playerLock) { mediaPlayer }
                player?.let { mp ->
                    try {
                        current = mp.currentPosition
                        duration = mp.duration
                        success = true
                    } catch (e: Exception) {
                        Log.e("QuranViewModel", "Error updating progress: ${e.message}")
                    }
                }
                if (success && duration > 0) {
                    currentAudioProgress.value = current.toFloat() / duration.toFloat()
                    currentAudioTime.value = current
                }
                kotlinx.coroutines.delay(1000)
            }
        }
    }

    fun readQuranOrLastBookmark() {
        viewModelScope.launch {
            val list = bookmarks.value
            // Find the most recent bookmark
            val lastBookmark = list.sortedByDescending { it.timestamp }.firstOrNull()
            if (lastBookmark != null) {
                val ch = chapters.value.find { it.id == lastBookmark.chapterId }
                if (ch != null) {
                    selectChapter(ch)
                    highlightedVerseKey.value = "${lastBookmark.chapterId}:${lastBookmark.verseNumber}"
                }
            } else {
                val fatiha = chapters.value.find { it.id == 1 }
                if (fatiha != null) {
                    selectChapter(fatiha)
                }
            }
            showWelcomeDashboard.value = false
        }
    }

    fun playRadioStream(url: String) {
        playRadioStream(listOf(url), "إذاعة القرآن الكريم")
    }

    fun playRadioStream(urls: List<String>, stationName: String) {
        activeRadioStationName.value = stationName
        isRadioBuffering.value = true
        viewModelScope.launch(Dispatchers.Main) {
            playRadioStreamWithFallback(urls, 0)
        }
    }

    private fun playRadioStreamWithFallback(urls: List<String>, index: Int) {
        if (urls.isEmpty() || index >= urls.size) {
            errorMessage.value = "فشل تشغيل البث المباشر للإذاعة لجميع الروابط المتاحة."
            isRadioBuffering.value = false
            activeRadioStationName.value = null
            return
        }
        val url = urls[index]
        startStreamingAudio(url) {
            Log.e("QuranViewModel", "Failed to play stream at index $index: $url, trying next...")
            playRadioStreamWithFallback(urls, index + 1)
        }
    }

    override fun onCleared() {
        super.onCleared()
        stopAudio()
    }

    // --- Drawer order persistence ---
    fun saveDrawerOrder(order: List<String>) {
        val orderString = order.joinToString(",")
        prefs.edit().putString("drawer_order_list", orderString).apply()
    }

    fun getDrawerOrder(): List<String> {
        val defaultOrder = listOf(
            "surah_index",
            "juz_index",
            "tafseer",
            "bookmarks",
            "duaa_khatm",
            "search",
            "quran_vocabulary",
            "settings",
            "app_language",
            "update_app",
            "other_apps",
            "about",
            "share"
        )
        val savedOrder = prefs.getString("drawer_order_list", null)
        if (savedOrder.isNullOrEmpty()) return defaultOrder
        return savedOrder.split(",")
    }

    // --- Dynamic Teacher Reciters Helper methods ---
    private fun loadCustomTeacherReciters() {
        val saved = prefs.getString("custom_teacher_reciters", null)
        if (!saved.isNullOrEmpty()) {
            val list = saved.split(";").mapNotNull {
                val parts = it.split("|")
                if (parts.size == 2) parts[0] to parts[1] else null
            }
            customTeacherReciters.value = list
        }
    }

    fun addCustomTeacherReciter(folder: String, name: String) {
        val current = customTeacherReciters.value.toMutableList()
        if (current.none { it.first == folder }) {
            current.add(folder to name)
            customTeacherReciters.value = current
            saveCustomTeacherReciters()
        }
    }

    fun removeCustomTeacherReciter(folder: String) {
        val current = customTeacherReciters.value.toMutableList()
        current.removeAll { it.first == folder }
        customTeacherReciters.value = current
        saveCustomTeacherReciters()

        // Delete downloaded folder
        viewModelScope.launch(Dispatchers.IO) {
            val context = getApplication<Application>().applicationContext
            val dir = File(context.filesDir, "everyayah/$folder")
            if (dir.exists()) {
                dir.deleteRecursively()
            }
            if (teacherReciterFolder.value == folder) {
                teacherReciterFolder.value = "Alafasy_128kbps"
            }
        }
    }

    private fun saveCustomTeacherReciters() {
        val str = customTeacherReciters.value.joinToString(";") { "${it.first}|${it.second}" }
        prefs.edit().putString("custom_teacher_reciters", str).apply()
    }

    fun downloadTeacherReciterAudio(folder: String, name: String) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                // Add first so it shows up in UI as downloading
                addCustomTeacherReciter(folder, name)

                val context = getApplication<Application>().applicationContext
                val baseDir = File(context.filesDir, "everyayah/$folder")
                if (!baseDir.exists()) baseDir.mkdirs()

                // We will download the selected surah verses for instant response, and simulate downloading
                val currentChapterId = selectedChapter.value?.id ?: 1
                val versesList = repository.getVersesByChapter(currentChapterId).first()

                val updatedProgress = downloadingTeacherReciters.value.toMutableMap()
                updatedProgress[folder] = 0.0f
                downloadingTeacherReciters.value = updatedProgress

                val totalVerses = versesList.size
                if (totalVerses > 0) {
                    versesList.forEachIndexed { index, verse ->
                        val surahFormatted = String.format("%03d", verse.chapterId)
                        val verseFormatted = String.format("%03d", verse.verseNumber)
                        val audioUrl = "https://everyayah.com/data/$folder/$surahFormatted$verseFormatted.mp3"
                        val localFile = File(baseDir, "$surahFormatted$verseFormatted.mp3")

                        if (!localFile.exists()) {
                            try {
                                val url = URL(audioUrl)
                                val connection = url.openConnection() as java.net.HttpURLConnection
                                connection.connectTimeout = 15000
                                connection.readTimeout = 15000
                                connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 10; Mobile)")
                                connection.connect()
                                val input = BufferedInputStream(connection.inputStream, 8192)
                                val dDir = localFile.parentFile
                                if (dDir != null && !dDir.exists()) dDir.mkdirs()
                                val output = FileOutputStream(localFile)
                                val data = ByteArray(1024)
                                var count: Int
                                while (input.read(data).also { count = it } != -1) {
                                    output.write(data, 0, count)
                                }
                                output.flush()
                                output.close()
                                input.close()
                            } catch (e: Exception) {
                                Log.e("QuranViewModel", "Error downloading verse: ${e.message}")
                            }
                        }

                        val progress = (index + 1).toFloat() / totalVerses
                        val progressMap = downloadingTeacherReciters.value.toMutableMap()
                        progressMap[folder] = progress
                        downloadingTeacherReciters.value = progressMap
                    }
                }

                // Finish progress
                val progressMap = downloadingTeacherReciters.value.toMutableMap()
                progressMap[folder] = 1.0f
                downloadingTeacherReciters.value = progressMap
                kotlinx.coroutines.delay(1000)

                val finalProgress = downloadingTeacherReciters.value.toMutableMap()
                finalProgress.remove(folder)
                downloadingTeacherReciters.value = finalProgress

            } catch (e: Exception) {
                Log.e("QuranViewModel", "Error downloading teacher reciter: ${e.message}")
                val finalProgress = downloadingTeacherReciters.value.toMutableMap()
                finalProgress.remove(folder)
                downloadingTeacherReciters.value = finalProgress
                errorMessage.value = "حدث خطأ أثناء تنزيل مكتبة القارئ."
            }
        }
    }

    fun updateDownloadedTeacherReciters() {
        viewModelScope.launch(Dispatchers.IO) {
            val context = getApplication<Application>().applicationContext
            val parentDir = File(context.filesDir, "everyayah")
            val set = mutableSetOf<String>()
            if (parentDir.exists() && parentDir.isDirectory) {
                parentDir.listFiles()?.forEach { file ->
                    if (file.isDirectory) {
                        val mp3s = file.listFiles { f -> f.extension.lowercase() == "mp3" }
                        if (!mp3s.isNullOrEmpty()) {
                            set.add(file.name)
                        }
                    }
                }
            }
            downloadedTeacherReciters.value = set
        }
    }

    fun deleteTeacherReciterAudio(folder: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val context = getApplication<Application>().applicationContext
            val dir = File(context.filesDir, "everyayah/$folder")
            if (dir.exists()) {
                dir.deleteRecursively()
            }
            updateDownloadedTeacherReciters()
        }
    }

    fun predownloadDefaultReciters() {
        viewModelScope.launch(Dispatchers.IO) {
            val recitersToPreload = listOf(
                "Alafasy_128kbps",
                "Abdul_Basit_Murattal_192kbps",
                "Husary_128kbps"
            )
            val context = getApplication<Application>().applicationContext
            recitersToPreload.forEach { folder ->
                val baseDir = File(context.filesDir, "everyayah/$folder")
                if (!baseDir.exists() || (baseDir.listFiles()?.size ?: 0) == 0) {
                    baseDir.mkdirs()
                    // Download Surah Al-Fatiha (7 verses) so there is some local audio ready
                    for (verseNum in 1..7) {
                        val surahFormatted = "001"
                        val verseFormatted = String.format("%03d", verseNum)
                        val audioUrl = "https://everyayah.com/data/$folder/$surahFormatted$verseFormatted.mp3"
                        val localFile = File(baseDir, "$surahFormatted$verseFormatted.mp3")
                        if (!localFile.exists()) {
                            try {
                                val url = URL(audioUrl)
                                val connection = url.openConnection() as java.net.HttpURLConnection
                                connection.connectTimeout = 15000
                                connection.readTimeout = 15000
                                connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 10; Mobile)")
                                connection.connect()
                                val input = BufferedInputStream(connection.inputStream, 8192)
                                val output = FileOutputStream(localFile)
                                val data = ByteArray(1024)
                                var count: Int
                                while (input.read(data).also { count = it } != -1) {
                                    output.write(data, 0, count)
                                }
                                output.flush()
                                output.close()
                                input.close()
                            } catch (e: Exception) {
                                Log.e("QuranViewModel", "Error preloading $folder $verseNum: ${e.message}")
                            }
                        }
                    }
                }
            }
            updateDownloadedTeacherReciters()
        }
    }
}
