package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Luxury Theme Colors
val LightGoldPrimary = Color(0xFFC59B27) // Rich Gold
val LightGoldSecondary = Color(0xFF8C7335)
val LightGoldBackground = Color(0xFFFAF6F0) // Warm Ivory/Cream
val LightGoldSurface = Color(0xFFFFFDF9)
val LightGoldText = Color.Black

// Dark Luxury Theme Colors
val DarkGoldPrimary = Color(0xFFD4AF37) // Golden Accent from Elegant Dark
val DarkGoldSecondary = Color(0xFF8C7335)
val DarkGoldBackground = Color(0xFF0D0D0D) // Very deep black/dark obsidian from Elegant Dark
val DarkGoldSurface = Color(0xFF1A1A1A) // Elegant dark surface card/header bg
val DarkGoldText = Color(0xFFE0E0E0) // Elegant light gray text

// General Colors
val AccentRed = Color(0xFFD32F2F)   // For "Allah" in light mode, words meaning highlights
val AccentGreen = Color(0xFF388E3C) // For "Allah" in dark mode, clicked verse highlights
val GoldAccent = Color(0xFFFFD700)
val DarkGray = Color(0xFF424242)
val LightGray = Color(0xFFE0E0E0)
