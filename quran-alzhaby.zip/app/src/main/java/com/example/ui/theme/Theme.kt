package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = DarkGoldPrimary,
    secondary = DarkGoldSecondary,
    background = DarkGoldBackground,
    surface = DarkGoldSurface,
    onPrimary = DarkGoldBackground,
    onSecondary = DarkGoldBackground,
    onBackground = DarkGoldText,
    onSurface = DarkGoldText
)

private val LightColorScheme = lightColorScheme(
    primary = LightGoldPrimary,
    secondary = LightGoldSecondary,
    background = LightGoldBackground,
    surface = LightGoldSurface,
    onPrimary = LightGoldBackground,
    onSecondary = LightGoldBackground,
    onBackground = LightGoldText,
    onSurface = LightGoldText
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
