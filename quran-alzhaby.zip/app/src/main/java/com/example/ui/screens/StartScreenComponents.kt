package com.example.ui.screens

import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import com.example.R
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.db.ChapterEntity
import com.example.data.db.VerseEntity
import com.example.data.db.WordMeaning
import com.example.ui.theme.*
import com.example.ui.viewmodel.QuranViewModel
import com.example.ui.viewmodel.recitersList
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay

// Dynamic language translation manager
fun getAppString(key: String, lang: String): String {
    val translations = mapOf(
        "ar" to mapOf(
            "surah_index" to "فهرس السور الكريمة",
            "juz_index" to "الفهرس بالأجزاء والأحزاب",
            "tafseer_page" to "التفسير وأسباب النزول",
            "bookmarks" to "علامات القراءة والحفظ ومكان التوقف",
            "duaa" to "دعاء ختم القرآن الكريم",
            "search" to "بحث بالكلمات والآيات",
            "share" to "مشاركة التطبيق للثواب والخير",
            "update" to "تحديث التطبيق",
            "other_apps" to "تطبيقات أخرى",
            "about" to "حول التطبيق",
            "vocabulary" to "معاني المفردات",
            "easy_tafseer" to "التفسير الميسر",
            "settings" to "إعدادات المظهر وتخصيص القراءة",
            "translations" to "الترجمات",
            "teacher_mode" to "وضع المعلم",
            "hadith" to "من أقوال النبي صلى الله عليه وسلم",
            "listen" to "استمع إلى القرآن الكريم",
            "azkar" to "أذكار وأدعية",
            "radio" to "إذاعة القرآن الكريم",
            "sermons" to "خطب ومواعظ",
            "read_learn" to "اقرأ وتعلم القرآن الكريم",
            "app_language" to "لغة التطبيق",
            "app_title" to "القرآن الكريم الذهبي",
            "read_learn_sub" to "اقرأ وتعلم واستمع إلى كلمات الله",
            "close" to "إغلاق",
            "loading" to "جاري التحميل...",
            "back" to "رجوع",
            "play" to "تشغيل",
            "pause" to "إيقاف مؤقت",
            "reciters" to "القراء",
            "dark_mode" to "الوضع الداكن (الليل)",
            "text_size" to "حجم خط الآيات والكلمات",
            "brightness_control" to "درجة سطوع وإعتام الشاشة",
            "teacher_reciter" to "القارئ المعلم تكرار الآية",
            "offline_download" to "تحميل المحتوى للاستخدام دون اتصال بالإنترنت",
            "download_tafseer" to "تنزيل كتاب التفسير الميسر ومعاني الكلمات",
            "download_translation" to "تنزيل نصوص الترجمة المختارة كاملاً",
            "external_api" to "مزامنة واستيراد نصوص وتفسير من مصادر خارجية",
            "import_external" to "استيراد وتحديث من المصادر الخارجية",
            "save_confirm" to "موافق وتأكيد الحفظ",
            // New UI keys
            "app_name" to "القرآن الكريم الذهبي",
            "tafseer" to "التفسير الميسر",
            "duaa_khatm" to "دعاء ختم القرآن الكريم",
            "quran_vocabulary" to "معاني المفردات",
            "update_app" to "تحديث التطبيق",
            "under_development" to "هذه الميزة قيد التطوير حالياً، انتظرونا قريباً!",
            // App Support strings
            "support_app" to "دعم التطبيق",
            "report_issue" to "إبلاغ عن مشكلة في التطبيق عبر الواتساب",
            "contribute_goodness" to "ساهم في الخير",
            "contact_us" to "تواصل معنا لإنشاء تطبيقك المفضل",
            "charity_msg" to "التطبيق صدقة جارية شارك وادعم المطورين تم إنشاء وتطوير التطبيق بواسطة م:علاء عز",
            "instapay" to "انستباي",
            "bank" to "بنك",
            "instapay_title" to "دعم عبر انستباي",
            "bank_title" to "دعم عبر الحساب البنكي",
            "copy" to "نسخ",
            "copied" to "تم النسخ بنجاح!",
            "name" to "الاسم",
            "iban" to "الأيبان",
            "swift_code" to "السويفت كود"
        ),
        "en" to mapOf(
            "surah_index" to "Surah Index",
            "juz_index" to "Juz & Hizb Index",
            "tafseer_page" to "Tafseer & Revelation",
            "bookmarks" to "Bookmarks & Reading Marks",
            "duaa" to "Duaa of Quran Completion",
            "search" to "Search Words & Verses",
            "share" to "Share Application",
            "update" to "Update App",
            "other_apps" to "Other Apps",
            "about" to "About App",
            "vocabulary" to "Vocabulary Meanings",
            "easy_tafseer" to "Easy Tafseer",
            "settings" to "Appearance & Reading Customization",
            "translations" to "Translations",
            "teacher_mode" to "Teacher Mode",
            "hadith" to "Sayings of the Prophet (PBUH)",
            "listen" to "Listen to the Holy Quran",
            "azkar" to "Azkar & Supplications",
            "radio" to "Holy Quran Radio",
            "sermons" to "Sermons & Lectures",
            "read_learn" to "Read & Learn Holy Quran",
            "app_language" to "App Language",
            "app_title" to "The Golden Holy Quran",
            "read_learn_sub" to "Read, learn, and listen to the words of Allah",
            "close" to "Close",
            "loading" to "Loading...",
            "back" to "Back",
            "play" to "Play",
            "pause" to "Pause",
            "reciters" to "Reciters",
            "dark_mode" to "Dark Mode (Night)",
            "text_size" to "Verse & Word Text Size",
            "brightness_control" to "Screen Brightness & Dimming",
            "teacher_reciter" to "Teacher Reciter Verse Repeat",
            "offline_download" to "Download Content for Offline Use",
            "download_tafseer" to "Download Easy Tafsir & Word Meanings",
            "download_translation" to "Download Selected Translation Texts",
            "external_api" to "Sync & Import from External Sources",
            "import_external" to "Import & Update from External Sources",
            "save_confirm" to "OK & Confirm Save",
            // New UI keys
            "app_name" to "The Golden Holy Quran",
            "tafseer" to "Easy Tafseer",
            "duaa_khatm" to "Completion Supplication",
            "quran_vocabulary" to "Quranic Vocabulary",
            "update_app" to "Update Application",
            "under_development" to "This feature is under development, coming soon!",
            // App Support strings
            "support_app" to "Support App",
            "report_issue" to "Report a problem via WhatsApp",
            "contribute_goodness" to "Contribute to Goodness",
            "contact_us" to "Contact Us",
            "charity_msg" to "The app is an ongoing charity (Sadaqah Jariyah). Share and support the developers - create your own app",
            "instapay" to "Instapay",
            "bank" to "Bank",
            "instapay_title" to "Support via Instapay",
            "bank_title" to "Support via Bank Account",
            "copy" to "Copy",
            "copied" to "Copied successfully!",
            "name" to "Name",
            "iban" to "IBAN",
            "swift_code" to "Swift Code"
        ),
        "fr" to mapOf(
            "surah_index" to "Index des Sourates",
            "juz_index" to "Index des Juz & Hizb",
            "tafseer_page" to "Tafsir & Révélation",
            "bookmarks" to "Signets & Marques de Lecture",
            "duaa" to "Douaa de fin du Coran",
            "search" to "Rechercher des Mots & Versets",
            "share" to "Partager l'Application",
            "update" to "Mettre à Jour l'App",
            "other_apps" to "Autres Applications",
            "about" to "À propos de l'App",
            "vocabulary" to "Vocabulaire du Coran",
            "easy_tafseer" to "Tafsir Facile",
            "settings" to "Apparence & Lecture personnalisée",
            "translations" to "Traductions",
            "teacher_mode" to "Mode Enseignant",
            "hadith" to "Paroles du Prophète (PSL)",
            "listen" to "Écouter le Saint Coran",
            "azkar" to "Invocations & Azkar",
            "radio" to "Radio du Saint Coran",
            "sermons" to "Sermons & Conférences",
            "read_learn" to "Lire & Apprendre le Coran",
            "app_language" to "Langue de l'Application",
            "app_title" to "Le Coran Doré",
            "read_learn_sub" to "Lisez, apprenez et écoutez les paroles d'Allah",
            "close" to "Fermer",
            "loading" to "Chargement...",
            "back" to "Retour",
            "play" to "Jouer",
            "pause" to "Pause",
            "reciters" to "Récitateurs",
            "dark_mode" to "Mode Sombre (Nuit)",
            "text_size" to "Taille du Texte des Versets",
            "brightness_control" to "Luminosité & Assombrissement",
            "teacher_reciter" to "Récitateur Enseignant (Répétition)",
            "offline_download" to "Télécharger le Contenu Hors Ligne",
            "download_tafseer" to "Télécharger le Tafsir Facile & Vocabulaire",
            "download_translation" to "Télécharger le Texte de Traduction Sélectionné",
            "external_api" to "Sync & Importer des Sources Externes",
            "import_external" to "Importer & Mettre à jour des APIs",
            "save_confirm" to "OK & Confirmer la Sauvegarde",
            // New UI keys
            "app_name" to "Le Coran Doré",
            "tafseer" to "Tafsir Facile",
            "duaa_khatm" to "Douaa de fin du Coran",
            "quran_vocabulary" to "Vocabulaire du Coran",
            "update_app" to "Mettre à jour l'application",
            "under_development" to "Cette fonctionnalité est en cours de développement, bientôt disponible!",
            // App Support strings
            "support_app" to "Soutenir l'App",
            "report_issue" to "Signaler un problème via WhatsApp",
            "contribute_goodness" to "Contribuer au Bien",
            "contact_us" to "Contactez-nous",
            "charity_msg" to "L'application est une aumône continue. Partagez et soutenez les développeurs - créez votre propre application",
            "instapay" to "Instapay",
            "bank" to "Banque",
            "instapay_title" to "Soutien via Instapay",
            "bank_title" to "Soutien via Compte Bancaire",
            "copy" to "Copier",
            "copied" to "Copié avec succès !",
            "name" to "Nom",
            "iban" to "IBAN",
            "swift_code" to "Code Swift"
        ),
        "es" to mapOf(
            "surah_index" to "Índice de Suras",
            "juz_index" to "Índice de Juz & Hizb",
            "tafseer_page" to "Tafsir y Revelación",
            "bookmarks" to "Marcadores de Lectura",
            "duaa" to "Duaa de Conclusión del Corán",
            "search" to "Buscar Palabras y Versículos",
            "share" to "Compartir Aplicación",
            "update" to "Actualizar Aplicación",
            "other_apps" to "Otras Aplicaciones",
            "about" to "Acerca de la Aplicación",
            "vocabulary" to "Vocabulario del Corán",
            "easy_tafseer" to "Tafsir Fácil",
            "settings" to "Personalización de Apariencia",
            "translations" to "Traducciones",
            "teacher_mode" to "Modo Profesor",
            "hadith" to "Dichos del Profeta (BPD)",
            "listen" to "Escuchar el Sagrado Corán",
            "azkar" to "Súplicas y Azkar",
            "radio" to "Radio del Sagrado Corán",
            "sermons" to "Sermones y Conferencias",
            "read_learn" to "Leer y Aprender el Corán",
            "app_language" to "Idioma de la Aplicación",
            "app_title" to "El Corán de Oro",
            "read_learn_sub" to "Lee, aprende y escucha las palabras de Alá",
            "close" to "Cerrar",
            "loading" to "Cargando...",
            "back" to "Atrás",
            "play" to "Reproducir",
            "pause" to "Pausa",
            "reciters" to "Recitadores",
            "dark_mode" to "Modo Oscuro (Noche)",
            "text_size" to "Tamaño de Letra de Versículos",
            "brightness_control" to "Brillo y Atenuación de Pantalla",
            "teacher_reciter" to "Recitador de Profesor (Repetición)",
            "offline_download" to "Descargar Contenido Fuera de Línea",
            "download_tafseer" to "Descargar Tafsir Fácil y Vocabulario",
            "download_translation" to "Descargar Texto de Traducción Elegido",
            "external_api" to "Sincronizar e Importar de Fuentes Externas",
            "import_external" to "Importar y Actualizar de APIs",
            "save_confirm" to "Aceptar y Confirmar",
            // New UI keys
            "app_name" to "El Corán de Oro",
            "tafseer" to "Tafsir Fácil",
            "duaa_khatm" to "Súplica de Conclusión",
            "quran_vocabulary" to "Vocabulario del Corán",
            "update_app" to "Actualizar Aplicación",
            "under_development" to "Esta función está en desarrollo, próximamente!",
            // App Support strings
            "support_app" to "Apoyar la App",
            "report_issue" to "Reportar un problema por WhatsApp",
            "contribute_goodness" to "Contribuir al Bien",
            "contact_us" to "Contáctenos",
            "charity_msg" to "La aplicación es una caridad continua. Comparte y apoya a los desarrolladores - crea tu propia aplicación",
            "instapay" to "Instapay",
            "bank" to "Banco",
            "instapay_title" to "Soporte vía Instapay",
            "bank_title" to "Soporte vía Cuenta Bancaria",
            "copy" to "Copiar",
            "copied" to "¡Copiado con éxito!",
            "name" to "Nombre",
            "iban" to "IBAN",
            "swift_code" to "Código Swift"
        ),
        "tr" to mapOf(
            "surah_index" to "Sure İndeksi",
            "juz_index" to "Cüz ve Hizb İndeksi",
            "tafseer_page" to "Tefsir ve Nüzul Sebepleri",
            "bookmarks" to "Kitap Ayracı & Kaldığı Yer",
            "duaa" to "Hatim Duası",
            "search" to "Kelime ve Ayet Ara",
            "share" to "Uygulamayı Paylaş",
            "update" to "Uygulamayı Güncelle",
            "other_apps" to "Diğer Uygulamalar",
            "about" to "Uygulama Hakkında",
            "vocabulary" to "Kuran Kelime Mealleri",
            "easy_tafseer" to "Kolay Tefsir",
            "settings" to "Görünüm & Okuma Özelleştirme",
            "translations" to "Mealler",
            "teacher_mode" to "Muallim Modu",
            "hadith" to "Peygamber Efendimizin Hadisleri",
            "listen" to "Kuran-ı Kerim Dinle",
            "azkar" to "Dualar ve Zikirler",
            "radio" to "Kuran-ı Kerim Radyosu",
            "sermons" to "Hutbeler ve Sohbetler",
            "read_learn" to "Kuran Oku ve Öğren",
            "app_language" to "Uygulama Dili",
            "app_title" to "Altın Kuran-ı Kerim",
            "read_learn_sub" to "Allah'ın kelamını okuyun, öğrenin ve dinleyin",
            "close" to "Kapat",
            "loading" to "Yükleniyor...",
            "back" to "Geri",
            "play" to "Oynat",
            "pause" to "Duraklat",
            "reciters" to "Hafızlar",
            "dark_mode" to "Karanlık Mod (Gece)",
            "text_size" to "Ayet ve Kelime Yazı Boyutu",
            "brightness_control" to "Ekran Parlaklığı ve Karartma",
            "teacher_reciter" to "Muallim Hafız Ayet Tekrarı",
            "offline_download" to "Çevrimdışı Kullanım İçin İndir",
            "download_tafseer" to "Kolay Tefsir ve Kelime Meallerini İndir",
            "download_translation" to "Seçilen Meal Metinlerini İndir",
            "external_api" to "Harici Kaynaklardan Eşitle ve İçe Aktar",
            "import_external" to "Harici API'lerden İçe Aktar ve Güncelle",
            "save_confirm" to "Tamam ve Kaydet",
            // New UI keys
            "app_name" to "Altın Kuran-ı Kerim",
            "tafseer" to "Kolay Tefsir",
            "duaa_khatm" to "Hatim Duası",
            "quran_vocabulary" to "Kuran Kelime Mealleri",
            "update_app" to "Uygulamayı Güncelle",
            "under_development" to "Bu özellik geliştirilmektedir, yakında gelecek!",
            // App Support strings
            "support_app" to "Uygulamayı Destekle",
            "report_issue" to "WhatsApp üzerinden sorun bildir",
            "contribute_goodness" to "Hayra Katkıda Bulun",
            "contact_us" to "Bize Ulaşın",
            "charity_msg" to "Uygulama devam eden bir sadakadır. Paylaşın ve geliştiricileri destekleyin - kendi uygulamanızı oluşturun",
            "instapay" to "Instapay",
            "bank" to "Banka",
            "instapay_title" to "Instapay ile Destek",
            "bank_title" to "Banka Hesabı ile Destek",
            "copy" to "Kopyala",
            "copied" to "Başarıyla kopyalandı!",
            "name" to "İsim",
            "iban" to "IBAN",
            "swift_code" to "Swift Kodu"
        ),
        "ur" to mapOf(
            "surah_index" to "سورتوں کا انڈیکس",
            "juz_index" to "پارہ اور حزب انڈیکس",
            "tafseer_page" to "تفسیر اور نزول کے اسباب",
            "bookmarks" to "بک مارکس اور نشانات",
            "duaa" to "ختم قرآن کی دعا",
            "search" to "الفاظ اور آیات کی تلاش",
            "share" to "ثواب کے لیے ایپ شیئر کریں",
            "update" to "ایپ اپ ڈیٹ کریں",
            "other_apps" to "دیگر ایپس",
            "about" to "ایپ کے بارے میں",
            "vocabulary" to "قرآنی الفاظ کے معانی",
            "easy_tafseer" to "آسان تفسیر",
            "settings" to "ظاہری شکل اور قرآنی تخصیص",
            "translations" to "تراجم",
            "teacher_mode" to "معلم موڈ",
            "hadith" to "احادیث نبوی (ص)",
            "listen" to "تلاوت قرآن سنیں",
            "azkar" to "اذکار اور دعائیں",
            "radio" to "قرآن ریڈیو",
            "sermons" to "خطبات اور بیانات",
            "read_learn" to "قرآن پڑھیں اور سیکھیں",
            "app_language" to "ایپ کی زبان",
            "app_title" to "سنहरी قرآن مجید",
            "read_learn_sub" to "اللہ کے کلام کو پڑھیں، سیکھیں اور سنیں",
            "close" to "بند کریں",
            "loading" to "لوڈ ہو رہا ہے...",
            "back" to "واپس",
            "play" to "چلائیں",
            "pause" to "روکیں",
            "reciters" to "قراء",
            "dark_mode" to "ڈارک موڈ (رات)",
            "text_size" to "آیات اور الفاظ کا سائز",
            "brightness_control" to "اسکرین کی چمک اور مدہم پن",
            "teacher_reciter" to "معلم قاری آیت دهرائیں",
            "offline_download" to "آف لائن استعمال کے لیے مواد ڈاؤن لوڈ کریں",
            "download_tafseer" to "آسان تفسیر اور الفاظ کے معانی ڈاؤن لوڈ کریں",
            "download_translation" to "منتخب کردہ ترجمہ ڈاؤن لوڈ کریں",
            "external_api" to "بیرونی ذرائع سے مطابقت پذیری کریں",
            "import_external" to "بیرونی ذرائع سے درآمد اور اپ ڈیٹ کریں",
            "save_confirm" to "ٹھیک ہے اور محفوظ کریں",
            // New UI keys
            "app_name" to "سنहरी قرآن مجید",
            "tafseer" to "آسان تفسیر",
            "duaa_khatm" to "ختم قرآن کی دعا",
            "quran_vocabulary" to "قرآنی الفاظ کے معانی",
            "update_app" to "ایپ اپ ڈیٹ کریں",
            "under_development" to "یہ خصوصیت ابھی زیرِ تعمیر ہے، جلد ہی دستیاب ہوگی!",
            // App Support strings
            "support_app" to "ایپ کی حمایت کریں",
            "report_issue" to "واٹس ایپ کے ذریعے مسئلہ رپورٹ کریں",
            "contribute_goodness" to "بھلائی في حصہ لیں",
            "contact_us" to "ہم سے رابطہ کریں",
            "charity_msg" to "ایپلیکیشن صدقہ جاریہ ہے۔ شیئر کریں اور ڈویلپرز کی مدد کریں - اپنی ایپ بنائیں",
            "instapay" to "انسٹا پے",
            "bank" to "بینک",
            "instapay_title" to "انسٹا پے کے ذریعے سپورٹ",
            "bank_title" to "بینک اکاؤنٹ کے ذریعے سپورٹ",
            "copy" to "کاپی کریں",
            "copied" to "کامیابی سے کاپی ہو گیا!",
            "name" to "نام",
            "iban" to "آئی بی اے این",
            "swift_code" to "سوئفٹ کوڈ"
        ),
        "id" to mapOf(
            "surah_index" to "Indeks Surah",
            "juz_index" to "Indeks Juz & Hizb",
            "tafseer_page" to "Tafsir & Asbabun Nuzul",
            "bookmarks" to "Bookmark & Batas Bacaan",
            "duaa" to "Doa Khatam Al-Quran",
            "search" to "Cari Kata & Ayat",
            "share" to "Bagikan Aplikasi",
            "update" to "Perbarui Aplikasi",
            "other_apps" to "Aplikasi Lain",
            "about" to "Tentang Aplikasi",
            "vocabulary" to "Arti Kosakata Al-Quran",
            "easy_tafseer" to "Tafsir Ringkas",
            "settings" to "Pengaturan Tampilan & Membaca",
            "translations" to "Terjemahan",
            "teacher_mode" to "Mode Guru",
            "hadith" to "Sabda Nabi SAW",
            "listen" to "Dengarkan Al-Quran",
            "azkar" to "Doa & Dzikir",
            "radio" to "Radio Al-Quran",
            "sermons" to "Khotbah & Ceramah",
            "read_learn" to "Baca & Pelajari Al-Quran",
            "app_language" to "Bahasa Aplikasi",
            "app_title" to "Al-Quran Emas",
            "read_learn_sub" to "Baca, pelajari, dan dengarkan firman Allah",
            "close" to "Tutup",
            "loading" to "Memuat...",
            "back" to "Kembali",
            "play" to "Putar",
            "pause" to "Jeda",
            "reciters" to "Qari",
            "dark_mode" to "Mode Gelap (Malam)",
            "text_size" to "Ukuran Teks Ayat & Kata",
            "brightness_control" to "Kecerahan & Redup Layar",
            "teacher_reciter" to "Murottal Muallim Ulang Ayat",
            "offline_download" to "Unduh Konten untuk Offline",
            "download_tafseer" to "Unduh Tafsir Ringkas & Arti Kata",
            "download_translation" to "Unduh Teks Terjemahan Terpilih",
            "external_api" to "Sinkronkan & Impor dari Sumber Eksternal",
            "import_external" to "Impor & Perbarui dari API Eksternal",
            "save_confirm" to "Oke & Simpan Pengaturan",
            // New UI keys
            "app_name" to "Al-Quran Emas",
            "tafseer" to "Tafsir Ringkas",
            "duaa_khatm" to "Doa Khatam Al-Quran",
            "quran_vocabulary" to "Kosakata Al-Quran",
            "update_app" to "Perbarui Aplikasi",
            "under_development" to "Fitur ini sedang dikembangkan, segera hadir!",
            // App Support strings
            "support_app" to "Dukung Aplikasi",
            "report_issue" to "Laporkan masalah via WhatsApp",
            "contribute_goodness" to "Kontribusi Kebaikan",
            "contact_us" to "Hubungi Kami",
            "charity_msg" to "Aplikasi ini adalah sedekah jariyah. Bagikan dan dukung developer - buat aplikasimu sendiri",
            "instapay" to "Instapay",
            "bank" to "Bank",
            "instapay_title" to "Dukungan via Instapay",
            "bank_title" to "Dukungan via Rekening Bank",
            "copy" to "Salin",
            "copied" to "Berhasil disalin!",
            "name" to "Nama",
            "iban" to "IBAN",
            "swift_code" to "Kode Swift"
        )
    )

    val langMap = translations[lang] ?: translations["ar"]!!
    return langMap[key] ?: translations["ar"]!![key] ?: key
}

// Gorgeous Start Screen
@Composable
fun StartScreen(
    viewModel: QuranViewModel,
    appLanguage: String,
    onOpenQuran: () -> Unit
) {
    val context = LocalContext.current
    var showHadithDialog by remember { mutableStateOf(false) }
    var showListenDialog by remember { mutableStateOf(false) }
    var showAzkarDialog by remember { mutableStateOf(false) }
    var showRadioDialog by remember { mutableStateOf(false) }
    var showSettingsDialog by remember { mutableStateOf(false) }
    var showSupportDialog by remember { mutableStateOf(false) }
    var showCharityDialog by remember { mutableStateOf(false) }
    var showSupportLabel by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        delay(2000)
        showSupportLabel = false
    }

    val textSizeVal by viewModel.textSize.collectAsState()
    val brightnessVal by viewModel.brightness.collectAsState()
    val isDarkTheme by viewModel.isDarkTheme.collectAsState()
    val teacherReciterFolder by viewModel.teacherReciterFolder.collectAsState()
    val isPlayingAudio by viewModel.isPlaying.collectAsState()
    val latestNotificationTitle by viewModel.latestNotificationTitle.collectAsState()

    // Classic Ottoman Majestic Deep Green background
    val backgroundGradient = Brush.verticalGradient(
        colors = listOf(
            Color(0xFF021B13), // deep islamic pine green
            Color(0xFF042E20), // classic deep forest green
            Color(0xFF073F2B)  // elegant dark emerald sheen
        )
    )

    val goldPrimary = Color(0xFFD4AF37) // Golden tone
    val emeraldPrimary = Color(0xFF0F9B58) // Luminous emerald

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(backgroundGradient)
            .drawBehind {
                // Drawing majestic golden and light-emerald classical Ottoman/Islamic decorations on the deep green backdrop
                val strokeWidth = 1.dp.toPx()
                val goldColor = goldPrimary.copy(alpha = 0.15f)
                val emeraldColor = Color(0xFF105F42).copy(alpha = 0.3f)

                // 1. Pointed Mosque Arch/Dome (Mihrab) outlining the background
                val archPath = androidx.compose.ui.graphics.Path().apply {
                    val margin = 20.dp.toPx()
                    val w = size.width
                    val h = size.height
                    moveTo(margin, h)
                    lineTo(margin, h * 0.3f)
                    // Beautiful pointed multi-cusp arch top
                    cubicTo(margin, h * 0.18f, w * 0.25f, h * 0.12f, w * 0.5f, h * 0.08f)
                    cubicTo(w * 0.75f, h * 0.12f, w - margin, h * 0.18f, w - margin, h * 0.3f)
                    lineTo(w - margin, h)
                }
                drawPath(archPath, color = goldColor, style = Stroke(width = 1.5.dp.toPx()))

                // Outer arch parallel line for depth
                val outerArchPath = androidx.compose.ui.graphics.Path().apply {
                    val margin = 10.dp.toPx()
                    val w = size.width
                    val h = size.height
                    moveTo(margin, h)
                    lineTo(margin, h * 0.28f)
                    cubicTo(margin, h * 0.15f, w * 0.23f, h * 0.1f, w * 0.5f, h * 0.05f)
                    cubicTo(w * 0.75f, h * 0.1f, w - margin, h * 0.15f, w - margin, h * 0.28f)
                    lineTo(w - margin, h)
                }
                drawPath(outerArchPath, color = goldColor.copy(alpha = 0.08f), style = Stroke(width = 1.dp.toPx()))

                // 2. Large Ottoman Medallion (Shamsa) behind the Quran Book Logo
                val medalCenter = Offset(size.width / 2f, size.height * 0.28f)
                // Outer star points
                val rays = 16
                val r1 = 150.dp.toPx()
                val r2 = 135.dp.toPx()
                for (i in 0 until rays) {
                    val angle1 = (i * 2 * Math.PI / rays)
                    val angle2 = ((i + 0.5f) * 2 * Math.PI / rays)
                    val angle3 = ((i + 1) * 2 * Math.PI / rays)
                    
                    val p = androidx.compose.ui.graphics.Path().apply {
                        moveTo(medalCenter.x + r2 * Math.cos(angle1).toFloat(), medalCenter.y + r2 * Math.sin(angle1).toFloat())
                        lineTo(medalCenter.x + r1 * Math.cos(angle2).toFloat(), medalCenter.y + r1 * Math.sin(angle2).toFloat())
                        lineTo(medalCenter.x + r2 * Math.cos(angle3).toFloat(), medalCenter.y + r2 * Math.sin(angle3).toFloat())
                    }
                    drawPath(p, color = goldColor.copy(alpha = 0.10f), style = Stroke(width = 1.dp.toPx()))
                }
                
                // Intricate concentric rings inside medallion
                drawCircle(color = goldColor.copy(alpha = 0.12f), radius = 130.dp.toPx(), center = medalCenter, style = Stroke(width = 1.dp.toPx()))
                drawCircle(color = emeraldColor, radius = 115.dp.toPx(), center = medalCenter, style = Stroke(width = 1.dp.toPx()))
                drawCircle(color = goldColor.copy(alpha = 0.08f), radius = 100.dp.toPx(), center = medalCenter, style = Stroke(width = 1.dp.toPx()))
            }
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(modifier = Modifier.height(30.dp))

            // 1. Glowing Quran Book Icon with glass shadow (3D shimmering & twinkling)
            val infiniteTransition = rememberInfiniteTransition(label = "icon_anim")
            val rotationY by infiniteTransition.animateFloat(
                initialValue = -12f,
                targetValue = 12f,
                animationSpec = infiniteRepeatable(
                    animation = tween(2500, easing = EaseInOutSine),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "rotation_y"
            )
            val rotationX by infiniteTransition.animateFloat(
                initialValue = -8f,
                targetValue = 8f,
                animationSpec = infiniteRepeatable(
                    animation = tween(2000, easing = EaseInOutSine),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "rotation_x"
            )
            val scale by infiniteTransition.animateFloat(
                initialValue = 0.98f,
                targetValue = 1.04f,
                animationSpec = infiniteRepeatable(
                    animation = tween(1500, easing = EaseInOutQuad),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "scale"
            )
            val shimmerTranslate by infiniteTransition.animateFloat(
                initialValue = -150f,
                targetValue = 350f,
                animationSpec = infiniteRepeatable(
                    animation = tween(3000, easing = LinearEasing),
                    repeatMode = RepeatMode.Restart
                ),
                label = "shimmer"
            )
            val sparkleAlpha by infiniteTransition.animateFloat(
                initialValue = 0.2f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    animation = tween(1200, easing = EaseInOutSine),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "sparkle"
            )

            Box(
                modifier = Modifier
                    .size(110.dp)
                    .graphicsLayer {
                        this.rotationX = rotationX
                        this.rotationY = rotationY
                        this.scaleX = scale
                        this.scaleY = scale
                        this.cameraDistance = 12f * density
                        shadowElevation = 16f
                    },
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(100.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                colors = listOf(
                                    Color(0xFFD4AF37).copy(alpha = 0.3f),
                                    if (isDarkTheme) Color(0xFF1C1D24) else Color.White
                                )
                            )
                        )
                        .border(2.5.dp, Color(0xFFD4AF37), CircleShape)
                        .padding(12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.MenuBook,
                        contentDescription = "Quran Logo",
                        tint = Color(0xFFD4AF37),
                        modifier = Modifier.size(64.dp)
                    )
                    
                    Canvas(modifier = Modifier.matchParentSize()) {
                        val brush = Brush.linearGradient(
                            colors = listOf(
                                Color.Transparent,
                                Color(0xFFFFF7C2).copy(alpha = 0.6f),
                                Color.Transparent
                            ),
                            start = androidx.compose.ui.geometry.Offset(shimmerTranslate, 0f),
                            end = androidx.compose.ui.geometry.Offset(shimmerTranslate + 80f, 80f)
                        )
                        drawCircle(brush = brush)
                    }
                }

                Canvas(modifier = Modifier.size(125.dp)) {
                    drawCircle(
                        color = Color(0xFFFFF7C2).copy(alpha = sparkleAlpha),
                        radius = 4f,
                        center = androidx.compose.ui.geometry.Offset(15f, 25f)
                    )
                    drawCircle(
                        color = Color(0xFFFFF7C2).copy(alpha = sparkleAlpha),
                        radius = 5f,
                        center = androidx.compose.ui.geometry.Offset(size.width - 20f, size.height - 25f)
                    )
                    drawCircle(
                        color = Color(0xFFFFF7C2).copy(alpha = sparkleAlpha),
                        radius = 3.5f,
                        center = androidx.compose.ui.geometry.Offset(size.width - 15f, 35f)
                    )
                }
            }

            // 2. Golden title with beautiful 3D Nickel Gold contrast against the deep green background
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(contentAlignment = Alignment.Center) {
                    // 3D extrusion/shadow layer (Deep bronze bronze-gold)
                    Text(
                        text = getAppString("app_title", appLanguage),
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Black,
                        textAlign = TextAlign.Center,
                        color = Color(0xFF3E2C0F), // Rich dark bronze
                        modifier = Modifier.offset(x = 1.5.dp, y = 1.5.dp)
                    )
                    // Front metallic gold layer with reflective linear gradient and soft glow shadow
                    Text(
                        text = getAppString("app_title", appLanguage),
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Black,
                        textAlign = TextAlign.Center,
                        style = androidx.compose.ui.text.TextStyle(
                            brush = Brush.linearGradient(
                                colors = listOf(
                                    Color(0xFF907030), // Deep warm gold
                                    Color(0xFFD4B257), // Nickel warm gold
                                    Color(0xFFF9E4B7), // Bright shiny nickel gold
                                    Color(0xFFFFF7DC), // Pale champagne highlight
                                    Color(0xFFD4B257), // Nickel warm gold
                                    Color(0xFF907030)  // Deep warm gold
                                )
                            ),
                            shadow = androidx.compose.ui.graphics.Shadow(
                                color = Color.Black.copy(alpha = 0.5f),
                                offset = Offset(2f, 4f),
                                blurRadius = 8f
                            )
                        )
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = getAppString("read_learn_sub", appLanguage),
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.Center,
                    color = Color(0xFFE2F0EA)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 3. Luxurious 3D Glassmorphic Container for Menu Buttons
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .graphicsLayer {
                        shadowElevation = 16f
                        shape = RoundedCornerShape(24.dp)
                        clip = true
                    }
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                Color.White.copy(alpha = 0.08f),
                                Color.White.copy(alpha = 0.03f)
                            )
                        )
                    )
                    .border(
                        width = 1.2.dp,
                        brush = Brush.linearGradient(
                            colors = listOf(
                                Color.White.copy(alpha = 0.25f),
                                Color(0xFFD4AF37).copy(alpha = 0.40f),
                                Color.White.copy(alpha = 0.10f)
                            )
                        ),
                        shape = RoundedCornerShape(24.dp)
                    )
                    .padding(horizontal = 14.dp, vertical = 20.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    StartScreenMenuButton(
                        text = getAppString("read_learn", appLanguage),
                        icon = Icons.Default.Book,
                        backgroundColor = Color.White.copy(alpha = 0.08f),
                        textColor = Color(0xFF81C784),
                        borderColor = goldPrimary.copy(alpha = 0.4f),
                        onClick = onOpenQuran
                    )

                    StartScreenMenuButton(
                        text = getAppString("hadith", appLanguage),
                        icon = Icons.Default.MenuBook,
                        backgroundColor = Color.White.copy(alpha = 0.08f),
                        textColor = Color(0xFFFFD180),
                        borderColor = goldPrimary.copy(alpha = 0.4f),
                        onClick = { showHadithDialog = true }
                    )

                    StartScreenMenuButton(
                        text = getAppString("listen", appLanguage),
                        icon = Icons.Default.Headphones,
                        backgroundColor = Color.White.copy(alpha = 0.08f),
                        textColor = Color(0xFF90CAF9),
                        borderColor = goldPrimary.copy(alpha = 0.4f),
                        trailingIcon = if (isPlayingAudio) Icons.Default.StopCircle else null,
                        onTrailingIconClick = if (isPlayingAudio) { { viewModel.stopAudio() } } else null,
                        onClick = { showListenDialog = true }
                    )

                    StartScreenMenuButton(
                        text = getAppString("azkar", appLanguage),
                        icon = Icons.Default.Favorite,
                        backgroundColor = Color.White.copy(alpha = 0.08f),
                        textColor = Color(0xFFFF80AB),
                        borderColor = goldPrimary.copy(alpha = 0.4f),
                        onClick = { showAzkarDialog = true }
                    )

                    StartScreenMenuButton(
                        text = getAppString("radio", appLanguage),
                        icon = Icons.Default.Radio,
                        backgroundColor = Color.White.copy(alpha = 0.08f),
                        textColor = Color(0xFFFFD54F),
                        borderColor = goldPrimary.copy(alpha = 0.4f),
                        onClick = { showRadioDialog = true }
                    )

                    StartScreenMenuButton(
                        text = getAppString("sermons", appLanguage),
                        icon = Icons.Default.VideoLibrary,
                        backgroundColor = Color.White.copy(alpha = 0.08f),
                        textColor = Color(0xFFCFD8DC),
                        borderColor = goldPrimary.copy(alpha = 0.4f),
                        onClick = {
                            Toast.makeText(context, "هذه الميزة قيد التطوير حالياً، انتظرونا قريباً!", Toast.LENGTH_LONG).show()
                        }
                    )
                }
            }

            // 4. Beautiful Classical Ottoman Islamic Ornamentation
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .padding(vertical = 8.dp)
            ) {
                val center = Offset(size.width / 2f, size.height / 2f)
                val goldColor = goldPrimary.copy(alpha = 0.75f)
                val goldFade = goldPrimary.copy(alpha = 0.35f)
                val goldLeaf = goldPrimary.copy(alpha = 0.50f)

                // 1. Symmetrical background Ottoman pointed Mihrab arch at the bottom
                val archPath = androidx.compose.ui.graphics.Path().apply {
                    val archWidth = 140.dp.toPx()
                    val archHeight = 150.dp.toPx()
                    val bottomY = size.height
                    val topY = size.height - archHeight
                    val startX = center.x - archWidth / 2f
                    val endX = center.x + archWidth / 2f

                    moveTo(startX, bottomY)
                    lineTo(startX, bottomY - 60.dp.toPx())
                    
                    // Stepped and scalloped curves for classic Ottoman architecture style
                    cubicTo(
                        startX, bottomY - 90.dp.toPx(),
                        center.x - 40.dp.toPx(), topY + 40.dp.toPx(),
                        center.x - 30.dp.toPx(), topY + 20.dp.toPx()
                    )
                    // Pointed tip
                    lineTo(center.x, topY)
                    lineTo(center.x + 30.dp.toPx(), topY + 20.dp.toPx())
                    
                    cubicTo(
                        center.x + 40.dp.toPx(), topY + 40.dp.toPx(),
                        endX, bottomY - 90.dp.toPx(),
                        endX, bottomY - 60.dp.toPx()
                    )
                    lineTo(endX, bottomY)
                }
                drawPath(archPath, color = goldFade, style = Stroke(width = 2.dp.toPx()))

                // Draw parallel inner arch lines for a rich look
                val innerArchPath = androidx.compose.ui.graphics.Path().apply {
                    val archWidth = 120.dp.toPx()
                    val archHeight = 135.dp.toPx()
                    val bottomY = size.height
                    val topY = size.height - archHeight
                    val startX = center.x - archWidth / 2f
                    val endX = center.x + archWidth / 2f

                    moveTo(startX, bottomY)
                    lineTo(startX, bottomY - 50.dp.toPx())
                    cubicTo(
                        startX, bottomY - 75.dp.toPx(),
                        center.x - 35.dp.toPx(), topY + 35.dp.toPx(),
                        center.x - 25.dp.toPx(), topY + 15.dp.toPx()
                    )
                    lineTo(center.x, topY)
                    lineTo(center.x + 25.dp.toPx(), topY + 15.dp.toPx())
                    cubicTo(
                        center.x + 35.dp.toPx(), topY + 35.dp.toPx(),
                        endX, bottomY - 75.dp.toPx(),
                        endX, bottomY - 50.dp.toPx()
                    )
                    lineTo(endX, bottomY)
                }
                drawPath(innerArchPath, color = goldFade.copy(alpha = 0.18f), style = Stroke(width = 1.dp.toPx()))

                // 2. Centerpiece: Classic Ottoman Tulip (Lale) representing divine beauty
                fun drawOttomanTulip(cx: Float, cy: Float, scale: Float) {
                    val tulipPath = androidx.compose.ui.graphics.Path().apply {
                        moveTo(cx, cy + 20f * scale)
                        // Left Petal
                        cubicTo(
                            cx - 15f * scale, cy + 12f * scale,
                            cx - 22f * scale, cy - 8f * scale,
                            cx - 10f * scale, cy - 30f * scale
                        )
                        cubicTo(
                            cx - 6f * scale, cy - 15f * scale,
                            cx - 3f * scale, cy - 4f * scale,
                            cx, cy + 6f * scale
                        )
                        // Right Petal
                        cubicTo(
                            cx + 3f * scale, cy - 4f * scale,
                            cx + 6f * scale, cy - 15f * scale,
                            cx + 10f * scale, cy - 30f * scale
                        )
                        cubicTo(
                            cx + 22f * scale, cy - 8f * scale,
                            cx + 15f * scale, cy + 12f * scale,
                            cx, cy + 20f * scale
                        )
                    }
                    drawPath(tulipPath, color = goldColor, style = Stroke(width = 2.dp.toPx()))
                    
                    // Central stamen of the tulip
                    val centerStamen = androidx.compose.ui.graphics.Path().apply {
                        moveTo(cx, cy + 14f * scale)
                        lineTo(cx, cy - 38f * scale)
                    }
                    drawPath(centerStamen, color = goldColor, style = Stroke(width = 1.5.dp.toPx()))
                    
                    // Little circles at the top of petals for a festive illuminated look
                    drawCircle(color = goldColor, radius = 2.dp.toPx(), center = Offset(cx - 10f * scale, cy - 30f * scale))
                    drawCircle(color = goldColor, radius = 2.dp.toPx(), center = Offset(cx + 10f * scale, cy - 30f * scale))
                    drawCircle(color = goldColor, radius = 2.5f.dp.toPx(), center = Offset(cx, cy - 38f * scale))
                }

                // Draw central majestic tulip in the center of the Mihrab
                drawOttomanTulip(center.x, center.y + 10.dp.toPx(), 1.2f)

                // 3. Symmetrical spiral gold stems (Arabesque scrollwork / Tezhip)
                val leftStem = androidx.compose.ui.graphics.Path().apply {
                    moveTo(center.x, size.height)
                    cubicTo(
                        center.x - 40.dp.toPx(), center.y + 60.dp.toPx(),
                        center.x - 80.dp.toPx(), center.y + 40.dp.toPx(),
                        center.x - 70.dp.toPx(), center.y
                    )
                    cubicTo(
                        center.x - 60.dp.toPx(), center.y - 30.dp.toPx(),
                        center.x - 30.dp.toPx(), center.y - 20.dp.toPx(),
                        center.x - 40.dp.toPx(), center.y + 5.dp.toPx()
                    )
                }
                drawPath(leftStem, color = goldLeaf, style = Stroke(width = 1.5.dp.toPx()))

                val rightStem = androidx.compose.ui.graphics.Path().apply {
                    moveTo(center.x, size.height)
                    cubicTo(
                        center.x + 40.dp.toPx(), center.y + 60.dp.toPx(),
                        center.x + 80.dp.toPx(), center.y + 40.dp.toPx(),
                        center.x + 70.dp.toPx(), center.y
                    )
                    cubicTo(
                        center.x + 60.dp.toPx(), center.y - 30.dp.toPx(),
                        center.x + 30.dp.toPx(), center.y - 20.dp.toPx(),
                        center.x + 40.dp.toPx(), center.y + 5.dp.toPx()
                    )
                }
                drawPath(rightStem, color = goldLeaf, style = Stroke(width = 1.5.dp.toPx()))

                // 4. Stylized side flowers (smaller carnations/buds) on the spiral branches
                drawOttomanTulip(center.x - 70.dp.toPx(), center.y, 0.7f)
                drawOttomanTulip(center.x + 70.dp.toPx(), center.y, 0.7f)

                // 5. Delicate decorative leaves (Rumi pattern) at the nodes of the scrolls
                fun drawRumiLeaf(cx: Float, cy: Float, rotationAngle: Double) {
                    val leaf = androidx.compose.ui.graphics.Path().apply {
                        val angle = Math.toRadians(rotationAngle)
                        val cos = Math.cos(angle).toFloat()
                        val sin = Math.sin(angle).toFloat()
                        
                        fun rotate(x: Float, y: Float) = Offset(cx + (x * cos - y * sin), cy + (x * sin + y * cos))
                        
                        val p0 = rotate(0f, 0f)
                        val p1 = rotate(-10f, -5f)
                        val p2 = rotate(-15f, -20f)
                        val p3 = rotate(0f, -25f)
                        val p4 = rotate(5f, -15f)
                        val p5 = rotate(3f, -5f)

                        moveTo(p0.x, p0.y)
                        cubicTo(p1.x, p1.y, p2.x, p2.y, p3.x, p3.y)
                        cubicTo(p4.x, p4.y, p5.x, p5.y, p0.x, p0.y)
                    }
                    drawPath(leaf, color = goldLeaf, style = Stroke(width = 1.2.dp.toPx()))
                }

                // Left and right Rumi leaf accents
                drawRumiLeaf(center.x - 55.dp.toPx(), center.y + 35.dp.toPx(), -45.0)
                drawRumiLeaf(center.x + 55.dp.toPx(), center.y + 35.dp.toPx(), 45.0)
                drawRumiLeaf(center.x - 45.dp.toPx(), center.y - 15.dp.toPx(), -135.0)
                drawRumiLeaf(center.x + 45.dp.toPx(), center.y - 15.dp.toPx(), 135.0)

                // Symmetrical decorative stars/dots in the negative space
                val dotColor = goldPrimary.copy(alpha = 0.65f)
                drawCircle(color = dotColor, radius = 2.dp.toPx(), center = Offset(center.x - 30.dp.toPx(), center.y - 45.dp.toPx()))
                drawCircle(color = dotColor, radius = 2.dp.toPx(), center = Offset(center.x + 30.dp.toPx(), center.y - 45.dp.toPx()))
                drawCircle(color = dotColor, radius = 3.dp.toPx(), center = Offset(center.x - 100.dp.toPx(), center.y + 20.dp.toPx()))
                drawCircle(color = dotColor, radius = 3.dp.toPx(), center = Offset(center.x + 100.dp.toPx(), center.y + 20.dp.toPx()))
            }

            Spacer(modifier = Modifier.height(40.dp))
        }

        // Separate left and right aligned floating buttons
        // Force settings gear on the right, and charity/support buttons on the top left
        val isRtl = androidx.compose.ui.platform.LocalLayoutDirection.current == androidx.compose.ui.unit.LayoutDirection.Rtl
        val charityAlignment = if (isRtl) Alignment.TopEnd else Alignment.TopStart // Always Left
        val settingsAlignment = if (isRtl) Alignment.TopStart else Alignment.TopEnd // Always Right

        // 1. Settings Gear on the Right side
        Box(
            modifier = Modifier
                .align(settingsAlignment)
                .padding(16.dp)
                .offset(x = 12.dp, y = (-8).dp)
        ) {
            Box(contentAlignment = Alignment.TopEnd) {
                IconButton(
                    onClick = { showSettingsDialog = true },
                    modifier = Modifier
                        .size(44.dp)
                        .background(if (isDarkTheme) Color(0xFF1E1E1E).copy(alpha = 0.85f) else Color.White.copy(alpha = 0.85f), CircleShape)
                        .border(1.5.dp, goldPrimary, CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "الإعدادات",
                        tint = goldPrimary,
                        modifier = Modifier.size(22.dp)
                    )
                }

                if (!latestNotificationTitle.isNullOrBlank()) {
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .background(Color.Red, CircleShape)
                            .border(1.5.dp, if (isDarkTheme) Color(0xFF1E1E1E) else Color.White, CircleShape)
                            .align(Alignment.TopEnd)
                    )
                }
            }
        }

        // 2. Charity and Support buttons on the Left side
        Column(
            modifier = Modifier
                .align(charityAlignment)
                .padding(16.dp)
                .offset(x = (-12).dp, y = (-8).dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Button 1: ساهم في الخير (Contribute to Goodness) - Glowing and permanent
            val infiniteTransition = rememberInfiniteTransition(label = "glow")
            val glowColor by infiniteTransition.animateColor(
                initialValue = goldPrimary,
                targetValue = Color(0xFFFFD700), // Pure Gold
                animationSpec = infiniteRepeatable(
                    animation = tween(1000, easing = FastOutSlowInEasing),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "glowColor"
            )
            val glowScale by infiniteTransition.animateFloat(
                initialValue = 0.95f,
                targetValue = 1.05f,
                animationSpec = infiniteRepeatable(
                    animation = tween(1000, easing = FastOutSlowInEasing),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "glowScale"
            )

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Surface(
                    color = Color(0xFF021B13).copy(alpha = 0.9f),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.5.dp, glowColor),
                    modifier = Modifier
                        .padding(bottom = 2.dp)
                        .scale(glowScale)
                ) {
                    Text(
                        text = getAppString("contribute_goodness", appLanguage),
                        color = glowColor,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        style = androidx.compose.ui.text.TextStyle(
                            shadow = androidx.compose.ui.graphics.Shadow(
                                color = glowColor,
                                offset = Offset(0f, 0f),
                                blurRadius = 10f * glowScale
                              )
                        ),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                FloatingActionButton(
                    onClick = { showCharityDialog = true },
                    containerColor = goldPrimary,
                    contentColor = Color(0xFF021B13),
                    shape = CircleShape,
                    modifier = Modifier
                        .size(56.dp)
                        .testTag("charity_fab"),
                    elevation = FloatingActionButtonDefaults.elevation(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Favorite,
                        contentDescription = getAppString("contribute_goodness", appLanguage),
                        tint = Color(0xFFD32F2F),
                        modifier = Modifier.size(28.dp)
                    )
                }
            }

            // Button 2: الدعم (Support) - Smaller, label appears for 2 seconds then disappears
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                AnimatedVisibility(
                    visible = showSupportLabel,
                    enter = fadeIn() + expandVertically(),
                    exit = fadeOut() + shrinkVertically()
                ) {
                    Surface(
                        color = goldPrimary,
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.5.dp, Color.White.copy(alpha = 0.5f)),
                        modifier = Modifier.padding(bottom = 2.dp)
                    ) {
                        Text(
                            text = getAppString("support_app", appLanguage),
                            color = Color(0xFF021B13),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                        )
                    }
                }

                SmallFloatingActionButton(
                    onClick = { showSupportDialog = true },
                    containerColor = if (isDarkTheme) Color(0xFF2C2C35) else Color(0xFFF0EAE1),
                    contentColor = goldPrimary,
                    shape = CircleShape,
                    modifier = Modifier
                        .size(40.dp)
                        .testTag("support_fab")
                ) {
                    Icon(
                        imageVector = Icons.Default.Call,
                        contentDescription = getAppString("support_app", appLanguage),
                        modifier = Modifier.size(20.dp),
                        tint = goldPrimary
                    )
                }
            }
        }
    }

    // Dialogs Triggered
    if (showHadithDialog) {
        HadithDialog(isDark = isDarkTheme, onClose = { showHadithDialog = false })
    }

    if (showListenDialog) {
        ListenQuranDialog(viewModel = viewModel, onClose = { showListenDialog = false })
    }

    if (showAzkarDialog) {
        AzkarDialog(isDark = isDarkTheme, onClose = { showAzkarDialog = false })
    }

    if (showRadioDialog) {
        RadioDialog(viewModel = viewModel, isDark = isDarkTheme, onClose = { showRadioDialog = false })
    }

    if (showSettingsDialog) {
        SettingsControlDialog(
            viewModel = viewModel,
            textSize = textSizeVal,
            brightness = brightnessVal,
            isDark = isDarkTheme,
            teacherReciterFolder = teacherReciterFolder,
            onClose = { showSettingsDialog = false }
        )
    }

    if (showSupportDialog) {
        AppSupportDialog(
            isDark = isDarkTheme,
            appLanguage = appLanguage,
            onClose = { showSupportDialog = false }
        )
    }

    if (showCharityDialog) {
        CharityDialog(
            isDark = isDarkTheme,
            appLanguage = appLanguage,
            onClose = { showCharityDialog = false }
        )
    }
}

// Highly stylized individual starting screen button
@Composable
fun StartScreenMenuButton(
    text: String,
    icon: ImageVector,
    backgroundColor: Color,
    textColor: Color,
    borderColor: Color,
    trailingIcon: ImageVector? = null,
    onTrailingIconClick: (() -> Unit)? = null,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth(0.9f)
            .height(60.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.5.dp, borderColor.copy(alpha = 0.5f)),
        colors = CardDefaults.cardColors(containerColor = backgroundColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = textColor,
                modifier = Modifier.size(26.dp)
            )
            Text(
                text = text,
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                color = textColor,
                textAlign = TextAlign.Center,
                modifier = Modifier.weight(1f)
            )
            if (trailingIcon != null && onTrailingIconClick != null) {
                IconButton(
                    onClick = onTrailingIconClick,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = trailingIcon,
                        contentDescription = "Stop",
                        tint = Color(0xFFEF5350), // soft crimson stop color
                        modifier = Modifier.size(24.dp)
                    )
                }
            } else {
                Icon(
                    imageVector = Icons.Default.ChevronLeft,
                    contentDescription = null,
                    tint = textColor.copy(alpha = 0.5f),
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    }
}

data class HadithItem(val text: String, val category: String)

// Hadith Scroll Dialog
@Composable
fun HadithDialog(isDark: Boolean, onClose: () -> Unit) {
    val allHadiths = remember {
        listOf(
            // الصلاة
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"بُنِيَ الإسْلامُ علَى خَمْسٍ: شَهادَةِ أنْ لا إلَهَ إلَّا اللَّهُ وأنَّ مُحَمَّدًا رَسولُ اللَّهِ، وإقامِ الصَّلاةِ، وإيتاءِ الزَّكاةِ، والحَجِّ، وصَوْمِ رَمَضانَ\"\n(رواه البخاري)", "الصلاة"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"أرأيتُم لو أنَّ نَهرًا ببابِ أحدِكم يَغتسِلُ منه كلَّ يَومٍ خَمسَ مرَّاتٍ، هلْ يَبقَى من دَرَنِه شيءٌ؟ قالوا: لا يَبقَى من دَرَنِه شيءٌ، قال: فذلكَ مَثلُ الصَّلواتِ الخمسِ، يَمحُو اللَّهُ بهنَّ الخطايا\"\n(رواه البخاري)", "الصلاة"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"من صلَّى البردَينِ دَخلَ الجَنَّةَ\"\n(رواه البخاري)", "الصلاة"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"إنَّ أحدَكم إذا قامَ يُصلِّي، فإنَّه يُناجِي ربَّه، أو إنَّ ربَّه بينَه وبينَ القِبلةِ\"\n(رواه البخاري)", "الصلاة"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"صلُّوا كما رَأيتُمُونِي أُصلِّي\"\n(رواه البخاري)", "الصلاة"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"مَن تَوضَّأَ لِلصَّلَاةِ فأسْبَغَ الوُضُوءَ، ثُمَّ مَشَى إلى الصَّلَاةِ المَكْتُوبَةِ، فَصَلَّاهَا مع النَّاسِ، غَفَرَ اللَّهُ له ذُنُوبَهُ\"\n(رواه البخاري)", "الصلاة"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"عليك بسجودِ اللهِ تباركَ وتعالى، فإنَّك لا تسجُدُ للهِ سَجدةً إلَّا رفعَك اللهُ بها دَرجةً، وحطَّ عنك بها خَطيئةً\"\n(رواه البخاري)", "الصلاة"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"إذا نُودِيَ بالصَّلَاةِ أدْبَرَ الشَّيْطَانُ وله ضُرَاطٌ حتَّى لا يَسْمَعَ التَّأْذِينَ\"\n(رواه البخاري)", "الصلاة"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"ليسَ صَلَاةٌ أثْقَلَ علَى المُنَافِقِينَ مِنَ الفَجْرِ والعِشَاءِ، ولو يَعْلَمُونَ ما فِيهِمَا لَأتَوْهُمَا ولو حَبْوًا\"\n(رواه البخاري)", "الصلاة"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"إذا دخَلَ أحدُكمُ المسجِدَ، فلا يجلِسْ حتى يركَعَ ركعتَينِ\"\n(رواه البخاري)", "الصلاة"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"بَشِّرِ الْمَشَّائِينَ فِي الظُّلَمِ إِلَى الْمَسَاجِدِ بِالنُّورِ التَّامِّ يَوْمَ الْقِيَامَةِ\"\n(رواه البخاري)", "الصلاة"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"صلاةُ الجميعِ تَزيدُ على صلاتِه في بيتِه، وصلاتِه في سُوقِه، خَمسًا وعِشرينَ دَرَجةً\"\n(رواه البخاري)", "الصلاة"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"لو يعلمُ الناسُ ما في النِّداءِ والصفِّ الأولِ ثم لم يجدوا إلا أن يَستهموا عليه لاسْتَهموا\"\n(رواه البخاري)", "الصلاة"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"إذا أَمَّ أحدُكمُ الناسَ فَلْيُخَفِّفْ؛ فإنَّ فيهمُ الصغيرَ والكبيرَ والضعيفَ والمريضَ\"\n(رواه البخاري)", "الصلاة"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"أقربُ ما يكونُ العبدُ من ربِّه وهو ساجدٌ، فأكْثِرُوا الدُّعاءَ\"\n(رواه البخاري)", "الصلاة"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"جُعِلَتْ لي الأرْضُ مَسْجِدًا وطَهُورًا، فأيُّما رَجُلٍ مِن أُمَّتي أدْرَكَتْهُ الصَّلَاةُ فَلْيُصَلِّ\"\n(رواه البخاري)", "الصلاة"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"مَن غَدَا إلى المَسْجِدِ أوْ رَاحَ، أعَدَّ اللَّهُ له في الجَنَّةِ نُزُلًا كُلَّما غَدَا أوْ رَاحَ\"\n(رواه البخاري)", "الصلاة"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"الملائكةُ تُصلِّي على أحدِكم ما دام في مُصلَّاه الذي صلَّى فيه ما لم يُحدثْ\"\n(رواه البخاري)", "الصلاة"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"مَن صلَّى العِشاءَ في جَماعةٍ فكَأنَّما قامَ نِصفَ اللَّيلِ، ومَن صلَّى الصُّبْحَ في جَماعةٍ فكَأنَّما صلَّى اللَّيلَ كُلَّه\"\n(رواه البخاري)", "الصلاة"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"مَن بنى مَسجدًا يَبْتَغِي به وَجْهَ اللَّهِ، بَنَى اللَّهُ له مِثْلَهُ في الجَنَّةِ\"\n(رواه البخاري)", "الصلاة"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"إذا قال الإمامُ: غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ فقولوا: آمينَ؛ فإنَّه مَن وافقَ قولُه قولَ الملائكةِ غُفِرَ له ما تقدَّمَ من ذنبِه\"\n(رواه البخاري)", "الصلاة"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"تَراصُّوا في الصُّفوفِ وقارِبوا بينَها\"\n(رواه البخاري)", "الصلاة"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"لا صلاةَ لمن لم يقرأْ بفاتحةِ الكتابِ\"\n(رواه البخاري)", "الصلاة"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"أعِتموا بهذه الصلاةِ؛ فإنكم قد فُضّلتُم بها على الأممِ، ولم تُصلّها أمةٌ قبلكم\"\n(رواه البخاري)", "الصلاة"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"مَن نَسِيَ صَلَاةً فَلْيُصَلِّ إِذَا ذَكَرَهَا، لَا كَفَّارَةَ لَهَا إِلَّا ذَلِكَ\"\n(رواه البخاري)", "الصلاة"),

            // الزكاة
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"مَن آتاهُ اللَّهُ مالًا، فلم يُؤَدِّ زَكاتَهُ مُثِّلَ له مالُهُ يَومَ القِيامَةِ شُجاعًا أقْرَعَ له زَبِيبَتانِ يُطَوَّقُهُ يَومَ القِيامَةِ\"\n(رواه البخاري)", "الزكاة"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"ما مِن يَومٍ يُصْبِحُ العِبادُ فيه، إلَّا مَلَكانِ يَنْزِلانِ، فيَقولُ أحَدُهُما: اللَّهُمَّ أعْطِ مُنْفِقًا خَلَفًا، ويَقولُ الآخرُ: اللَّهُمَّ أعْطِ مُمْسِكًا تَلَفًا\"\n(رواه البخاري)", "الزكاة"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"اتَّقُوا النَّارَ ولو بشِقِّ تَمْرَةٍ\"\n(رواه البخاري)", "الزكاة"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"اليدُ العُليا خيرٌ من اليدِ السُّفلى، وابدأْ بمَن تَعولُ، وخيرُ الصدقةِ عن ظهرِ غِنًى\"\n(رواه البخاري)", "الزكاة"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"إنَّ الصَّدَقَةَ لَتُطْفِئُ غَضَبَ الرَّبِّ وتَدْفَعُ مِيتَةَ السُّوءِ\"\n(رواه البخاري)", "الزكاة"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"أَيُّما مُسْلِمٍ كَسَا مُسْلِمًا ثَوْبًا عَلَى عُرْيٍ كَسَاهُ اللَّهُ مِنْ خُضْرِ الْجَنَّةِ\"\n(رواه البخاري)", "الزكاة"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"مَن تَصدَّقَ بعَدْلِ تَمرَةٍ مِن كَسْبٍ طَيِّبٍ -ولا يَقْبَلُ اللَّهُ إلَّا الطَّيِّبَ- فإنَّ اللَّهَ يَقْبَلُها بيَمِينِهِ، ثُمَّ يُرَبِّيها لِصاحِبِهِ كما يُرَبِّي أحَدُكُمْ فَلُوَّهُ\"\n(رواه البخاري)", "الزكاة"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"لا حسدَ إلا في اثنتينِ: رجلٌ آتاه اللهُ مالًا فسلطَهُ على هَلَكتِهِ في الحقِّ، ورجلٌ آتاه اللهُ الحكمةَ فهو يقضي بها ويُعلمُها\"\n(رواه البخاري)", "الزكاة"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"السَّاعِي علَى الأرْمَلَةِ والمِسْكِينِ، كَالْمُجَاهِدِ في سَبيلِ اللَّهِ، أوِ القَائِمِ اللَّيْلَ الصَّائِمِ النَّهَارَ\"\n(رواه البخاري)", "الزكاة"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"أنا وكافِلُ اليَتِيمِ في الجَنَّةِ هَكَذَا، وأَشَارَ بالسَّبَّابَةِ والوُسْطَى، وفَرَّجَ بيْنَهُمَا شيئًا\"\n(رواه البخاري)", "الزكاة"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"الصدقةُ تسدُّ سبعينَ بابًا من السوءِ\"\n(رواه البخاري)", "الزكاة"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"صنائعُ المعروفِ تقي مصارعَ السوءِ، والصدقةُ خفياً تطفئُ غضبَ الربِّ\"\n(رواه البخاري)", "الزكاة"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"كلُّ امرئٍ في ظلِّ صدقتِهِ حتى يُفصلَ بين الناسِ\"\n(رواه البخاري)", "الزكاة"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"تَبَسُّمُكَ فِي وَجْهِ أَخِيكَ لَكَ صَدَقَةٌ\"\n(رواه البخاري)", "الزكاة"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"أطعموا الجائعَ، وعودوا المريضَ، وفكوا العاني\"\n(رواه البخاري)", "الزكاة"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"ما نقصتْ صدقةٌ من مالٍ، وما زاد اللهُ عبدًا بعفوٍ إلا عزًّا\"\n(رواه البخاري)", "الزكاة"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"إنَّما يَرْحَمُ اللَّهُ مِن عِبادِهِ الرُّحَماءَ\"\n(رواه البخاري)", "الزكاة"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"على كلِّ مسلمٍ صدقةٌ. قالوا: فإن لم يجدْ؟ قال: يعملُ بيديهِ فينفعُ نفسَهُ ويتصدقُ\"\n(رواه البخاري)", "الزكاة"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"أفضلُ الصدقةِ أن تُشبِعَ كبِدًا جائعةً\"\n(رواه البخاري)", "الزكاة"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"مَن كان في حاجةِ أخيهِ كان اللهُ في حاجتِهِ\"\n(رواه البخاري)", "الزكاة"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"سبعةٌ يُظلُّهم اللهُ في ظلِّهِ.. ورجلٌ تصدَّقَ بصدقةٍ فأخفاها حتى لا تعلمَ شمالُهُ ما تُنفقُ يمينُهُ\"\n(رواه البخاري)", "الزكاة"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"داووا مرضاكم بالصدقةِ\"\n(رواه البخاري)", "الزكاة"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"إتقوا الشُّحَّ فإنَّ الشُّحَّ أهلك من كان قبلكم\"\n(رواه البخاري)", "الزكاة"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"يا ابنَ آدمَ أنفِقْ أُنفِقْ عليكَ\"\n(رواه البخاري)", "الزكاة"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"ليس المسكينُ الذي يطوفُ على الناسِ ترده اللقمةُ واللقمتانِ، ولكن المسكينُ الذي لا يجد غنىً ولا يُفطنُ له\"\n(رواه البخاري)", "الزكاة"),

            // الذكر
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"كَلِمَتانِ حَبِيبَتانِ إلى الرَّحْمَنِ، خَفِيفَتانِ علَى اللِّسانِ، ثَقِيلَتانِ في المِيزانِ: سُبْحانَ اللَّهِ وبِحَمْدِهِ، سُبْحانَ اللَّهِ العَظِيمِ\"\n(رواه البخاري)", "الذكر"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"مَثَلُ الذي يَذْكُرُ رَبَّهُ والذي لا يَذْكُرُ رَبَّهُ، مَثَلُ الحَيِّ والمَيِّتِ\"\n(رواه البخاري)", "الذكر"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"يقولُ اللَّه تعالى: أنا عِنْدَ ظَنِّ عَبْدِي بي، وأنا معهُ إذا ذَكَرَنِي، فإنْ ذَكَرَنِي في نَفْسِهِ ذَكَرْتُهُ في نَفْسِي\"\n(رواه البخاري)", "الذكر"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"لأَنْ أَقُولَ سُبْحَانَ اللهِ، وَالْحَمْدُ للهِ، وَلَا إِلَهَ إِلَّا اللهُ، وَاللهُ أَكْبَرُ، أَحَبُّ إِلَيَّ مِمَّا طَلَعَتْ عَلَيْهِ الشَّمْسُ\"\n(رواه البخاري)", "الذكر"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"مَن قالَ: سُبْحانَ اللَّهِ وبِحَمْدِهِ، في يَومٍ مِائَةَ مَرَّةٍ، حُطَّتْ خَطاياهُ وإنْ كانَتْ مِثْلَ زَبَدِ البَحْرِ\"\n(رواه البخاري)", "الذكر"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"ألا أدُلُّكَ علَى كَنْزٍ مِن كُنُوزِ الجَنَّةِ؟ فَقُلتُ: بَلَى يا رَسولَ اللَّهِ، قالَ: لا حَوْلَ ولا قُوَّةَ إلَّا باللَّهِ\"\n(رواه البخاري)", "الذكر"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"أحبُّ الكلامِ إلى اللهِ أربعٌ: سُبْحانَ اللهِ، وَالْحَمْدُ للهِ، وَلَا إِلَهَ إِلَّا اللهُ، وَاللهُ أَكْبَرُ\"\n(رواه البخاري)", "الذكر"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"سيِّدُ الاستغفارِ أنْ تقولَ: اللَّهُمَّ أنْتَ رَبِّي لا إلَهَ إلَّا أنْتَ، خَلَقْتَنِي وأنا عَبْدُكَ، وأنا علَى عَهْدِكَ ووَعْدِكَ ما اسْتَطَعْتُ\"\n(رواه البخاري)", "الذكر"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"مَن قالَ: لا إلَهَ إلَّا اللَّهُ وحْدَهُ لا شَرِيكَ له، له المُلْكُ وله الحَمْدُ وهو علَى كُلِّ شيءٍ قَدِيرٌ، في يَومٍ مِائَةَ مَرَّةٍ؛ كانَتْ له عَدْلَ عَشْرِ رِقابٍ، وكُتِبَتْ له مِائَةُ حَسَنَةٍ\"\n(رواه البخاري)", "الذكر"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"مَن صلَّى عليَّ صلاةً واحدةً صلَّى اللهُ عليه بها عشرًا\"\n(رواه البخاري)", "الذكر"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"إنَّ للهِ ملائكةً يطوفون في الطرقِ يلتَمِسون أهلَ الذِّكرِ، فإذا وجدوا قومًا يذكرون اللهَ تنادَوْا: هلمّوا إلى حاجتِكم\"\n(رواه البخاري)", "الذكر"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"أفضلُ الذِّكرِ: لا إلهَ إلا اللهُ، وأفضلُ الدعاءِ: الحمدُ للهِ\"\n(رواه البخاري)", "الذكر"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"ليس شيءٌ أكرمَ على اللهِ تعالى من الدعاءِ\"\n(رواه البخاري)", "الذكر"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"يُستجابُ لأحدِكم ما لم يَعجلْ، يقولُ: دعوتُ فلم يُستجبْ لي\"\n(رواه البخاري)", "الذكر"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"من لزمَ الاستغفارَ جعلَ اللهُ له من كلِّ ضيقٍ مخرجًا، ومن كلِّ همٍّ فرجًا، ورزقَهُ من حيثُ لا يحتسبُ\"\n(رواه البخاري)", "الذكر"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"ما عَمِلَ آدَمِيٌّ عَمَلًا أَنْجَى لَهُ مِنْ عَذَابِ اللَّهِ مِنْ ذِكْرِ اللَّهِ\"\n(رواه البخاري)", "الذكر"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"إنَّ اللهَ عز وجل يقولُ: أنا مع عبدي ما ذكرَني وتحركتْ بي شفتاهُ\"\n(رواه البخاري)", "الذكر"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"مَن سرَّهُ أن يستجيبَ اللهُ له عند الشدائدِ والكُربِ فليُكثرِ الدعاءَ في الرخاءِ\"\n(رواه البخاري)", "الذكر"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"ذاكرُ اللهِ في الغافلينَ مثلُ الشجرةِ الخضراءِ في وسطِ الهشيمِ\"\n(رواه البخاري)", "الذكر"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"الدعاءُ هو العبادةُ\"\n(رواه البخاري)", "الذكر"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"إنَّ رَبَّكُمْ حَيِيٌّ كَرِيمٌ يَسْتَحْيِي مِنْ عَبْدِهِ إِذَا رَفَعَ يَدَيْهِ إِلَيْهِ أَنْ يَرُدَّهُمَا صِفْرًا خَائِبَتَيْنِ\"\n(رواه البخاري)", "الذكر"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"لا يَقُلْ أحَدُكُمْ: اللَّهُمَّ اغْفِرْ لي إنْ شِئْتَ، ارْحَمْنِي إنْ شِئْتَ، لِيَعْزِمِ المَسْأَلَةَ، فإنَّه لا مُكْرِهَ له\"\n(رواه البخاري)", "الذكر"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"ما قعدَ قومٌ مقعدًا لم يذكروا اللهَ فيه ولم يُصلّوا على نبيِّهم إلا كان عليهم تِرةٌ يومَ القيامةِ\"\n(رواه البخاري)", "الذكر"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"البخيلُ مَن ذُكِرتُ عندَهُ فلم يُصلِّ عليَّ\"\n(رواه البخاري)", "الذكر"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"مَن قَرَأَ الآيَتَيْنِ مِن آخِرِ سُورَةِ البَقَرَةِ في لَيْلَةٍ كَفَتَاهُ\"\n(رواه البخاري)", "الذكر"),

            // فضائل الأعمال
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"إنَّما الأعْمالُ بالنِّيَّاتِ، وإنَّما لِكُلِّ امْرِئٍ ما نَوَى، فمَن كانَتْ هِجْرَتُهُ إلى دُنْيا يُصِيبُها، أوْ إلى امْرَأَةٍ يَنْكِحُها، فهِجْرَتُهُ إلى ما هَاجَرَ إلَيْهِ\"\n(رواه البخاري)", "فضائل الأعمال"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"المُسْلِمُ مَن سَلِمَ المُسْلِمُونَ مِن لِسانِهِ ويَدِهِ، والمُهَاجِرُ مَن هَجَرَ ما نَهَى اللَّهُ عنْه\"\n(رواه البخاري)", "فضائل الأعمال"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"لا يُؤْمِنُ أحدُكم حتى يُحِبَّ لأخيهِ ما يُحِبُّ لنفسِهِ\"\n(رواه البخاري)", "فضائل الأعمال"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"مَن كانَ يُؤْمِنُ باللَّهِ واليَومِ الآخِرِ فليَقُلْ خَيْرًا أوْ لِيَصْمُتْ، ومَن كانَ يُؤْمِنُ باللَّهِ واليَومِ الآخِرِ فَلْيُكْرِمْ جَارَهُ\"\n(رواه البخاري)", "فضائل الأعمال"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"إنَّ الصِّدْقَ يَهْدِي إلى البِرِّ، وإنَّ البِرَّ يَهْدِي إلى الجَنَّةِ، وإنَّ الرَّجُلَ لَيَصْدُقُ حتَّى يُكْتَبَ صِدِّيقًا\"\n(رواه البخاري)", "فضائل الأعمال"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"تَبَسُّمُكَ فِي وَجْهِ أَخِيكَ لَكَ صَدَقَةٌ، وَأَمْرُكَ بِالْمَعْرُوفِ وَنَهْيُكَ عَنِ الْمُنْكَرِ صَدَقَةٌ\"\n(رواه البخاري)", "فضائل الأعمال"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"إنَّ الخِيَارَ مِنْكُمْ أَحْسَنُكُمْ أَخْلَاقًا\"\n(رواه البخاري)", "فضائل الأعمال"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"مَن سَلَكَ طَرِيقًا يَلْتَمِسُ فِيهِ عِلْمًا سَهَّلَ اللَّهُ لَهُ بِهِ طَرِيقًا إِلَى الْجَنَّةِ\"\n(رواه البخاري)", "فضائل الأعمال"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"الرَّاحِمُونَ يَرْحَمُهُمُ الرَّحْمَنُ، ارْحَمُوا مَنْ فِي الْأَرْضِ يَرْحَمْكُمْ مَنْ فِي السَّمَاءِ\"\n(رواه البخاري)", "فضائل الأعمال"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"مَن لَا يَرْحَمْ لَا يُرْحَمْ\"\n(رواه البخاري)", "فضائل الأعمال"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"آيَةُ المُنَافِقِ ثَلَاثٌ: إذَا حَدَّثَ كَذَبَ، وإذَا وعَدَ أخْلَفَ، وإذَا اؤْتُمِنَ خَانَ\"\n(رواه البخاري)", "فضائل الأعمال"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"لَيْسَ الشَّدِيدُ بِالصُّرَعَةِ، إِنَّمَا الشَّدِيدُ الَّذِي يَمْلِكُ نَفْسَهُ عِنْدَ الْغَضَبِ\"\n(رواه البخاري)", "فضائل الأعمال"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"يَسِّرُوا ولا تُعَسِّرُوا، وبَشِّرُوا ولا تُنَفِّرُوا\"\n(رواه البخاري)", "فضائل الأعمال"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"إنَّ المَعْرُوفَ يَقِي مَصَارِعَ السُّوءِ، والصَّدَقَةَ خُفْيًا تُطْفِئُ غَضَبَ الرَّبِّ\"\n(رواه البخاري)", "فضائل الأعمال"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"مَن سَرَّهُ أنْ يُبْسَطَ له في رِزْقِهِ، وأَنْ يُنْسَأَ له في أثَرِهِ، فَلْيَصِلْ رَحِمَهُ\"\n(رواه البخاري)", "فضائل الأعمال"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"لا يَدْخُلُ الجَنَّةَ قاطِعُ رَحِمٍ\"\n(رواه البخاري)", "فضائل الأعمال"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"مَن نَفَّسَ عَنْ مُؤْمِنٍ كُرْبَةً مِنْ كُرَبِ الدُّنْيَا نَفَّسَ اللَّهُ عَنْهُ كُرْبَةً مِنْ كُرَبِ يَوْمِ الْقِيَامَةِ\"\n(رواه البخاري)", "فضائل الأعمال"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"وَاللَّهُ فِي عَوْنِ الْعَبْدِ مَا كَانَ الْعَبْدُ فِي عَوْنِ أَخِيهِ\"\n(رواه البخاري)", "فضائل الأعمال"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"لأن يَحْتَطِبَ أحَدُكُمْ حُزْمَةً علَى ظَهْرِهِ، خَيْرٌ له مِن أنْ يَسْأَلَ أحَدًا فيُعْطِيَهُ أوْ يَمْنَعَهُ\"\n(رواه البخاري)", "فضائل الأعمال"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"مَن نَجَّى نَفْسًا فَكَأَنَّمَا أَحْيَا النَّاسَ جَمِيعًا\"\n(رواه البخاري)", "فضائل الأعمال"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"الدَّالُّ عَلَى الْخَيْرِ كَفَاعِلِهِ\"\n(رواه البخاري)", "فضائل الأعمال"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"اتَّقِ اللَّهَ حَيْثُمَا كُنْتَ، وَأَتْبِعِ السَّيِّئَةَ الْحَسَنَةَ تَمْحُهَا، وَخَالِقِ النَّاسَ بِخُلُقٍ حَسَنٍ\"\n(رواه البخاري)", "فضائل الأعمال"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"مَن كانَ يُؤْمِنُ باللَّهِ واليَومِ الآخِرِ فَلْيُكْرِمْ ضَيْفَهُ\"\n(رواه البخاري)", "فضائل الأعمال"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"إنَّ اللَّهَ يُحِبُّ إِذَا عَمِلَ أَحَدُكُمْ عَمَلًا أَنْ يُتْقِنَهُ\"\n(رواه البخاري)", "فضائل الأعمال"),
            HadithItem("قال رسول الله صلى الله عليه وسلم:\n\"تَبَسُّمُكَ فِي وَجْهِ أَخِيكَ لَكَ صَدَقَةٌ\"\n(رواه البخاري)", "فضائل الأعمال")
        )
    }

    var selectedTab by remember { mutableStateOf("الكل") }
    val categories = listOf("الكل", "الصلاة", "الزكاة", "الذكر", "فضائل الأعمال")

    val filteredHadiths = remember(selectedTab) {
        if (selectedTab == "الكل") allHadiths else allHadiths.filter { it.category == selectedTab }
    }

    var currentIndex by remember(selectedTab) { mutableStateOf(0) }
    val safeIndex = if (currentIndex in filteredHadiths.indices) currentIndex else 0
    val currentHadith = filteredHadiths.getOrNull(safeIndex)

    val context = LocalContext.current

    Dialog(onDismissRequest = onClose) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = if (isDark) Color(0xFF1E1E24) else Color(0xFFFAF6F0),
            border = BorderStroke(2.dp, if (isDark) DarkGoldPrimary else Color(0xFFD4AF37)),
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header
                Text(
                    text = "من هدي النبوة (البخاري)",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isDark) DarkGoldPrimary else Color(0xFF3E2723),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                // Category Tabs
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(bottom = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    categories.forEach { cat ->
                        val isSelected = selectedTab == cat
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    if (isSelected) {
                                        if (isDark) DarkGoldPrimary else Color(0xFF3E2723)
                                    } else {
                                        if (isDark) Color(0xFF2C2D35) else Color.White
                                    }
                                )
                                .border(
                                    1.dp,
                                    (if (isDark) DarkGoldPrimary else Color(0xFFD4AF37)).copy(alpha = 0.3f),
                                    RoundedCornerShape(12.dp)
                                )
                                .clickable { selectedTab = cat }
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = cat,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) {
                                    if (isDark) Color.Black else Color.White
                                } else {
                                    if (isDark) DarkGoldText else Color(0xFF3E2723)
                                }
                            )
                        }
                    }
                }

                // Scroll Card
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (isDark) Color(0xFF25262E) else Color.White
                    ),
                    border = BorderStroke(
                        1.dp,
                        (if (isDark) DarkGoldPrimary else Color(0xFFD4AF37)).copy(alpha = 0.2f)
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(14.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            if (currentHadith != null) {
                                Text(
                                    text = currentHadith.text,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = if (isDark) DarkGoldText else Color(0xFF4E342E),
                                    textAlign = TextAlign.Center,
                                    lineHeight = 22.sp
                                )
                            } else {
                                Text(
                                    text = "لا توجد أحاديث في هذا القسم حالياً.",
                                    fontSize = 14.sp,
                                    color = if (isDark) DarkGoldText else Color(0xFF4E342E)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Navigation & Share Button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Previous Button
                    TextButton(
                        onClick = {
                            if (currentIndex > 0) currentIndex--
                        },
                        enabled = currentIndex > 0,
                        colors = ButtonDefaults.textButtonColors(
                            contentColor = if (isDark) DarkGoldPrimary else Color(0xFF3E2723)
                        )
                    ) {
                        Text("السابق", fontWeight = FontWeight.Bold)
                    }

                    // Share and Counter Row
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Share Button
                        IconButton(
                            onClick = {
                                currentHadith?.let {
                                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                        type = "text/plain"
                                        putExtra(Intent.EXTRA_TEXT, it.text)
                                    }
                                    context.startActivity(Intent.createChooser(shareIntent, "مشاركة الحديث الشريف"))
                                }
                            },
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(if (isDark) Color(0xFF2C2D35) else Color(0xFFF3EFE9)),
                        ) {
                            Icon(
                                imageVector = Icons.Default.Share,
                                contentDescription = "مشاركة الحديث",
                                tint = if (isDark) DarkGoldPrimary else Color(0xFF3E2723),
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        // Index
                        Text(
                            text = if (filteredHadiths.isNotEmpty()) "${safeIndex + 1} / ${filteredHadiths.size}" else "0 / 0",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isDark) DarkGoldText.copy(alpha = 0.8f) else Color(0xFF8D6E63)
                        )
                    }

                    // Next Button
                    TextButton(
                        onClick = {
                            if (currentIndex < filteredHadiths.size - 1) currentIndex++
                        },
                        enabled = currentIndex < filteredHadiths.size - 1,
                        colors = ButtonDefaults.textButtonColors(
                            contentColor = if (isDark) DarkGoldPrimary else Color(0xFF3E2723)
                        )
                    ) {
                        Text("التالي", fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = onClose,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isDark) DarkGoldPrimary else Color(0xFFD4AF37),
                        contentColor = if (isDark) Color.Black else Color.White
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("إغلاق", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// Audio player selection Dialog with Reciters list and Surah Index list
@Composable
fun ListenQuranDialog(
    viewModel: QuranViewModel,
    onClose: () -> Unit
) {
    val chapters by viewModel.chapters.collectAsState()
    var selectedReciterIdx by remember { mutableStateOf(0) }
    var searchQuery by remember { mutableStateOf("") }

    val filteredChapters = remember(chapters, searchQuery) {
        if (searchQuery.isBlank()) {
            chapters
        } else {
            chapters.filter { it.nameArabic.contains(searchQuery) || it.id.toString() == searchQuery }
        }
    }

    Dialog(onDismissRequest = onClose) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = Color(0xFF0F2C21), // Beautiful Deep Forest Emerald
            border = BorderStroke(1.5.dp, Color(0xFFD4AF37)),
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f)
                .padding(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "استمع للقرآن الكريم",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFD4AF37),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                )

                // 1. Reciters Horizontal Carousel Selector
                Text(
                    text = "اختر القارئ المفضل:",
                    fontSize = 12.sp,
                    color = Color.White.copy(alpha = 0.7f),
                    modifier = Modifier.padding(bottom = 6.dp)
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(bottom = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    recitersList.forEachIndexed { idx, reciter ->
                        val isSelected = selectedReciterIdx == idx
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(if (isSelected) Color(0xFFD4AF37) else Color.White.copy(alpha = 0.1f))
                                .clickable { selectedReciterIdx = idx }
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = reciter.nameArabic,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color(0xFF0F2C21) else Color.White
                            )
                        }
                    }
                }

                // 2. Surah Search Input
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("ابحث عن سورة بالاسم أو الرقم...", color = Color.White.copy(alpha = 0.4f)) },
                    textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 14.sp),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFFD4AF37),
                        unfocusedBorderColor = Color.White.copy(alpha = 0.3f),
                        focusedContainerColor = Color.White.copy(alpha = 0.05f),
                        unfocusedContainerColor = Color.White.copy(alpha = 0.02f)
                    ),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                    shape = RoundedCornerShape(12.dp),
                    trailingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Color(0xFFD4AF37)) }
                )

                // 3. Surah List
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(filteredChapters) { ch ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color.White.copy(alpha = 0.05f))
                                .clickable {
                                    viewModel.selectChapter(ch)
                                    viewModel.playFullSurah(ch.id, selectedReciterIdx)
                                    onClose()
                                }
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFFD4AF37).copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = ch.id.toString(),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFFD4AF37)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = ch.nameArabic,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Play",
                                tint = Color(0xFFD4AF37)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = onClose,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD4AF37)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("إغلاق", color = Color(0xFF0F2C21), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// Supplications and Azkar Dialog
@Composable
fun AzkarDialog(isDark: Boolean, onClose: () -> Unit) {
    var selectedTab by remember { mutableStateOf(0) } // 0: Morning, 1: Evening, 2: Post-Prayer, 3: Sleep, 4: Quranic

    val morningAzkar = remember {
        mutableStateListOf(
            AzkariItem("أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَٰهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ.", 1),
            AzkariItem("اللَّهُمَّ بِكَ أَصْبَحْنَا، وَبِكَ أَمْسَيْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ النُّشُورُ.", 1),
            AzkariItem("بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ.", 3),
            AzkariItem("يَا حَيُّ يَا قَيُّومُ بِرَحْمَتِكَ أَسْتَغِيثُ أَصْلِحْ لِي شَأْنِي كُلَّهُ وَلَا تَكِلْنِي إِلَى نَفْسِي طَرْفَةَ عَيْنٍ.", 1)
        )
    }

    val eveningAzkar = remember {
        mutableStateListOf(
            AzkariItem("أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَٰهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ.", 1),
            AzkariItem("اللَّهُمَّ بِكَ أَمْسَيْنَا، وَبِكَ أَصْبَحْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ الْمَصِيرُ.", 1),
            AzkariItem("بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ.", 3),
            AzkariItem("أَعُوذُ بِكَلِمَاتِ اللَّهِ التَّامَّاتِ مِنْ شَرِّ مَا خَلَقَ.", 3)
        )
    }

    val postPrayerAzkar = remember {
        mutableStateListOf(
            AzkariItem("أستغفر الله (ثلاثًا) .. اللهم أنت السلام ومنك السلام تباركت يا ذا الجلال والإكرام.", 1),
            AzkariItem("لا إله إلا الله وحده لا شريك له، له الملك وله الحمد وهو على كل شيء قدير، لا حول ولا قوة إلا بالله.", 1),
            AzkariItem("سبحان الله (33 مرة)، الحمد لله (33 مرة)، الله أكبر (33 مرة) .. ثم تمام المائة: لا إله إلا الله وحده لا شريك له.", 1),
            AzkariItem("قراءة آية الكرسي: اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ ۚ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ...", 1),
            AzkariItem("قراءة سورة الإخلاص، والفلق، والناس (مرة بعد الظهر والعصر والعشاء، وثلاث مرات بعد الفجر والمغرب).", 3)
        )
    }

    val sleepAzkar = remember {
        mutableStateListOf(
            AzkariItem("بِاسْمِكَ رَبِّي وَضَعْتُ جَنْبِي وَبِكَ أَرْفَعُهُ، إِنْ أَمْسَكْتَ نَفْسِي فَارْحَمْهَا، وَإِنْ أَرْسَلْتَهَا فَاحْظَهَا بِمَا تَحْفَظُ بِهِ عِبَادَكَ الصَّالِحِينَ.", 1),
            AzkariItem("اللَّهُمَّ خَلَقْتَ نَفْسِي وَأَنْتَ تَوَفَّاهَا، لَكَ مَمَاتُهَا وَمَحْيَاهَا، إِنْ أَحْيَيْتَهَا فَاحْفَظْهَا وَإِنْ أَمَتَّهَا فَاغْفِرْ لَهَا.", 1),
            AzkariItem("اللَّهُمَّ قِنِي عَذَابَكَ يَوْمَ تَبْعَثُ عِبَادَكَ.", 3),
            AzkariItem("بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا.", 1),
            AzkariItem("قراءة سورة الملك المنجية من عذاب القبر.", 1)
        )
    }

    val quranicDuas = remember {
        mutableStateListOf(
            AzkariItem("رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ.", 1),
            AzkariItem("رَبَّنَا لَا تُزِغْ قُلُوبَنَا بَعْدَ إِذْ هَدَيْتَنَا وَهَبْ لَنَا مِنْ لَدُنْكَ رَحْمَةً إِنَّكَ أَنْتَ الْوَهَّابُ.", 1),
            AzkariItem("رَبَّنَا اغْفِرْ لَنَا ذُنُوبَنَا وَإِسْرَافَنَا فِي أَمْرِنَا وَثَبِّتْ أَقْدَامَنَا وَانْصُرْنَا عَلَى الْقَوْمِ الْكَافِرِينَ.", 1),
            AzkariItem("رَبِّ اجْعَلْنِي مُقِيمَ الصَّلَاةِ وَمِنْ ذُرِّيَّتِي رَبَّنَا وَتَقَبَّلْ دُعَاءِ.", 1)
        )
    }

    val currentList = when (selectedTab) {
        0 -> morningAzkar
        1 -> eveningAzkar
        2 -> postPrayerAzkar
        3 -> sleepAzkar
        else -> quranicDuas
    }

    val primaryColor = if (isDark) DarkGoldPrimary else Color(0xFF900C3F)
    val textPrimary = if (isDark) DarkGoldText else Color(0xFF4A148C)

    Dialog(onDismissRequest = onClose) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = if (isDark) Color(0xFF1E1E24) else Color(0xFFFAF6F0),
            border = BorderStroke(1.5.dp, primaryColor),
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f)
                .padding(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "الأذكار والأدعية اليومية",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = primaryColor,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                )

                // Tab selectors - Scrollable Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(bottom = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("أذكار الصباح", "أذكار المساء", "بعد الصلاة", "أذكار النوم", "أدعية قرآنية").forEachIndexed { index, label ->
                        val isSelected = selectedTab == index
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isSelected) primaryColor else (if (isDark) Color(0xFF2C2D35) else Color.White))
                                .border(1.dp, primaryColor.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                                .clickable { selectedTab = index }
                                .padding(horizontal = 14.dp, vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = label,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) (if (isDark) Color.Black else Color.White) else primaryColor
                            )
                        }
                    }
                }

                // Scrollable List of items with click/tap counts!
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(currentList) { item ->
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (isDark) Color(0xFF25262E) else Color.White
                            ),
                            border = BorderStroke(
                                1.dp,
                                primaryColor.copy(alpha = 0.15f)
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    if (item.currentCount < item.targetCount) {
                                        item.currentCount++
                                    }
                                }
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = item.text,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = textPrimary,
                                    textAlign = TextAlign.Center,
                                    lineHeight = 22.sp
                                )

                                Spacer(modifier = Modifier.height(10.dp))

                                // Progress Indicators
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "التكرار المطلوبة: ${item.targetCount}",
                                        fontSize = 11.sp,
                                        color = if (isDark) DarkGoldText.copy(alpha = 0.6f) else Color.Gray
                                    )

                                    // Luminous Circular Badge
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .background(
                                                if (item.currentCount >= item.targetCount) Color(0xFF2E7D32) else primaryColor
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "${item.currentCount}/${item.targetCount}",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (item.currentCount >= item.targetCount || !isDark) Color.White else Color.Black
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Reset Button
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = {
                            currentList.forEach { it.currentCount = 0 }
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = primaryColor),
                        border = BorderStroke(1.dp, primaryColor)
                    ) {
                        Text("إعادة تصفير العداد", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = onClose,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = primaryColor,
                            contentColor = if (isDark) Color.Black else Color.White
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("إغلاق", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

class AzkariItem(
    val text: String,
    val targetCount: Int
) {
    var currentCount by mutableStateOf(0)
}

// Live Quran Radios Dialog with Direct Streaming integrations
@Composable
fun RadioDialog(
    viewModel: QuranViewModel,
    isDark: Boolean,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    val radioStations = listOf(
        RadioStation(
            name = "راديو قرآن",
            urls = listOf(
                "http://live.mp3quran.net:8006/;",
                "http://live.mp3quran.net:9992/;"
            )
        ),
        RadioStation(
            name = "إذاعة القرآن الكريم المصرية",
            urls = listOf(
                "https://rn.maspero.eg/radio/quran",
                "https://live.maspero.eg/hls/quran.m3u8"
            ),
            isDevelopmentOnly = true
        ),
        RadioStation(
            name = "إذاعة القرآن الكريم السعودية",
            urls = listOf(
                "http://live.mp3quran.net:9992/;",
                "https://streaming.sbc.sa/hls/quran.m3u8",
                "https://stream.sba.sa/radio/quran/icecast.audio"
            )
        ),
        RadioStation(
            name = "تلاوات خاشعة ومميزة",
            urls = emptyList(),
            isDevelopmentOnly = true
        ),
        RadioStation(
            name = "تفسير القرآن الكريم الصوتي",
            urls = emptyList(),
            isDevelopmentOnly = true
        )
    )

    val isPlaying by viewModel.isPlaying.collectAsState()
    val isRadioBuffering by viewModel.isRadioBuffering.collectAsState()
    val activeRadioStationName by viewModel.activeRadioStationName.collectAsState()
    val primaryColor = if (isDark) DarkGoldPrimary else Color(0xFF900C3F)
    val textPrimary = if (isDark) DarkGoldText else Color(0xFF4A148C)

    Dialog(onDismissRequest = onClose) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = if (isDark) Color(0xFF1E1E24) else Color(0xFFFAF6F0),
            border = BorderStroke(1.5.dp, primaryColor),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "إذاعة القرآن الكريم المباشرة",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = primaryColor,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                )

                Text(
                    text = "اختر المحطة الصوتية للبث الحي:",
                    fontSize = 12.sp,
                    color = if (isDark) Color.White.copy(alpha = 0.6f) else Color.DarkGray,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                // List
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(radioStations) { station ->
                        val isCurrentActive = activeRadioStationName == station.name
                        val isThisBuffering = isCurrentActive && isRadioBuffering
                        val isThisPlaying = isCurrentActive && isPlaying && !isRadioBuffering

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    if (isCurrentActive) {
                                        primaryColor.copy(alpha = 0.1f)
                                    } else if (isDark) {
                                        Color.White.copy(alpha = 0.05f)
                                    } else {
                                        Color.White
                                    }
                                )
                                .border(
                                    width = if (isCurrentActive) 1.5.dp else 0.5.dp,
                                    color = if (isCurrentActive) primaryColor else if (isDark) Color.White.copy(alpha = 0.1f) else primaryColor.copy(alpha = 0.15f),
                                    shape = RoundedCornerShape(12.dp)
                                )
                                .clickable {
                                    if (station.isDevelopmentOnly) {
                                        android.widget.Toast.makeText(context, "قيد التطوير حالياً", android.widget.Toast.LENGTH_SHORT).show()
                                    } else {
                                        if (isCurrentActive && (isPlaying || isRadioBuffering)) {
                                            viewModel.stopAudio()
                                        } else {
                                            viewModel.playRadioStream(station.urls, station.name)
                                        }
                                    }
                                }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Icon(
                                    imageVector = if (isThisPlaying) Icons.Default.VolumeUp else Icons.Default.Radio,
                                    contentDescription = null,
                                    tint = primaryColor,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = station.name,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isCurrentActive) primaryColor else if (isDark) Color.White else Color.Black,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            if (isThisBuffering) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(24.dp),
                                    color = primaryColor,
                                    strokeWidth = 2.dp
                                )
                            } else {
                                Icon(
                                    imageVector = if (isThisPlaying) Icons.Default.StopCircle else Icons.Default.PlayCircle,
                                    contentDescription = if (isThisPlaying) "Stop" else "Play",
                                    tint = if (isThisPlaying) Color.Red else primaryColor
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Control panel if playing or buffering
                if (isPlaying || isRadioBuffering) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = if (isDark) Color(0xFF152A1C) else Color(0xFFE2EFE4)),
                        border = BorderStroke(1.dp, primaryColor.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            // Professional album art image replacing any default placeholders
                            Image(
                                painter = painterResource(id = R.drawable.img_app_icon),
                                contentDescription = "Holy Quran Radio Cover",
                                modifier = Modifier
                                    .size(100.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .border(1.dp, primaryColor.copy(alpha = 0.5f), RoundedCornerShape(12.dp)),
                                contentScale = ContentScale.Crop
                            )
                            
                            Spacer(modifier = Modifier.height(10.dp))
                            
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (isRadioBuffering) "جاري الاتصال بالإذاعة والتحميل..." else "جاري تشغيل: $activeRadioStationName",
                                    fontSize = 13.sp,
                                    color = if (isDark) DarkGoldPrimary else Color(0xFF1B4D22),
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.weight(1f)
                                )

                                IconButton(
                                    onClick = { viewModel.stopAudio() },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.StopCircle,
                                        contentDescription = "Stop",
                                        tint = Color.Red,
                                        modifier = Modifier.size(28.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                Button(
                    onClick = {
                        onClose()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = primaryColor,
                        contentColor = if (isDark) Color.Black else Color.White
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("إغلاق", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun QuranRadioDialog(
    viewModel: QuranViewModel,
    isDark: Boolean,
    onClose: () -> Unit
) {
    RadioDialog(viewModel = viewModel, isDark = isDark, onClose = onClose)
}

data class RadioStation(
    val name: String,
    val urls: List<String>,
    val isDevelopmentOnly: Boolean = false
)

// Vocabulary Explainer with Search & Indexes
@Composable
fun VocabularyExplorerDialog(
    viewModel: QuranViewModel,
    chapters: List<ChapterEntity>,
    isDark: Boolean,
    onClose: () -> Unit
) {
    var searchWordQuery by remember { mutableStateOf("") }
    var selectedChapterIdx by remember { mutableStateOf<ChapterEntity?>(null) }
    var displayedWordMeanings by remember { mutableStateOf<List<Pair<String, WordMeaning>>>(emptyList()) }

    val scope = rememberCoroutineScope()

    // Load vocabularies for selected Chapter
    LaunchedEffect(selectedChapterIdx) {
        selectedChapterIdx?.let { chapter ->
            // Extract from its verses
            val list = mutableListOf<Pair<String, WordMeaning>>()
            viewModel.verses.value.forEach { verse ->
                val meanings = viewModel.parseWordMeanings(verse.wordMeaningsJson)
                meanings.forEach { m ->
                    val cleaned = m.textUthmani.replace(Regex("[0-9\\u0660-\\u0669\\u06F0-\\u06F9\\uFD3E\\uFD3F\\s\\p{Punct}]"), "")
                    if (cleaned.isNotEmpty()) {
                        list.add(Pair(verse.verseKey, m))
                    }
                }
            }
            displayedWordMeanings = list
        }
    }

    // Auto-select first chapter if null
    if (selectedChapterIdx == null && chapters.isNotEmpty()) {
        selectedChapterIdx = chapters.first()
    }

    val filteredVocabList = remember(displayedWordMeanings, searchWordQuery) {
        if (searchWordQuery.isBlank()) {
            displayedWordMeanings
        } else {
            displayedWordMeanings.filter {
                it.second.textUthmani.contains(searchWordQuery) ||
                it.second.meaning.contains(searchWordQuery) ||
                it.first.contains(searchWordQuery) // matches "1:1" verse key etc
            }
        }
    }

    Dialog(onDismissRequest = onClose) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = if (isDark) DarkGoldSurface else LightGoldSurface,
            border = BorderStroke(1.5.dp, (if (isDark) DarkGoldPrimary else LightGoldPrimary)),
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f)
                .padding(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "معاني مفردات القرآن الكريم",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isDark) DarkGoldPrimary else LightGoldPrimary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                )

                // 1. Chapter selection dropdown box (scrollable line)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(bottom = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    chapters.forEach { ch ->
                        val isSelected = selectedChapterIdx?.id == ch.id
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(
                                    if (isSelected) {
                                        if (isDark) DarkGoldPrimary else LightGoldPrimary
                                    } else {
                                        (if (isDark) DarkGoldPrimary else LightGoldPrimary).copy(alpha = 0.1f)
                                    }
                                )
                                .clickable {
                                    selectedChapterIdx = ch
                                    viewModel.selectChapter(ch)
                                }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = ch.nameArabic,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color.Black else (if (isDark) DarkGoldText else LightGoldText)
                            )
                        }
                    }
                }

                // 2. Search Text Field
                OutlinedTextField(
                    value = searchWordQuery,
                    onValueChange = { searchWordQuery = it },
                    placeholder = { Text("ابحث بكلمة، رقم آية (مثل 1:1) أو معنى...", color = (if (isDark) DarkGoldText else LightGoldText).copy(alpha = 0.5f)) },
                    singleLine = true,
                    textStyle = androidx.compose.ui.text.TextStyle(color = if (isDark) DarkGoldText else LightGoldText, fontSize = 13.sp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = if (isDark) DarkGoldPrimary else LightGoldPrimary,
                        unfocusedBorderColor = (if (isDark) DarkGoldPrimary else LightGoldPrimary).copy(alpha = 0.3f)
                    ),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                    shape = RoundedCornerShape(12.dp),
                    trailingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = if (isDark) DarkGoldPrimary else LightGoldPrimary) }
                )

                // 3. Vocab List
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (filteredVocabList.isEmpty()) {
                        item {
                            Box(
                                modifier = Modifier.fillMaxWidth().padding(24.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "لا توجد معاني مطابقة للمفردة.",
                                    fontSize = 13.sp,
                                    color = (if (isDark) DarkGoldText else LightGoldText).copy(alpha = 0.6f)
                                )
                            }
                        }
                    } else {
                        items(filteredVocabList) { (verseKey, m) ->
                            Card(
                                colors = CardDefaults.cardColors(
                                    containerColor = (if (isDark) DarkGoldPrimary else LightGoldPrimary).copy(alpha = 0.05f)
                                ),
                                border = BorderStroke(1.dp, (if (isDark) DarkGoldPrimary else LightGoldPrimary).copy(alpha = 0.15f)),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = m.textUthmani,
                                            fontSize = 18.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isDark) DarkGoldPrimary else LightGoldPrimary,
                                            textAlign = TextAlign.Right,
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = m.meaning,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Medium,
                                            color = if (isDark) DarkGoldText else LightGoldText,
                                            textAlign = TextAlign.Right,
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    }

                                    Spacer(modifier = Modifier.width(16.dp))

                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(8.dp))
                                            .background((if (isDark) DarkGoldPrimary else LightGoldPrimary).copy(alpha = 0.15f))
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = "آية $verseKey",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isDark) DarkGoldPrimary else LightGoldPrimary
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = onClose,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isDark) DarkGoldPrimary else LightGoldPrimary
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("إغلاق", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun AppSupportDialog(
    isDark: Boolean,
    appLanguage: String,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    val primaryColor = if (isDark) DarkGoldPrimary else Color(0xFF900C3F)
    val cardBackground = if (isDark) Color(0xFF1E1E24) else Color(0xFFFAF6F0)
    val innerCardBg = if (isDark) Color.White.copy(alpha = 0.05f) else Color.White
    
    Dialog(onDismissRequest = onClose) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = cardBackground,
            border = BorderStroke(1.5.dp, primaryColor),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Header
                Icon(
                    imageVector = Icons.Default.Call,
                    contentDescription = null,
                    tint = primaryColor,
                    modifier = Modifier.size(48.dp)
                )
                
                Text(
                    text = getAppString("support_app", appLanguage),
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = primaryColor,
                    textAlign = TextAlign.Center
                )
                
                Divider(color = primaryColor.copy(alpha = 0.2f), thickness = 1.dp)
                
                Text(
                    text = "إذا واجهت أي مشكلة أو كان لديك استفسار، يسعدنا تواصلك معنا مباشرة عبر خيارات الدعم المتاحة في القائمة السريعة.",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isDark) Color.White else Color.DarkGray,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
                
                // Button to directly report issue
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            val msg = "السلام عليكم، أود الإبلاغ عن مشكلة في تطبيق القرآن الكريم الذهبي"
                            val uri = android.net.Uri.parse("https://api.whatsapp.com/send?phone=201507686172&text=${android.net.Uri.encode(msg)}")
                            val intent = Intent(Intent.ACTION_VIEW, uri)
                            try {
                                context.startActivity(intent)
                            } catch (e: Exception) {
                                Toast.makeText(context, "لم نتمكن من فتح تطبيق واتساب", Toast.LENGTH_SHORT).show()
                            }
                        },
                    colors = CardDefaults.cardColors(containerColor = innerCardBg),
                    border = BorderStroke(0.5.dp, primaryColor.copy(alpha = 0.3f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = primaryColor,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = getAppString("report_issue", appLanguage),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isDark) Color.White else Color.Black
                        )
                    }
                }
                
                // Close Button
                Button(
                    onClick = onClose,
                    colors = ButtonDefaults.buttonColors(containerColor = primaryColor),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = getAppString("close", appLanguage),
                        color = if (isDark) Color.Black else Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun CharityDialog(
    isDark: Boolean,
    appLanguage: String,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = androidx.compose.ui.platform.LocalClipboardManager.current
    
    // States for expanding sections
    var showCharitySection by remember { mutableStateOf(true) }
    var activeSupportMethod by remember { mutableStateOf<String?>(null) } // "instapay" or "bank"
    
    val primaryColor = if (isDark) DarkGoldPrimary else Color(0xFF900C3F)
    val cardBackground = if (isDark) Color(0xFF1E1E24) else Color(0xFFFAF6F0)
    val innerCardBg = if (isDark) Color.White.copy(alpha = 0.05f) else Color.White
    
    Dialog(onDismissRequest = onClose) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = cardBackground,
            border = BorderStroke(1.5.dp, primaryColor),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Header
                Icon(
                    imageVector = Icons.Default.Favorite,
                    contentDescription = null,
                    tint = primaryColor,
                    modifier = Modifier.size(48.dp)
                )
                
                Text(
                    text = getAppString("contribute_goodness", appLanguage),
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = primaryColor,
                    textAlign = TextAlign.Center
                )
                
                Divider(color = primaryColor.copy(alpha = 0.2f), thickness = 1.dp)
                
                // Contact Us inside Contribute to Goodness
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            val msg = "السلام عليكم، أريد التواصل بخصوص تطبيق القرآن الكريم الذهبي"
                            val uri = android.net.Uri.parse("https://api.whatsapp.com/send?phone=201507686172&text=${android.net.Uri.encode(msg)}")
                            val intent = Intent(Intent.ACTION_VIEW, uri)
                            try {
                                context.startActivity(intent)
                            } catch (e: Exception) {
                                Toast.makeText(context, "لم نتمكن من فتح تطبيق واتساب", Toast.LENGTH_SHORT).show()
                            }
                        },
                    colors = CardDefaults.cardColors(containerColor = innerCardBg),
                    border = BorderStroke(1.dp, primaryColor.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Call,
                            contentDescription = null,
                            tint = primaryColor,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = getAppString("contact_us", appLanguage) + " (تواصل معنا)",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isDark) Color.White else Color.Black
                        )
                    }
                }

                // Donation Message and payment options
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(primaryColor.copy(alpha = 0.05f), RoundedCornerShape(16.dp))
                        .border(0.5.dp, primaryColor.copy(alpha = 0.2f), RoundedCornerShape(16.dp))
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = getAppString("charity_msg", appLanguage),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isDark) Color.White else Color.DarkGray,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Instapay Button
                        Button(
                            onClick = { activeSupportMethod = if (activeSupportMethod == "instapay") null else "instapay" },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (activeSupportMethod == "instapay") primaryColor else primaryColor.copy(alpha = 0.15f),
                                contentColor = if (activeSupportMethod == "instapay") Color.White else primaryColor
                            ),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = getAppString("instapay", appLanguage),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        
                        // Bank Button
                        Button(
                            onClick = { activeSupportMethod = if (activeSupportMethod == "bank") null else "bank" },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (activeSupportMethod == "bank") primaryColor else primaryColor.copy(alpha = 0.15f),
                                contentColor = if (activeSupportMethod == "bank") Color.White else primaryColor
                            ),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = getAppString("bank", appLanguage),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    
                    // Expanding active support method details
                    AnimatedVisibility(
                        visible = activeSupportMethod != null,
                        enter = fadeIn() + expandVertically(),
                        exit = fadeOut() + shrinkVertically()
                    ) {
                        when (activeSupportMethod) {
                            "instapay" -> {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(innerCardBg, RoundedCornerShape(12.dp))
                                        .border(0.5.dp, primaryColor.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                                        .padding(12.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(
                                        text = getAppString("instapay_title", appLanguage),
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = primaryColor
                                    )
                                    
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = "alaaezz010@instapay",
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Medium,
                                            color = if (isDark) Color.White else Color.Black,
                                            modifier = Modifier.weight(1f)
                                        )
                                        
                                        IconButton(
                                            onClick = {
                                                clipboardManager.setText(androidx.compose.ui.text.AnnotatedString("alaaezz010@instapay"))
                                                Toast.makeText(context, getAppString("copied", appLanguage), Toast.LENGTH_SHORT).show()
                                            }
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.ContentCopy,
                                                contentDescription = getAppString("copy", appLanguage),
                                                tint = primaryColor,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }
                            }
                            "bank" -> {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(innerCardBg, RoundedCornerShape(12.dp))
                                        .border(0.5.dp, primaryColor.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                                        .padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Text(
                                        text = getAppString("bank_title", appLanguage),
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = primaryColor,
                                        modifier = Modifier.align(Alignment.CenterHorizontally)
                                    )
                                    
                                    // Row 1: Name
                                    BankDetailRow(
                                        label = getAppString("name", appLanguage),
                                        value = "Alaa Farouk Mohamed Ezz Abdallah",
                                        primaryColor = primaryColor,
                                        isDark = isDark,
                                        onCopy = {
                                            clipboardManager.setText(androidx.compose.ui.text.AnnotatedString("Alaa Farouk Mohamed Ezz Abdallah"))
                                            Toast.makeText(context, getAppString("copied", appLanguage), Toast.LENGTH_SHORT).show()
                                        },
                                        copyDesc = getAppString("copy", appLanguage)
                                    )
                                    
                                    // Row 2: IBAN
                                    BankDetailRow(
                                        label = getAppString("iban", appLanguage),
                                        value = "EG650005301900000319135065001",
                                        primaryColor = primaryColor,
                                        isDark = isDark,
                                        onCopy = {
                                            clipboardManager.setText(androidx.compose.ui.text.AnnotatedString("EG650005301900000319135065001"))
                                            Toast.makeText(context, getAppString("copied", appLanguage), Toast.LENGTH_SHORT).show()
                                        },
                                        copyDesc = getAppString("copy", appLanguage)
                                    )
                                    
                                    // Row 3: Swift
                                    BankDetailRow(
                                        label = getAppString("swift_code", appLanguage),
                                        value = "ALEXEGCXXXX",
                                        primaryColor = primaryColor,
                                        isDark = isDark,
                                        onCopy = {
                                            clipboardManager.setText(androidx.compose.ui.text.AnnotatedString("ALEXEGCXXXX"))
                                            Toast.makeText(context, getAppString("copied", appLanguage), Toast.LENGTH_SHORT).show()
                                        },
                                        copyDesc = getAppString("copy", appLanguage)
                                    )
                                }
                            }
                        }
                    }
                }
                
                // Close Button
                Button(
                    onClick = onClose,
                    colors = ButtonDefaults.buttonColors(containerColor = primaryColor),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = getAppString("close", appLanguage),
                        color = if (isDark) Color.Black else Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun BankDetailRow(
    label: String,
    value: String,
    primaryColor: Color,
    isDark: Boolean,
    onCopy: () -> Unit,
    copyDesc: String
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = primaryColor.copy(alpha = 0.8f)
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = value,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = if (isDark) Color.White else Color.Black,
                modifier = Modifier.weight(1f)
            )
            IconButton(
                onClick = onCopy,
                modifier = Modifier.size(32.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.ContentCopy,
                    contentDescription = copyDesc,
                    tint = primaryColor,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}
