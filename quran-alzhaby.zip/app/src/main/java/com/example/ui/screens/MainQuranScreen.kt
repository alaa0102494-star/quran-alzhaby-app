package com.example.ui.screens

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.window.Dialog
import com.example.data.db.ChapterEntity
import com.example.data.db.BookmarkEntity
import com.example.data.db.VerseEntity
import com.example.data.db.WordMeaning
import com.example.ui.theme.*
import com.example.ui.viewmodel.QuranViewModel
import com.example.ui.viewmodel.recitersList
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainQuranScreen(
    viewModel: QuranViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)

    // Viewmodel States
    val chapters by viewModel.chapters.collectAsState()
    val verses by viewModel.verses.collectAsState()
    val translations by viewModel.translations.collectAsState()
    val tafsirs by viewModel.tafsirs.collectAsState()
    val bookmarks by viewModel.bookmarks.collectAsState()
    val selectedChapter by viewModel.selectedChapter.collectAsState()
    val isDarkTheme by viewModel.isDarkTheme.collectAsState()
    val bgColorVal by viewModel.bgColor.collectAsState()
    val textSizeVal by viewModel.textSize.collectAsState()
    val brightnessVal by viewModel.brightness.collectAsState()
    val teacherReciterFolder by viewModel.teacherReciterFolder.collectAsState()
    val activeTranslationId by viewModel.translationLanguageId.collectAsState()
    val availableTranslations by viewModel.availableTranslations.collectAsState()
    val appLanguage by viewModel.appLanguage.collectAsState()
    val isTeacherModeEnabled by viewModel.isTeacherModeEnabled.collectAsState()
    val showWelcomeDashboard by viewModel.showWelcomeDashboard.collectAsState()

    // Search and Selection
    val searchQuery by viewModel.searchQuery.collectAsState()
    val searchResults by viewModel.searchResults.collectAsState()
    val highlightedVerseKey by viewModel.highlightedVerseKey.collectAsState()
    val highlightedWordText by viewModel.highlightedWordText.collectAsState()
    val activeWordMeaning by viewModel.activeWordMeaning.collectAsState()

    // Audio State
    val isPlaying by viewModel.isPlaying.collectAsState()
    val currentAudioProgress by viewModel.currentAudioProgress.collectAsState()
    val audioDuration by viewModel.audioDuration.collectAsState()
    val currentAudioTime by viewModel.currentAudioTime.collectAsState()
    val selectedReciterIndex by viewModel.selectedReciterIndex.collectAsState()
    val errorMessage by viewModel.errorMessage.collectAsState()

    // Dialog state controllers
    var showBookmarksDialog by remember { mutableStateOf(false) }
    var showTranslationDialog by remember { mutableStateOf(false) }
    var showSettingsDialog by remember { mutableStateOf(false) }
    var showSearchDialog by remember { mutableStateOf(false) }
    var showDuaaDialog by remember { mutableStateOf(false) }
    var showSurahIndexDialog by remember { mutableStateOf(false) }
    var showJuzIndexDialog by remember { mutableStateOf(false) }
    var showLanguageDialog by remember { mutableStateOf(false) }
    var showVocabularyDialog by remember { mutableStateOf(false) }
    var showAboutDialog by remember { mutableStateOf(false) }
    var showUpdateDialog by remember { mutableStateOf(false) }
    var floatingSurahName by remember { mutableStateOf<String?>(null) }
    var currentSubScreenTafseer by remember { mutableStateOf(false) }
    var initialTafseerVerseNumber by remember { mutableStateOf<Int?>(null) }
    val initialScrollIndex = remember(selectedChapter?.id) {
        val savedChapterId = viewModel.getLastReadChapterId()
        if (savedChapterId == selectedChapter?.id) {
            viewModel.getLastReadScrollIndex()
        } else {
            0
        }
    }
    val lazyListState = remember(selectedChapter?.id) { LazyListState(firstVisibleItemIndex = initialScrollIndex) }
    var isInitialRestoreDone by remember(selectedChapter?.id) { mutableStateOf(false) }
    val drawerOrder = remember {
        mutableStateListOf<String>().apply {
            addAll(viewModel.getDrawerOrder())
        }
    }

    var draggedIndex by remember { mutableStateOf<Int?>(null) }
    var dragOffsetY by remember { mutableStateOf(0f) }
    val density = androidx.compose.ui.platform.LocalDensity.current

    fun getDrawerItemIcon(key: String): androidx.compose.ui.graphics.vector.ImageVector {
        return when (key) {
            "surah_index" -> Icons.Default.FormatListNumbered
            "juz_index" -> Icons.Default.GridOn
            "tafseer" -> Icons.Default.MenuBook
            "bookmarks" -> Icons.Default.Bookmark
            "duaa_khatm" -> Icons.Default.Star
            "search" -> Icons.Default.Search
            "quran_vocabulary" -> Icons.Default.Translate
            "settings" -> Icons.Default.Settings
            "app_language" -> Icons.Default.Language
            "update_app" -> Icons.Default.SystemUpdate
            "other_apps" -> Icons.Default.Apps
            "about" -> Icons.Default.Info
            "share" -> Icons.Default.Share
            else -> Icons.Default.MenuBook
        }
    }

    fun onDrawerItemClick(key: String) {
        scope.launch { drawerState.close() }
        when (key) {
            "surah_index" -> showSurahIndexDialog = true
            "juz_index" -> showJuzIndexDialog = true
            "tafseer" -> currentSubScreenTafseer = true
            "bookmarks" -> showBookmarksDialog = true
            "duaa_khatm" -> showDuaaDialog = true
            "search" -> showSearchDialog = true
            "quran_vocabulary" -> showVocabularyDialog = true
            "settings" -> showSettingsDialog = true
            "app_language" -> showLanguageDialog = true
            "update_app" -> {
                try {
                    val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://thegoldenquran.blogspot.com/2026/07/blog-post.html"))
                    context.startActivity(intent)
                } catch (e: Exception) {
                    viewModel.errorMessage.value = "لا يمكن فتح رابط التحديث حالياً"
                }
            }
            "other_apps" -> {
                try {
                    val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://thegoldenquran.blogspot.com/2026/07/blog-post_05.html"))
                    context.startActivity(intent)
                } catch (e: Exception) {
                    viewModel.errorMessage.value = "لا يمكن فتح رابط التطبيقات الأخرى حالياً"
                }
            }
            "about" -> showAboutDialog = true
            "share" -> {
                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, getAppString("app_name", appLanguage))
                    putExtra(Intent.EXTRA_TEXT, "قم بتحميل تطبيق " + getAppString("app_name", appLanguage) + " مجاناً واستمتع بالمصحف كاملاً مع التفسير الميسر، أسباب النزول، معاني الكلمات التفاعلية، والاستماع لأشهر القراء!")
                }
                context.startActivity(Intent.createChooser(shareIntent, "مشاركة عبر"))
            }
        }
    }

    fun getDragModifier(index: Int): Modifier {
        return Modifier.pointerInput(index) {
            detectDragGestures(
                onDragStart = {
                    draggedIndex = index
                    dragOffsetY = 0f
                },
                onDragEnd = {
                    draggedIndex = null
                    dragOffsetY = 0f
                    viewModel.saveDrawerOrder(drawerOrder.toList())
                },
                onDragCancel = {
                    draggedIndex = null
                    dragOffsetY = 0f
                },
                onDrag = { change, dragAmount ->
                    change.consume()
                    dragOffsetY += dragAmount.y
                    
                    val itemHeightPx = 56.dp.toPx()
                    val threshold = itemHeightPx * 0.7f
                    if (dragOffsetY > threshold && index < drawerOrder.lastIndex) {
                        // Swap with next
                        val temp = drawerOrder[index]
                        drawerOrder[index] = drawerOrder[index + 1]
                        drawerOrder[index + 1] = temp
                        draggedIndex = index + 1
                        dragOffsetY -= itemHeightPx
                        viewModel.saveDrawerOrder(drawerOrder.toList())
                    } else if (dragOffsetY < -threshold && index > 0) {
                        // Swap with previous
                        val temp = drawerOrder[index]
                        drawerOrder[index] = drawerOrder[index - 1]
                        drawerOrder[index - 1] = temp
                        draggedIndex = index - 1
                        dragOffsetY += itemHeightPx
                        viewModel.saveDrawerOrder(drawerOrder.toList())
                    }
                }
            )
        }
    }
    var activeBookmarkTarget by remember { mutableStateOf<Pair<Int, Int>?>(null) } // Pair(chapterId, verseNumber)

    var showTopBanner by remember { mutableStateOf(true) }
    var showAudioBottomBar by remember { mutableStateOf(false) }

    val pagerState = rememberPagerState(
        initialPage = 0,
        pageCount = { chapters.size }
    )

    // Synchronize selected chapter from other UI selections to the pager
    LaunchedEffect(selectedChapter, chapters) {
        val index = chapters.indexOfFirst { it.id == selectedChapter?.id }
        if (index >= 0 && pagerState.currentPage != index) {
            pagerState.scrollToPage(index)
        }
    }

    // Synchronize pager swipe to selected chapter
    LaunchedEffect(pagerState.currentPage, pagerState.isScrollInProgress, chapters) {
        if (!pagerState.isScrollInProgress) {
            if (chapters.isNotEmpty() && pagerState.currentPage < chapters.size) {
                val chapter = chapters[pagerState.currentPage]
                if (selectedChapter?.id != chapter.id) {
                    viewModel.selectChapter(chapter)
                }
            }
        }
    }

    // Reset scroll to 0 when selectedChapter changes, or scroll to highlighted verse if any
    LaunchedEffect(selectedChapter, verses) {
        if (selectedChapter != null) {
            if (verses.isNotEmpty()) {
                val targetKey = viewModel.highlightedVerseKey.value
                if (targetKey != null && targetKey.startsWith("${selectedChapter!!.id}:")) {
                    val verseIndex = verses.indexOfFirst { it.verseKey == targetKey }
                    if (verseIndex >= 0) {
                        val bismillahOffset = if (selectedChapter?.bismillahPre == true && selectedChapter?.id != 9) 1 else 0
                        val headerOffset = 1 + bismillahOffset
                        lazyListState.scrollToItem(verseIndex + headerOffset)
                    }
                } else if (!isInitialRestoreDone) {
                    val savedChapterId = viewModel.getLastReadChapterId()
                    if (savedChapterId == selectedChapter!!.id) {
                        val savedIndex = viewModel.getLastReadScrollIndex()
                        if (savedIndex > 0) {
                            try {
                                lazyListState.scrollToItem(savedIndex)
                            } catch (e: Exception) {
                                // ignore
                            }
                        }
                    }
                    isInitialRestoreDone = true
                } else {
                    lazyListState.scrollToItem(0)
                }
            }
        }
    }

    // Scroll to highlighted verse immediately when highlightedVerseKey changes
    LaunchedEffect(highlightedVerseKey) {
        val targetKey = highlightedVerseKey
        if (targetKey != null && selectedChapter != null && targetKey.startsWith("${selectedChapter!!.id}:")) {
            val verseIndex = verses.indexOfFirst { it.verseKey == targetKey }
            if (verseIndex >= 0) {
                val bismillahOffset = if (selectedChapter?.bismillahPre == true && selectedChapter?.id != 9) 1 else 0
                val headerOffset = 1 + bismillahOffset
                try {
                    lazyListState.animateScrollToItem(verseIndex + headerOffset)
                } catch (e: Exception) {
                    lazyListState.scrollToItem(verseIndex + headerOffset)
                }
            }
        }
    }

    // Temporary floating Surah name overlay
    LaunchedEffect(selectedChapter) {
        if (selectedChapter != null) {
            floatingSurahName = selectedChapter?.nameArabic
            kotlinx.coroutines.delay(2000)
            floatingSurahName = null
        }
    }

    // Listen for error and show snackbar / toast
    LaunchedEffect(errorMessage) {
        errorMessage?.let {
            android.widget.Toast.makeText(context, it, android.widget.Toast.LENGTH_LONG).show()
            viewModel.errorMessage.value = null
        }
    }

    // Set color values based on theme / custom bg selection
    val computedBgColor = Color(bgColorVal)
    val computedTextColor = if (isDarkTheme) DarkGoldText else LightGoldText

    CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides LayoutDirection.Rtl) {
        if (!showWelcomeDashboard) {
            BackHandler {
                if (currentSubScreenTafseer) {
                    initialTafseerVerseNumber = null
                    currentSubScreenTafseer = false
                } else {
                    viewModel.showWelcomeDashboard.value = true
                }
            }
        }

        if (showWelcomeDashboard) {
            StartScreen(
                viewModel = viewModel,
                appLanguage = appLanguage,
                onOpenQuran = { viewModel.showWelcomeDashboard.value = false }
            )
        } else {
            ModalNavigationDrawer(
                drawerState = drawerState,
                drawerContent = {
                    ModalDrawerSheet(
                        drawerContainerColor = if (isDarkTheme) DarkGoldSurface else LightGoldSurface,
                        modifier = Modifier.width(300.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(
                                            Color(0xFFD4AF37).copy(alpha = 0.2f),
                                            Color.Transparent
                                        )
                                    )
                                )
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.clickable {
                                    scope.launch { drawerState.close() }
                                    viewModel.showWelcomeDashboard.value = true
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Default.MenuBook,
                                    contentDescription = "Logo",
                                    tint = if (isDarkTheme) DarkGoldPrimary else LightGoldPrimary,
                                    modifier = Modifier.size(64.dp)
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    text = getAppString("app_name", appLanguage),
                                    fontSize = 22.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isDarkTheme) DarkGoldPrimary else LightGoldPrimary
                                )
                            }
                        }

                        HorizontalDivider(color = (if (isDarkTheme) DarkGoldPrimary else LightGoldPrimary).copy(alpha = 0.3f))

                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            item {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.DragHandle,
                                        contentDescription = "سحب",
                                        tint = (if (isDarkTheme) DarkGoldPrimary else LightGoldPrimary).copy(alpha = 0.6f),
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (appLanguage == "ar") "اسحب المقبض لإعادة ترتيب القائمة" else "Drag handle to reorder list",
                                        fontSize = 12.sp,
                                        color = (if (isDarkTheme) DarkGoldText else LightGoldText).copy(alpha = 0.6f),
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }

                            itemsIndexed(drawerOrder, key = { _, key -> key }) { index, key ->
                                val itemOffset = if (draggedIndex == index) {
                                    with(density) { dragOffsetY.toDp() }
                                } else {
                                    0.dp
                                }
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .offset(y = itemOffset)
                                        .graphicsLayer {
                                            if (draggedIndex == index) {
                                                shadowElevation = 8.dp.toPx()
                                                scaleX = 1.02f
                                                scaleY = 1.02f
                                            }
                                        }
                                ) {
                                    DrawerItemButton(
                                        label = getAppString(key, appLanguage),
                                        icon = getDrawerItemIcon(key),
                                        isDark = isDarkTheme,
                                        onClick = { onDrawerItemClick(key) },
                                        dragModifier = getDragModifier(index)
                                    )
                                }
                            }
                        }
                    }
                }
            ) {
            Box(modifier = Modifier.fillMaxSize()) {
                if (currentSubScreenTafseer) {
                    // Tafseer and Asbab Al-Nuzul screen
                    TafseerSubScreen(
                        chapter = selectedChapter,
                        verses = verses,
                        tafsirs = tafsirs,
                        isDark = isDarkTheme,
                        onBack = { 
                            initialTafseerVerseNumber = null
                            currentSubScreenTafseer = false 
                        },
                        allChapters = chapters,
                        onChapterSelected = { ch ->
                            viewModel.selectChapter(ch)
                        },
                        initialVerseNumber = initialTafseerVerseNumber
                    )
                } else {
                    // Main Quran Reader Screen
                    Scaffold(
                        topBar = {
                            AnimatedVisibility(
                                visible = showTopBanner,
                                enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
                                exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut()
                            ) {
                                CenterAlignedTopAppBar(
                                    title = {
                                        // Removed redundant Surah name display to avoid duplication next to teacher mode button
                                    },
                                    navigationIcon = {
                                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                                            Icon(
                                                imageVector = Icons.Default.Menu,
                                                contentDescription = "القائمة الجانبية",
                                                tint = if (isDarkTheme) DarkGoldPrimary else LightGoldPrimary
                                            )
                                        }
                                    },
                                    actions = {
                                        // Teacher Mode Button
                                        Button(
                                            onClick = { viewModel.toggleTeacherMode() },
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = if (isTeacherModeEnabled) Color(0xFF4CAF50) else Color.Transparent
                                            ),
                                            border = androidx.compose.foundation.BorderStroke(
                                                width = 1.dp,
                                                color = if (isTeacherModeEnabled) Color(0xFF4CAF50) else (if (isDarkTheme) DarkGoldPrimary else LightGoldPrimary)
                                            ),
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                            modifier = Modifier.height(32.dp).padding(end = 4.dp)
                                        ) {
                                            Text(
                                                text = getAppString("teacher_mode", appLanguage),
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (isTeacherModeEnabled) Color.White else (if (isDarkTheme) DarkGoldPrimary else LightGoldPrimary)
                                            )
                                        }

                                        if (isTeacherModeEnabled) {
                                            // Audio Player Button (Tap: Toggle, Long-press: Open Bottom Panel)
                                            Box(
                                                modifier = Modifier
                                                    .size(40.dp)
                                                    .clip(CircleShape)
                                                    .pointerInput(selectedChapter) {
                                                        detectTapGestures(
                                                             onTap = {
                                                                 if (isPlaying) {
                                                                     viewModel.pauseAudio()
                                                                 } else {
                                                                     selectedChapter?.let { ch ->
                                                                         viewModel.playFullSurah(ch.id, selectedReciterIndex)
                                                                     }
                                                                 }
                                                             },
                                                             onLongPress = {
                                                                 showAudioBottomBar = !showAudioBottomBar
                                                             }
                                                         )
                                                    },
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(
                                                    imageVector = if (isPlaying) Icons.Default.PauseCircleFilled else Icons.Default.PlayCircle,
                                                    contentDescription = "تلاوة",
                                                    tint = if (isDarkTheme) DarkGoldPrimary else LightGoldPrimary,
                                                    modifier = Modifier.size(24.dp)
                                                )
                                            }
                                        }

                                        // Bookmarks / Reading Marks Button
                                        // Tafseer Shortcut Button
                                        IconButton(
                                            onClick = {
                                                val offset = 1 + if (selectedChapter?.bismillahPre == true && selectedChapter?.id != 9) 1 else 0
                                                val idx = lazyListState.firstVisibleItemIndex - offset
                                                val currentVerse = verses.getOrNull(if (idx in verses.indices) idx else 0)
                                                val currentVerseNumber = currentVerse?.verseNumber ?: 1
                                                
                                                initialTafseerVerseNumber = currentVerseNumber
                                                currentSubScreenTafseer = true
                                            }
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.MenuBook,
                                                contentDescription = "التفسير الميسر",
                                                tint = if (isDarkTheme) DarkGoldPrimary else LightGoldPrimary
                                            )
                                        }

                                        IconButton(onClick = { showBookmarksDialog = true }) {
                                            Icon(Icons.Default.Bookmark, contentDescription = "علامات القراءة", tint = if (isDarkTheme) DarkGoldPrimary else LightGoldPrimary)
                                        }

                                        // Translation Button
                                        IconButton(onClick = { showTranslationDialog = true }) {
                                            Icon(Icons.Default.Translate, contentDescription = "الترجمات", tint = if (isDarkTheme) DarkGoldPrimary else LightGoldPrimary)
                                        }

                                        // Search Button
                                        IconButton(onClick = { showSearchDialog = true }) {
                                            Icon(Icons.Default.Search, contentDescription = "بحث", tint = if (isDarkTheme) DarkGoldPrimary else LightGoldPrimary)
                                        }
                                    },
                                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                                        containerColor = if (isDarkTheme) DarkGoldSurface else LightGoldSurface
                                    )
                                )
                            }
                        },
                        bottomBar = {
                            AnimatedVisibility(
                                visible = showAudioBottomBar,
                                enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                                exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
                            ) {
                                AudioPlayerPanel(
                                    viewModel = viewModel,
                                    selectedChapter = selectedChapter,
                                    isDark = isDarkTheme,
                                    onChooseReciter = { /* handles inside popup */ }
                                )
                            }
                        }
                    ) { innerPadding ->
                        var previousIndex by remember { mutableStateOf(0) }
                        var previousOffset by remember { mutableStateOf(0) }

                        LaunchedEffect(lazyListState.firstVisibleItemIndex, lazyListState.firstVisibleItemScrollOffset) {
                            val currentIndex = lazyListState.firstVisibleItemIndex
                            val currentOffset = lazyListState.firstVisibleItemScrollOffset
                            
                            if (currentIndex > previousIndex || (currentIndex == previousIndex && currentOffset > previousOffset + 5)) {
                                // Scroll down -> hide top banner
                                showTopBanner = false
                            } else if (currentIndex < previousIndex || (currentIndex == previousIndex && currentOffset < previousOffset - 5)) {
                                // Scroll up -> show top banner
                                showTopBanner = true
                            }
                            
                            if (currentIndex != previousIndex) {
                                val currentChId = selectedChapter?.id
                                if (currentChId != null) {
                                    viewModel.saveLastReadPosition(currentChId, currentIndex)
                                }
                            }
                            
                            previousIndex = currentIndex
                            previousOffset = currentOffset
                        }

                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(computedBgColor)
                                .padding(innerPadding)
                        ) {
                            Column(
                                modifier = Modifier.fillMaxSize()
                            ) {
                                // Swipe Pager for Page transitions
                            HorizontalPager(
                                state = pagerState,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .weight(1f)
                                    .pointerInput(Unit) {
                                        detectTapGestures(
                                            onTap = {
                                                // Single tap hides the top banner!
                                                showTopBanner = false
                                            }
                                        )
                                    }
                            ) { page ->
                                val pageChapter = chapters.getOrNull(page)
                                if (pageChapter?.id == selectedChapter?.id) {
                                    LazyColumn(
                                        state = lazyListState,
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .padding(horizontal = 0.dp, vertical = 8.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.spacedBy(16.dp)
                                    ) {
                                        item {
                                            SurahTitleCard(chapter = selectedChapter, isDark = isDarkTheme)
                                        }

                                        // Show Bismillah pre if applicable
                                        selectedChapter?.let { ch ->
                                            if (ch.bismillahPre && ch.id != 9) {
                                                item {
                                                    Text(
                                                        text = "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ",
                                                        fontSize = (textSizeVal + 4).sp,
                                                        fontWeight = FontWeight.Bold,
                                                        textAlign = TextAlign.Center,
                                                        color = computedTextColor,
                                                        modifier = Modifier.padding(vertical = 16.dp)
                                                    )
                                                }
                                            }
                                        }

                                        items(verses) { verse ->
                                            val translationText = translations.find { it.verseKey == verse.verseKey }?.translationText
                                            val isHighlighted = highlightedVerseKey == verse.verseKey

                                            VerseCardItem(
                                                verse = verse,
                                                translationText = translationText,
                                                textSize = textSizeVal,
                                                isDark = isDarkTheme,
                                                isHighlighted = isHighlighted,
                                                textColor = computedTextColor,
                                                onVerseClick = {
                                                    if (isTeacherModeEnabled) {
                                                        viewModel.playVerseAudio(verse.verseKey, verse.verseNumber, verse.chapterId)
                                                    } else {
                                                        viewModel.highlightedVerseKey.value = if (highlightedVerseKey == verse.verseKey) null else verse.verseKey
                                                    }
                                                },
                                                onWordClick = { word ->
                                                    viewModel.selectWord(verse.verseKey, word)
                                                },
                                                onLongPressVerse = {
                                                    activeBookmarkTarget = Pair(verse.chapterId, verse.verseNumber)
                                                },
                                                viewModel = viewModel
                                            )
                                        }

                                        // Dynamic Page and Juz Number Footer
                                        item {
                                            selectedChapter?.let { ch ->
                                                Column(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .padding(top = 16.dp, bottom = 8.dp),
                                                    horizontalAlignment = Alignment.CenterHorizontally
                                                ) {
                                                    HorizontalDivider(
                                                        color = (if (isDarkTheme) DarkGoldPrimary else LightGoldPrimary).copy(alpha = 0.2f),
                                                        modifier = Modifier.width(120.dp)
                                                    )
                                                    Spacer(modifier = Modifier.height(8.dp))
                                                    Row(
                                                        horizontalArrangement = Arrangement.Center,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Text(
                                                            text = "الصفحة: ${getSurahStartPage(ch.id)}",
                                                            fontSize = 13.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = if (isDarkTheme) DarkGoldPrimary else LightGoldPrimary
                                                        )
                                                        Spacer(modifier = Modifier.width(16.dp))
                                                        Text(
                                                            text = "•",
                                                            fontSize = 13.sp,
                                                            color = (if (isDarkTheme) DarkGoldPrimary else LightGoldPrimary).copy(alpha = 0.5f)
                                                        )
                                                        Spacer(modifier = Modifier.width(16.dp))
                                                        Text(
                                                            text = "الجزء: ${getSurahStartJuz(ch.id)}",
                                                            fontSize = 13.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = if (isDarkTheme) DarkGoldPrimary else LightGoldPrimary
                                                        )
                                                    }
                                                }
                                            }
                                        }

                                        // Auto-navigate to next Surah at the end of current Surah
                                        item {
                                            val nextIndex = chapters.indexOfFirst { it.id == selectedChapter?.id } + 1
                                            if (nextIndex < chapters.size) {
                                                Box(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .padding(vertical = 24.dp, horizontal = 16.dp),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Card(
                                                        colors = CardDefaults.cardColors(
                                                            containerColor = if (isDarkTheme) Color(0xFF1B4D3E).copy(alpha = 0.2f) else Color(0xFFE2EFE4).copy(alpha = 0.5f)
                                                        ),
                                                        shape = RoundedCornerShape(16.dp),
                                                        border = androidx.compose.foundation.BorderStroke(1.dp, (if (isDarkTheme) DarkGoldPrimary else LightGoldPrimary).copy(alpha = 0.3f)),
                                                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
                                                    ) {
                                                        Row(
                                                            modifier = Modifier.padding(16.dp).fillMaxWidth(),
                                                            horizontalArrangement = Arrangement.Center,
                                                            verticalAlignment = Alignment.CenterVertically
                                                        ) {
                                                            CircularProgressIndicator(
                                                                color = if (isDarkTheme) DarkGoldPrimary else LightGoldPrimary,
                                                                modifier = Modifier.size(20.dp),
                                                                strokeWidth = 2.dp
                                                            )
                                                            Spacer(modifier = Modifier.width(12.dp))
                                                            Text(
                                                                text = if (appLanguage == "ar") "الانتقال للسورة التالية تلقائياً..." else "Transitioning to next Surah automatically...",
                                                                color = if (isDarkTheme) DarkGoldPrimary else Color(0xFF1B4D22),
                                                                fontWeight = FontWeight.Bold,
                                                                fontSize = 14.sp
                                                            )
                                                        }
                                                    }
                                                }
                                                LaunchedEffect(Unit) {
                                                    // Automatically transition to next Surah after 300ms when this item enters viewport
                                                    kotlinx.coroutines.delay(300)
                                                    val currentIdx = chapters.indexOfFirst { it.id == selectedChapter?.id }
                                                    if (currentIdx >= 0 && currentIdx < chapters.size - 1) {
                                                        val nextChapter = chapters[currentIdx + 1]
                                                        viewModel.selectChapter(nextChapter)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .padding(16.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Card(
                                            colors = CardDefaults.cardColors(
                                                containerColor = if (isDarkTheme) DarkGoldSurface else LightGoldSurface
                                            ),
                                            shape = RoundedCornerShape(16.dp),
                                            border = androidx.compose.foundation.BorderStroke(
                                                1.dp,
                                                (if (isDarkTheme) DarkGoldPrimary else LightGoldPrimary).copy(alpha = 0.2f)
                                            ),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(16.dp)
                                        ) {
                                            Column(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(24.dp),
                                                horizontalAlignment = Alignment.CenterHorizontally,
                                                verticalArrangement = Arrangement.Center
                                            ) {
                                                Text(
                                                    text = pageChapter?.nameArabic ?: "",
                                                    fontSize = 24.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (isDarkTheme) DarkGoldPrimary else LightGoldPrimary
                                                )
                                                Spacer(modifier = Modifier.height(8.dp))
                                                Text(
                                                    text = "سورة رقم ${pageChapter?.id ?: 0} • عدد آياتها ${pageChapter?.versesCount ?: 0}",
                                                    fontSize = 14.sp,
                                                    color = if (isDarkTheme) DarkGoldText else LightGoldText
                                                )
                                                Spacer(modifier = Modifier.height(16.dp))
                                                CircularProgressIndicator(
                                                    color = if (isDarkTheme) DarkGoldPrimary else LightGoldPrimary,
                                                    modifier = Modifier.size(24.dp),
                                                    strokeWidth = 2.dp
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                }
                            }

                            // Temporary floating Surah name overlay
                            AnimatedVisibility(
                                visible = !showTopBanner && selectedChapter != null,
                                enter = fadeIn(animationSpec = tween(400)) + slideInVertically(
                                    initialOffsetY = { -it },
                                    animationSpec = tween(400)
                                ),
                                exit = fadeOut(animationSpec = tween(400)) + slideOutVertically(
                                    targetOffsetY = { -it },
                                    animationSpec = tween(400)
                                ),
                                modifier = Modifier
                                    .align(Alignment.TopCenter)
                                    .padding(top = 16.dp)
                            ) {
                                selectedChapter?.nameArabic?.let { name ->
                                    Surface(
                                        shape = RoundedCornerShape(20.dp),
                                        color = if (isDarkTheme) Color.Black.copy(alpha = 0.7f) else Color.White.copy(alpha = 0.85f),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, (if (isDarkTheme) DarkGoldPrimary else LightGoldPrimary).copy(alpha = 0.5f)),
                                        tonalElevation = 4.dp,
                                        modifier = Modifier.padding(horizontal = 24.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 24.dp, vertical = 10.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.MenuBook,
                                                contentDescription = null,
                                                tint = if (isDarkTheme) DarkGoldPrimary else LightGoldPrimary,
                                                modifier = Modifier.size(20.dp)
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = "سورة $name",
                                                fontSize = 16.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (isDarkTheme) DarkGoldPrimary else LightGoldPrimary
                                            )
                                        }
                                    }
                                }
                            }
                        }

                // Custom App-level Brightness Dimmer Layer
                if (brightnessVal > 0f) {
                    Canvas(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = brightnessVal))
                    ) {}
                }

                // Word Meaning Dialog Popup instead of bottom sheet
                if (activeWordMeaning != null && highlightedWordText != null) {
                    WordMeaningDialog(
                        wordText = highlightedWordText ?: "",
                        meaning = activeWordMeaning ?: "",
                        isDark = isDarkTheme,
                        onClose = { viewModel.clearWordSelection() }
                    )
                }

                // Dialogs List
                if (showSurahIndexDialog) {
                    SurahIndexDialog(
                        chapters = chapters,
                        isDark = isDarkTheme,
                        onChapterSelected = { ch ->
                            viewModel.selectChapter(ch)
                            showSurahIndexDialog = false
                        },
                        onClose = { showSurahIndexDialog = false }
                    )
                }

                if (showJuzIndexDialog) {
                    JuzIndexDialog(
                        chapters = chapters,
                        isDark = isDarkTheme,
                        onChapterSelected = { ch ->
                            viewModel.selectChapter(ch)
                            showJuzIndexDialog = false
                        },
                        onClose = { showJuzIndexDialog = false }
                    )
                }

                if (showTranslationDialog) {
                    TranslationSelectionDialog(
                        viewModel = viewModel,
                        currentId = activeTranslationId,
                        options = availableTranslations,
                        isDark = isDarkTheme,
                        onSelect = { id -> viewModel.setTranslationLanguage(id) },
                        onClose = { showTranslationDialog = false }
                    )
                }

                if (showSettingsDialog) {
                    SettingsControlDialog(
                        viewModel = viewModel,
                        textSize = textSizeVal,
                        brightness = brightnessVal,
                        isDark = isDarkTheme,
                        teacherReciterFolder = teacherReciterFolder,
                        onClose = { showSettingsDialog = false }
                    )
                }

                if (showSearchDialog) {
                    SearchVerseDialog(
                        query = searchQuery,
                        results = searchResults,
                        isDark = isDarkTheme,
                        onQueryChange = { viewModel.search(it) },
                        onSelectVerse = { verse ->
                            val ch = chapters.find { it.id == verse.chapterId }
                            if (ch != null) {
                                viewModel.selectChapter(ch)
                                // Scroll to or highlight is managed via state
                                viewModel.highlightedVerseKey.value = verse.verseKey
                            }
                            showSearchDialog = false
                        },
                        onClose = { showSearchDialog = false }
                    )
                }

                if (showBookmarksDialog) {
                    val currentVerseOnScreen = remember(lazyListState.firstVisibleItemIndex, verses, selectedChapter) {
                        val bismillahOffset = if (selectedChapter?.bismillahPre == true && selectedChapter?.id != 9) 1 else 0
                        val headerOffset = 1 + bismillahOffset // SurahTitleCard (1) + Bismillah (0 or 1)
                        val index = lazyListState.firstVisibleItemIndex - headerOffset
                        verses.getOrNull(index.coerceIn(0, verses.lastIndex)) ?: verses.firstOrNull()
                    }

                    BookmarksDialog(
                        bookmarks = bookmarks,
                        isDark = isDarkTheme,
                        currentChapterId = selectedChapter?.id,
                        currentVerseNumber = currentVerseOnScreen?.verseNumber,
                        onAddBookmark = { chId, vNum ->
                            viewModel.addBookmark(
                                chapterId = chId,
                                verseNumber = vNum,
                                pageNumber = (vNum / 10) + 1,
                                title = "سورة ${viewModel.getChapterName(chId)} - آية $vNum",
                                type = "reading"
                            )
                        },
                        onSelectBookmark = { bmk ->
                            val ch = chapters.find { it.id == bmk.chapterId }
                            if (ch != null) {
                                viewModel.selectChapter(ch)
                                viewModel.highlightedVerseKey.value = "${bmk.chapterId}:${bmk.verseNumber}"
                            }
                            showBookmarksDialog = false
                        },
                        onDeleteBookmark = { bmk ->
                            viewModel.toggleBookmark(bmk.chapterId, bmk.verseNumber)
                        },
                        onClose = { showBookmarksDialog = false }
                    )
                }

                if (showDuaaDialog) {
                    DuaaKhatmDialog(
                        isDark = isDarkTheme,
                        onClose = { showDuaaDialog = false }
                    )
                }

                // Add Bookmark Dialog Prompt
                activeBookmarkTarget?.let { target ->
                    AddBookmarkDialog(
                        chapterId = target.first,
                        verseNumber = target.second,
                        isDark = isDarkTheme,
                        onConfirm = { type ->
                            viewModel.addBookmark(
                                chapterId = target.first,
                                verseNumber = target.second,
                                pageNumber = (target.second / 10) + 1,
                                title = "سورة ${viewModel.getChapterName(target.first)} - آية ${target.second}",
                                type = type
                            )
                            activeBookmarkTarget = null
                        },
                        onDismiss = { activeBookmarkTarget = null }
                    )
                }

                // 1. Language Selection Dialog
                if (showLanguageDialog) {
                    Dialog(onDismissRequest = { showLanguageDialog = false }) {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = if (isDarkTheme) DarkGoldSurface else LightGoldSurface,
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (isDarkTheme) DarkGoldPrimary else LightGoldPrimary),
                            modifier = Modifier.fillMaxWidth().padding(16.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = getAppString("app_language", appLanguage),
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isDarkTheme) DarkGoldPrimary else LightGoldPrimary,
                                    modifier = Modifier.padding(bottom = 12.dp)
                                )
                                val langs = listOf(
                                    "ar" to "العربية",
                                    "en" to "English",
                                    "fr" to "Français",
                                    "es" to "Español",
                                    "tr" to "Türkçe",
                                    "ur" to "اردو",
                                    "id" to "Bahasa Indonesia",
                                    "fa" to "فارسی",
                                    "ru" to "Русский",
                                    "de" to "Deutsch",
                                    "it" to "Italiano"
                                )
                                LazyColumn(modifier = Modifier.heightIn(max = 300.dp)) {
                                    items(langs) { (code, name) ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable {
                                                    viewModel.setAppLanguage(code)
                                                    showLanguageDialog = false
                                                }
                                                .padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            RadioButton(
                                                selected = appLanguage == code,
                                                onClick = {
                                                    viewModel.setAppLanguage(code)
                                                    showLanguageDialog = false
                                                },
                                                colors = RadioButtonDefaults.colors(
                                                    selectedColor = if (isDarkTheme) DarkGoldPrimary else LightGoldPrimary
                                                )
                                            )
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Text(
                                                text = name,
                                                fontSize = 15.sp,
                                                color = if (isDarkTheme) DarkGoldText else LightGoldText
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // 2. Vocabulary Meanings Explorer Dialog
                if (showVocabularyDialog) {
                    VocabularyExplorerDialog(
                        viewModel = viewModel,
                        chapters = chapters,
                        isDark = isDarkTheme,
                        onClose = { showVocabularyDialog = false }
                    )
                }

                // 3. About Dialog
                if (showAboutDialog) {
                    Dialog(onDismissRequest = { showAboutDialog = false }) {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = if (isDarkTheme) DarkGoldSurface else LightGoldSurface,
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (isDarkTheme) DarkGoldPrimary else LightGoldPrimary),
                            modifier = Modifier.fillMaxWidth().padding(16.dp)
                        ) {
                            Column(modifier = Modifier.padding(20.dp)) {
                                Text(
                                    text = getAppString("about", appLanguage),
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isDarkTheme) DarkGoldPrimary else LightGoldPrimary,
                                    modifier = Modifier.padding(bottom = 12.dp)
                                )
                                val aboutText = "تم إنشاء التطبيق كصدقة جارية عن أبي وأمي وعائلتي، لا تنسونا بصالح دعائكم.\n\n" +
                                        "تطبيق القرآن الكريم الذهبي v1.2.0\n\n" +
                                        "تطبيق إسلامي شامل ومتميز لقراءة وتلاوة القرآن الكريم وتدبر معانيه وحفظه.\n\n" +
                                        "أبرز مميزات التطبيق وكيفية استخدامها:\n\n" +
                                        "١. القراءة والتلاوة التفاعلية:\n" +
                                        "يمكنك قراءة القرآن بالرسم العثماني الفاخر. للتلاوة، اضغط على أيقونة التلاوة (سماعة الرأس) بالأعلى للاستماع للسورة كاملة بصوت القارئ المفضل.\n\n" +
                                        "٢. وضع القارئ المعلم (التكرار للحفظ):\n" +
                                        "فعّل خيار \"وضع المعلم\" من شاشة القراءة، وعندها يمكنك الضغط على أي آية ليتم تكرار تلاوتها فوراً لتسهيل الحفظ والتلقين الصحيح.\n\n" +
                                        "٣. التفسير ومعاني الكلمات التفاعلية:\n" +
                                        "اضغط ضغطة مطولة على أي آية لعرض التفسير الميسر، معاني المفردات لكل كلمة على حدة، وأسباب النزول المناسبة.\n\n" +
                                        "٤. التمييز الذكي لأسماء الله الحسنى:\n" +
                                        "يقوم التطبيق تلقائياً وبتحليل دقيق بتمييز أسماء الله الحسنى وتلوينها باللون الأخضر في الوضع الداكن وباللون الأحمر في الوضع الفاتح لسهولة التدبر.\n\n" +
                                        "٥. قسم الأذكار والحديث الشريف:\n" +
                                        "استمتع بقراءة الأذكار اليومية (الصباح والمساء) واستخدم المسبحة الإلكترونية التفاعلية، بالإضافة إلى تصفح الأحاديث النبوية الشريفة من الشاشة الرئيسية.\n\n" +
                                        "٦. إذاعة القرآن الكريم المباشرة:\n" +
                                        "يمكنك الاستماع المباشر لمحطات إذاعة القرآن الكريم المختلفة من شاشة التطبيق الرئيسية في أي وقت.\n\n" +
                                        "٧. البحث والفهرسة الذكية:\n" +
                                        "استخدم محرك البحث المتقدم للوصول السريع للآيات، أو تصفح الفهرس الشامل للسور والأجزاء والأحزاب للانتقال الفوري لما تريد.\n\n" +
                                        "٨. الإشارات المرجعية وحفظ التقدم:\n" +
                                        "لحفظ موضع قراءتك، اضغط على علامة الحفظ المرجعية للعودة إليها لاحقاً بكل سهولة ويسر."
                                Text(
                                    text = aboutText,
                                    fontSize = 13.sp,
                                    color = if (isDarkTheme) DarkGoldText else LightGoldText,
                                    lineHeight = 20.sp,
                                    modifier = Modifier
                                        .weight(1f, fill = false)
                                        .verticalScroll(rememberScrollState())
                                )
                                Spacer(modifier = Modifier.height(16.dp))
                                Button(
                                    onClick = { showAboutDialog = false },
                                    colors = ButtonDefaults.buttonColors(containerColor = if (isDarkTheme) DarkGoldPrimary else LightGoldPrimary),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("موافق", color = Color.White)
                                }
                            }
                        }
                    }
                }

                // 4. Update Dialog
                if (showUpdateDialog) {
                    var isChecking by remember { mutableStateOf(true) }
                    LaunchedEffect(Unit) {
                        kotlinx.coroutines.delay(1200)
                        isChecking = false
                    }
                    Dialog(onDismissRequest = { showUpdateDialog = false }) {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = if (isDarkTheme) DarkGoldSurface else LightGoldSurface,
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (isDarkTheme) DarkGoldPrimary else LightGoldPrimary),
                            modifier = Modifier.fillMaxWidth().padding(16.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                if (isChecking) {
                                    CircularProgressIndicator(color = if (isDarkTheme) DarkGoldPrimary else LightGoldPrimary)
                                    Spacer(modifier = Modifier.height(16.dp))
                                    Text("جاري فحص التحديثات المتاحة...", color = if (isDarkTheme) DarkGoldText else LightGoldText, fontSize = 14.sp)
                                } else {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF4CAF50), modifier = Modifier.size(48.dp))
                                    Spacer(modifier = Modifier.height(16.dp))
                                    Text("تحديث التطبيق", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = if (isDarkTheme) DarkGoldPrimary else LightGoldPrimary)
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text("التطبيق محدث بالكامل لأحدث إصدار (v1.2.0)", color = if (isDarkTheme) DarkGoldText else LightGoldText, fontSize = 13.sp, textAlign = TextAlign.Center)
                                    Spacer(modifier = Modifier.height(16.dp))
                                    Button(
                                        onClick = { showUpdateDialog = false },
                                        colors = ButtonDefaults.buttonColors(containerColor = if (isDarkTheme) DarkGoldPrimary else LightGoldPrimary),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text("موافق", color = Color.White)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
}
}

// Drawer item button layout
@Composable
fun DrawerItemButton(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isDark: Boolean,
    onClick: () -> Unit,
    dragModifier: Modifier = Modifier
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        shape = RoundedCornerShape(12.dp),
        color = Color.Transparent
    ) {
        Row(
            modifier = Modifier
                .clickable(onClick = onClick)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Drag handle to reorder
            Icon(
                imageVector = Icons.Default.DragHandle,
                contentDescription = "ترتيب",
                tint = (if (isDark) DarkGoldPrimary else LightGoldPrimary).copy(alpha = 0.5f),
                modifier = dragModifier
                    .size(24.dp)
                    .padding(end = 4.dp)
            )
            
            Spacer(modifier = Modifier.width(8.dp))

            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (isDark) DarkGoldPrimary else LightGoldPrimary,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(16.dp))
            Text(
                text = label,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                color = if (isDark) DarkGoldText else LightGoldText,
                modifier = Modifier.weight(1f)
            )
        }
    }
}
