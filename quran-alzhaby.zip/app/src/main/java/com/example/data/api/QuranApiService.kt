package com.example.data.api

import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

interface QuranApiService {

    @GET("chapters")
    suspend fun getChapters(
        @Query("language") language: String = "ar"
    ): ChaptersResponse

    @GET("quran/verses/uthmani")
    suspend fun getVersesUthmani(
        @Query("chapter_number") chapterNumber: Int
    ): VersesUthmaniResponse

    @GET("verses/by_chapter/{chapter_number}")
    suspend fun getVersesWithWords(
        @Path("chapter_number") chapterNumber: Int,
        @Query("words") words: Boolean = true,
        @Query("word_fields") wordFields: String = "text_uthmani",
        @Query("language") language: String = "ar",
        @Query("word_translation_language") wordTranslationLanguage: String = "ar"
    ): VersesWordsResponse

    @GET("quran/tafsirs/{tafsir_id}")
    suspend fun getTafsir(
        @Path("tafsir_id") tafsirId: Int,
        @Query("chapter_number") chapterNumber: Int
    ): TafsirsResponse

    @GET("quran/translations/{translation_id}")
    suspend fun getTranslation(
        @Path("translation_id") translationId: Int,
        @Query("chapter_number") chapterNumber: Int
    ): TranslationsResponse

    @GET("resources/translations")
    suspend fun getTranslationResources(): TranslationResourceResponse

    companion object {
        private const val BASE_URL = "https://api.quran.com/api/v4/"

        fun create(): QuranApiService {
            val moshi = Moshi.Builder()
                .addLast(KotlinJsonAdapterFactory())
                .build()

            return Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(MoshiConverterFactory.create(moshi))
                .build()
                .create(QuranApiService::class.java)
        }
    }
}
