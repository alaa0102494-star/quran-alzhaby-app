package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "chapters")
data class ChapterEntity(
    @PrimaryKey val id: Int,
    val nameArabic: String,
    val nameComplex: String,
    val translatedName: String,
    val versesCount: Int,
    val revelationPlace: String,
    val bismillahPre: Boolean
)

@Entity(tableName = "verses", indices = [androidx.room.Index(value = ["chapterId"])])
data class VerseEntity(
    @PrimaryKey val verseKey: String, // e.g., "1:1"
    val chapterId: Int,
    val verseNumber: Int,
    val textUthmani: String,
    val wordMeaningsJson: String // JSON string containing List of WordMeaning objects
)

@Entity(tableName = "translations", indices = [androidx.room.Index(value = ["translationId", "verseKey"])])
data class TranslationEntity(
    @PrimaryKey val id: String, // e.g., "1:1_131"
    val verseKey: String,
    val translationId: Int,
    val languageName: String,
    val translationText: String
)

@Entity(tableName = "tafsirs", indices = [androidx.room.Index(value = ["tafsirId", "verseKey"])])
data class TafsirEntity(
    @PrimaryKey val id: String, // e.g., "1:1_16"
    val verseKey: String,
    val tafsirId: Int,
    val tafsirText: String,
    val asbabAlNuzul: String
)

@Entity(tableName = "bookmarks")
data class BookmarkEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val chapterId: Int,
    val verseNumber: Int,
    val pageNumber: Int,
    val title: String,
    val type: String, // "reading" or "memorization"
    val timestamp: Long = System.currentTimeMillis()
)

data class WordMeaning(
    val position: Int,
    val textUthmani: String,
    val meaning: String
)
