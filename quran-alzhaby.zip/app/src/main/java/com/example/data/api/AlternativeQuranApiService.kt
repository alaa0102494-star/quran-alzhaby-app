package com.example.data.api

import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import com.squareup.moshi.Moshi
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

// --- Al Quran Cloud API Models & Service ---

@JsonClass(generateAdapter = true)
data class AlQuranCloudSurahResponse(
    @Json(name = "code") val code: Int,
    @Json(name = "status") val status: String,
    @Json(name = "data") val data: AlQuranCloudSurahData
)

@JsonClass(generateAdapter = true)
data class AlQuranCloudSurahData(
    @Json(name = "number") val number: Int,
    @Json(name = "ayahs") val ayahs: List<AlQuranCloudAyah>
)

@JsonClass(generateAdapter = true)
data class AlQuranCloudAyah(
    @Json(name = "number") val number: Int,
    @Json(name = "text") val text: String,
    @Json(name = "numberInSurah") val numberInSurah: Int
)

interface AlQuranCloudApiService {
    @GET("surah/{surah_number}")
    suspend fun getSurahUthmani(
        @Path("surah_number") surahNumber: Int
    ): AlQuranCloudSurahResponse

    @GET("surah/{surah_number}/ar.muyassar")
    suspend fun getSurahTafsirMuyassar(
        @Path("surah_number") surahNumber: Int
    ): AlQuranCloudSurahResponse

    @GET("surah/{surah_number}/en.sahih")
    suspend fun getSurahEnglishTranslation(
        @Path("surah_number") surahNumber: Int
    ): AlQuranCloudSurahResponse

    companion object {
        private const val BASE_URL = "https://api.alquran.cloud/v1/"

        fun create(): AlQuranCloudApiService {
            val moshi = Moshi.Builder()
                .addLast(KotlinJsonAdapterFactory())
                .build()

            return Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(MoshiConverterFactory.create(moshi))
                .build()
                .create(AlQuranCloudApiService::class.java)
        }
    }
}

// --- Al-Quran API (Fawaz Ahmed) Models & Service ---

@JsonClass(generateAdapter = true)
data class FawazQuranSurahResponse(
    @Json(name = "chapter") val chapter: List<FawazQuranVerse>
)

@JsonClass(generateAdapter = true)
data class FawazQuranVerse(
    @Json(name = "chapter") val chapter: Int,
    @Json(name = "verse") val verse: Int,
    @Json(name = "text") val text: String
)

interface FawazQuranApiService {
    @GET("editions/ara-jalaladdinalmah/{surah_number}.json")
    suspend fun getTafsirJalalayn(
        @Path("surah_number") surahNumber: Int
    ): FawazQuranSurahResponse

    @GET("editions/eng-translation/{surah_number}.json")
    suspend fun getEnglishTranslation(
        @Path("surah_number") surahNumber: Int
    ): FawazQuranSurahResponse

    companion object {
        private const val BASE_URL = "https://cdn.jsdelivr.net/gh/fawazahmed0/quran-api@1/"

        fun create(): FawazQuranApiService {
            val moshi = Moshi.Builder()
                .addLast(KotlinJsonAdapterFactory())
                .build()

            return Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(MoshiConverterFactory.create(moshi))
                .build()
                .create(FawazQuranApiService::class.java)
        }
    }
}

// --- Spa5k Tafsir API Models & Service ---

@JsonClass(generateAdapter = true)
data class Spa5kTafsirResponse(
    @Json(name = "tafsir_id") val tafsirId: Int?,
    @Json(name = "surah") val surah: Int?,
    @Json(name = "verses") val verses: List<Spa5kVerseTafsir>?
)

@JsonClass(generateAdapter = true)
data class Spa5kVerseTafsir(
    @Json(name = "verse") val verse: Int,
    @Json(name = "text") val text: String
)

interface Spa5kTafsirApiService {
    // Standard endpoint to get a specific Tafsir by Tafsir ID and Surah number
    // ID 1 is typically Tafsir Ibn Kathir, ID 2 is Tafsir Al-Saddi, or custom
    @GET("tafsir/{tafsir_id}/{surah_number}")
    suspend fun getTafsir(
        @Path("tafsir_id") tafsirId: Int,
        @Path("surah_number") surahNumber: Int
    ): Spa5kTafsirResponse

    companion object {
        // Fallback domains are supported in the repository if this is unreachable
        private const val BASE_URL = "https://tafsir.api.spa5k.com/v1/"

        fun create(): Spa5kTafsirApiService {
            val moshi = Moshi.Builder()
                .addLast(KotlinJsonAdapterFactory())
                .build()

            return Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(MoshiConverterFactory.create(moshi))
                .build()
                .create(Spa5kTafsirApiService::class.java)
        }
    }
}
