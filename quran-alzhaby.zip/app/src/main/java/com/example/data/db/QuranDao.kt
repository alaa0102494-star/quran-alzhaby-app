package com.example.data.db

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface QuranDao {

    // Chapters
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChapters(chapters: List<ChapterEntity>)

    @Query("SELECT * FROM chapters ORDER BY id ASC")
    fun getAllChapters(): Flow<List<ChapterEntity>>

    @Query("SELECT * FROM chapters WHERE id = :chapterId")
    suspend fun getChapterById(chapterId: Int): ChapterEntity?

    // Verses
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVerses(verses: List<VerseEntity>)

    @Query("SELECT * FROM verses WHERE chapterId = :chapterId ORDER BY verseNumber ASC")
    fun getVersesByChapter(chapterId: Int): Flow<List<VerseEntity>>

    @Query("SELECT * FROM verses WHERE verseKey = :verseKey")
    suspend fun getVerseByKey(verseKey: String): VerseEntity?

    @Query("SELECT * FROM verses WHERE textUthmani LIKE '%' || :query || '%'")
    fun searchVerses(query: String): Flow<List<VerseEntity>>

    // Translations
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTranslations(translations: List<TranslationEntity>)

    @Query("SELECT * FROM translations WHERE verseKey = :verseKey AND translationId = :translationId")
    suspend fun getTranslationForVerse(verseKey: String, translationId: Int): TranslationEntity?

    @Query("SELECT * FROM translations WHERE translationId = :translationId AND verseKey LIKE :chapterId || ':%'")
    fun getTranslationsForChapter(chapterId: Int, translationId: Int): Flow<List<TranslationEntity>>

    // Tafsirs
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTafsirs(tafsirs: List<TafsirEntity>)

    @Query("SELECT * FROM tafsirs WHERE verseKey = :verseKey AND tafsirId = :tafsirId")
    suspend fun getTafsirForVerse(verseKey: String, tafsirId: Int): TafsirEntity?

    @Query("SELECT * FROM tafsirs WHERE tafsirId = :tafsirId AND verseKey LIKE :chapterId || ':%'")
    fun getTafsirsForChapter(chapterId: Int, tafsirId: Int): Flow<List<TafsirEntity>>

    // Bookmarks
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBookmark(bookmark: BookmarkEntity)

    @Delete
    suspend fun deleteBookmark(bookmark: BookmarkEntity)

    @Query("SELECT * FROM bookmarks ORDER BY timestamp DESC")
    fun getAllBookmarks(): Flow<List<BookmarkEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM bookmarks WHERE chapterId = :chapterId AND verseNumber = :verseNumber)")
    fun isBookmarkedFlow(chapterId: Int, verseNumber: Int): Flow<Boolean>

    @Query("SELECT EXISTS(SELECT 1 FROM bookmarks WHERE chapterId = :chapterId AND verseNumber = :verseNumber)")
    suspend fun isBookmarked(chapterId: Int, verseNumber: Int): Boolean

    @Query("DELETE FROM bookmarks WHERE chapterId = :chapterId AND verseNumber = :verseNumber")
    suspend fun deleteBookmarkByCoords(chapterId: Int, verseNumber: Int)
}
