package com.example.data.api

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class ChaptersResponse(
    @Json(name = "chapters") val chapters: List<ApiChapter>
)

@JsonClass(generateAdapter = true)
data class ApiChapter(
    @Json(name = "id") val id: Int,
    @Json(name = "revelation_place") val revelationPlace: String,
    @Json(name = "bismillah_pre") val bismillahPre: Boolean,
    @Json(name = "name_complex") val nameComplex: String,
    @Json(name = "name_arabic") val nameArabic: String,
    @Json(name = "verses_count") val versesCount: Int,
    @Json(name = "translated_name") val translatedName: ApiTranslatedName
)

@JsonClass(generateAdapter = true)
data class ApiTranslatedName(
    @Json(name = "language_name") val languageName: String,
    @Json(name = "name") val name: String
)

@JsonClass(generateAdapter = true)
data class VersesUthmaniResponse(
    @Json(name = "verses") val verses: List<ApiVerseUthmani>
)

@JsonClass(generateAdapter = true)
data class ApiVerseUthmani(
    @Json(name = "id") val id: Int,
    @Json(name = "verse_key") val verseKey: String,
    @Json(name = "text_uthmani") val textUthmani: String
)

@JsonClass(generateAdapter = true)
data class VersesWordsResponse(
    @Json(name = "verses") val verses: List<ApiVerseWords>
)

@JsonClass(generateAdapter = true)
data class ApiVerseWords(
    @Json(name = "id") val id: Int,
    @Json(name = "verse_number") val verseNumber: Int,
    @Json(name = "verse_key") val verseKey: String,
    @Json(name = "words") val words: List<ApiWord>
)

@JsonClass(generateAdapter = true)
data class ApiWord(
    @Json(name = "id") val id: Int,
    @Json(name = "position") val position: Int,
    @Json(name = "text_uthmani") val textUthmani: String?,
    @Json(name = "translation") val translation: ApiWordTranslation?
)

@JsonClass(generateAdapter = true)
data class ApiWordTranslation(
    @Json(name = "text") val text: String,
    @Json(name = "language_name") val languageName: String
)

@JsonClass(generateAdapter = true)
data class TafsirsResponse(
    @Json(name = "tafsirs") val tafsirs: List<ApiTafsir>
)

@JsonClass(generateAdapter = true)
data class ApiTafsir(
    @Json(name = "resource_id") val resourceId: Int?,
    @Json(name = "verse_key") val verseKey: String,
    @Json(name = "text") val text: String
)

@JsonClass(generateAdapter = true)
data class TranslationsResponse(
    @Json(name = "translations") val translations: List<ApiTranslation>
)

@JsonClass(generateAdapter = true)
data class ApiTranslation(
    @Json(name = "resource_id") val resourceId: Int?,
    @Json(name = "verse_key") val verseKey: String?,
    @Json(name = "text") val text: String
)

@JsonClass(generateAdapter = true)
data class TranslationResourceResponse(
    @Json(name = "translations") val translations: List<ApiTranslationResource>
)

@JsonClass(generateAdapter = true)
data class ApiTranslationResource(
    @Json(name = "id") val id: Int,
    @Json(name = "name") val name: String,
    @Json(name = "language_name") val languageName: String,
    @Json(name = "author_name") val authorName: String
)
