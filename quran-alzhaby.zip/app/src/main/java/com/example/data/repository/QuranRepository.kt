package com.example.data.repository

import com.example.data.api.*
import com.example.data.db.*
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flow
import android.util.Log
import java.net.URL

class QuranRepository(
    private val context: android.content.Context,
    private val quranDao: QuranDao,
    private val apiService: QuranApiService
) {
    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val wordMeaningListAdapter = moshi.adapter<List<WordMeaning>>(
        Types.newParameterizedType(List::class.java, WordMeaning::class.java)
    )

    // Chapters
    fun getChapters(): Flow<List<ChapterEntity>> = flow {
        // First check local DB
        val localChapters = quranDao.getAllChapters().first()
        if (localChapters.isNotEmpty()) {
            emit(localChapters)
            return@flow
        }

        try {
            // Fetch from API
            val response = apiService.getChapters("ar")
            val entities = response.chapters.map { apiChapter ->
                ChapterEntity(
                    id = apiChapter.id,
                    nameArabic = apiChapter.nameArabic,
                    nameComplex = apiChapter.nameComplex,
                    translatedName = apiChapter.translatedName.name,
                    versesCount = apiChapter.versesCount,
                    revelationPlace = apiChapter.revelationPlace,
                    bismillahPre = apiChapter.bismillahPre
                )
            }
            if (entities.isNotEmpty()) {
                quranDao.insertChapters(entities)
                emit(entities)
            }
        } catch (e: Exception) {
            Log.e("QuranRepository", "Error fetching chapters from API: ${e.message}, falling back to offline assets")
            if (localChapters.isEmpty()) {
                val offline = getOfflineData()
                val entities = offline.chapters.map { ch ->
                    ChapterEntity(
                        id = ch.id,
                        nameArabic = ch.nameArabic,
                        nameComplex = ch.nameComplex,
                        translatedName = ch.translatedName,
                        versesCount = ch.versesCount,
                        revelationPlace = ch.revelationPlace,
                        bismillahPre = ch.bismillahPre
                    )
                }
                if (entities.isNotEmpty()) {
                    quranDao.insertChapters(entities)
                    emit(entities)
                } else {
                    emit(emptyList())
                }
            }
        }
    }

    // Verses with Merge of Word Meanings
    fun getVersesByChapter(chapterId: Int): Flow<List<VerseEntity>> = flow {
        val localVerses = quranDao.getVersesByChapter(chapterId).first()
        if (localVerses.isNotEmpty()) {
            emit(localVerses)
            return@flow
        }

        try {
            // Fetch Uthmani text
            val uthmaniResponse = apiService.getVersesUthmani(chapterId)
            
            // Fetch word meaning details (Arabic translation of words or default translations)
            val wordsResponse = apiService.getVersesWithWords(
                chapterNumber = chapterId,
                words = true,
                wordFields = "text_uthmani",
                language = "ar" // Get Arabic meanings
            )

            // Create word meanings lookup map
            val wordsMap = wordsResponse.verses.associateBy { it.verseKey }

            val entities = uthmaniResponse.verses.map { apiVerse ->
                val apiVerseWords = wordsMap[apiVerse.verseKey]
                val wordMeanings = apiVerseWords?.words?.map { apiWord ->
                    WordMeaning(
                        position = apiWord.position,
                        textUthmani = apiWord.textUthmani ?: "",
                        meaning = QuranArabicSynonyms.getSynonym(apiWord.textUthmani ?: "")
                    )
                } ?: emptyList()

                val meaningsJson = try {
                    wordMeaningListAdapter.toJson(wordMeanings)
                } catch (e: Exception) {
                    "[]"
                }

                VerseEntity(
                    verseKey = apiVerse.verseKey,
                    chapterId = chapterId,
                    verseNumber = apiVerse.verseKey.split(":").getOrNull(1)?.toIntOrNull() ?: 1,
                    textUthmani = apiVerse.textUthmani,
                    wordMeaningsJson = meaningsJson
                )
            }

            if (entities.isNotEmpty()) {
                quranDao.insertVerses(entities)
                emit(entities)
            }
        } catch (e: Exception) {
            Log.e("QuranRepository", "Error fetching verses for chapter $chapterId: ${e.message}, falling back to offline assets")
            if (localVerses.isEmpty()) {
                val offline = getOfflineData()
                val chapterVerses = offline.verses.filterKeys { key ->
                    val parts = key.split(':')
                    parts.size == 2 && parts[0].toIntOrNull() == chapterId
                }
                
                val entities = chapterVerses.map { (verseKey, offlineVerse) ->
                    val vNum = verseKey.split(":").getOrNull(1)?.toIntOrNull() ?: 1
                    val words = offlineVerse.uthmani.trim().split(Regex("\\s+"))
                    val wordMeanings = words.mapIndexed { index, wordText ->
                        WordMeaning(
                            position = index + 1,
                            textUthmani = wordText,
                            meaning = QuranArabicSynonyms.getSynonym(wordText)
                        )
                    }
                    val meaningsJson = try {
                        wordMeaningListAdapter.toJson(wordMeanings)
                    } catch (ex: Exception) {
                        "[]"
                    }

                    VerseEntity(
                        verseKey = verseKey,
                        chapterId = chapterId,
                        verseNumber = vNum,
                        textUthmani = offlineVerse.uthmani,
                        wordMeaningsJson = meaningsJson
                    )
                }
                
                if (entities.isNotEmpty()) {
                    quranDao.insertVerses(entities)
                    emit(entities)
                } else {
                    emit(emptyList())
                }
            }
        }
    }

    // Translations for Chapter
    fun getTranslationsForChapter(chapterId: Int, translationId: Int): Flow<List<TranslationEntity>> = flow {
        val localTranslations = quranDao.getTranslationsForChapter(chapterId, translationId).first()
        if (localTranslations.isNotEmpty()) {
            emit(localTranslations)
            return@flow
        }

        try {
            val response = apiService.getTranslation(translationId, chapterId)
            val entities = response.translations.mapIndexed { index, apiTranslation ->
                val vKey = apiTranslation.verseKey ?: "$chapterId:${index + 1}"
                TranslationEntity(
                    id = "${vKey}_$translationId",
                    verseKey = vKey,
                    translationId = translationId,
                    languageName = getLanguageNameForId(translationId),
                    translationText = apiTranslation.text
                )
            }
            if (entities.isNotEmpty()) {
                quranDao.insertTranslations(entities)
                emit(entities)
            }
        } catch (e: Exception) {
            Log.e("QuranRepository", "Error fetching translations: ${e.message}, falling back to offline assets")
            if (localTranslations.isEmpty()) {
                val offline = getOfflineData()
                val chapterVerses = offline.verses.filterKeys { key ->
                    val parts = key.split(':')
                    parts.size == 2 && parts[0].toIntOrNull() == chapterId
                }
                
                val entities = chapterVerses.map { (verseKey, offlineVerse) ->
                    TranslationEntity(
                        id = "${verseKey}_$translationId",
                        verseKey = verseKey,
                        translationId = translationId,
                        languageName = "english",
                        translationText = offlineVerse.en
                    )
                }
                
                if (entities.isNotEmpty()) {
                    quranDao.insertTranslations(entities)
                    emit(entities)
                } else {
                    emit(emptyList())
                }
            }
        }
    }

    // Tafsirs and Asbab Al-Nuzul for Chapter
    fun getTafsirsForChapter(chapterId: Int, tafsirId: Int): Flow<List<TafsirEntity>> = flow {
        val localTafsirs = quranDao.getTafsirsForChapter(chapterId, tafsirId).first()
        if (localTafsirs.isNotEmpty()) {
            emit(localTafsirs)
            return@flow
        }

        try {
            val response = apiService.getTafsir(tafsirId, chapterId)
            val entities = response.tafsirs.map { apiTafsir ->
                val verseNum = apiTafsir.verseKey.split(":").getOrNull(1)?.toIntOrNull() ?: 1
                TafsirEntity(
                    id = "${apiTafsir.verseKey}_$tafsirId",
                    verseKey = apiTafsir.verseKey,
                    tafsirId = tafsirId,
                    tafsirText = apiTafsir.text,
                    asbabAlNuzul = getAsbabAlNuzulMock(chapterId, verseNum) // Load high-quality localized descriptions
                )
            }
            if (entities.isNotEmpty()) {
                quranDao.insertTafsirs(entities)
                emit(entities)
            } else {
                // If response was empty (common on api.quran.com for tafsir v4), fallback to AlQuran Cloud
                Log.d("QuranRepository", "Tafsir response empty from primary api, falling back to AlQuran Cloud")
                val apiCloud = com.example.data.api.AlQuranCloudApiService.create()
                val muyassarResponse = apiCloud.getSurahTafsirMuyassar(chapterId)
                val cloudEntities = muyassarResponse.data.ayahs.map { ayah ->
                    val verseKey = "$chapterId:${ayah.numberInSurah}"
                    TafsirEntity(
                        id = "${verseKey}_$tafsirId",
                        verseKey = verseKey,
                        tafsirId = tafsirId,
                        tafsirText = ayah.text,
                        asbabAlNuzul = getAsbabAlNuzulMock(chapterId, ayah.numberInSurah)
                    )
                }
                if (cloudEntities.isNotEmpty()) {
                    quranDao.insertTafsirs(cloudEntities)
                    emit(cloudEntities)
                }
            }
        } catch (e: Exception) {
            Log.e("QuranRepository", "Error fetching tafsirs: ${e.message}, attempting fallback to AlQuran Cloud or offline assets...")
            try {
                val apiCloud = com.example.data.api.AlQuranCloudApiService.create()
                val muyassarResponse = apiCloud.getSurahTafsirMuyassar(chapterId)
                val cloudEntities = muyassarResponse.data.ayahs.map { ayah ->
                    val verseKey = "$chapterId:${ayah.numberInSurah}"
                    TafsirEntity(
                        id = "${verseKey}_$tafsirId",
                        verseKey = verseKey,
                        tafsirId = tafsirId,
                        tafsirText = ayah.text,
                        asbabAlNuzul = getAsbabAlNuzulMock(chapterId, ayah.numberInSurah)
                    )
                }
                if (cloudEntities.isNotEmpty()) {
                    quranDao.insertTafsirs(cloudEntities)
                    emit(cloudEntities)
                }
            } catch (ex: Exception) {
                Log.e("QuranRepository", "Fallback AlQuran Cloud failed as well: ${ex.message}, falling back to offline assets")
                if (localTafsirs.isEmpty()) {
                    val offline = getOfflineData()
                    val chapterVerses = offline.verses.filterKeys { key ->
                        val parts = key.split(':')
                        parts.size == 2 && parts[0].toIntOrNull() == chapterId
                    }
                    
                    val entities = chapterVerses.map { (verseKey, offlineVerse) ->
                        val vNum = verseKey.split(":").getOrNull(1)?.toIntOrNull() ?: 1
                        TafsirEntity(
                            id = "${verseKey}_$tafsirId",
                            verseKey = verseKey,
                            tafsirId = tafsirId,
                            tafsirText = offlineVerse.tafsir,
                            asbabAlNuzul = getAsbabAlNuzulMock(chapterId, vNum)
                        )
                    }
                    
                    if (entities.isNotEmpty()) {
                        quranDao.insertTafsirs(entities)
                        emit(entities)
                    } else {
                        emit(emptyList())
                    }
                }
            }
        }
    }

    // Search Verses
    fun searchVerses(query: String): Flow<List<VerseEntity>> {
        return quranDao.searchVerses(query)
    }

    // Bookmarks
    fun getAllBookmarks(): Flow<List<BookmarkEntity>> = quranDao.getAllBookmarks()

    fun isBookmarkedFlow(chapterId: Int, verseNumber: Int): Flow<Boolean> =
        quranDao.isBookmarkedFlow(chapterId, verseNumber)

    suspend fun addBookmark(chapterId: Int, verseNumber: Int, pageNumber: Int, title: String, type: String) {
        val bookmark = BookmarkEntity(
            chapterId = chapterId,
            verseNumber = verseNumber,
            pageNumber = pageNumber,
            title = title,
            type = type
        )
        quranDao.insertBookmark(bookmark)
    }

    suspend fun removeBookmark(chapterId: Int, verseNumber: Int) {
        quranDao.deleteBookmarkByCoords(chapterId, verseNumber)
    }

    // Fetch available languages
    suspend fun getAvailableTranslations(): List<ApiTranslationResource> {
        return try {
            val response = apiService.getTranslationResources()
            response.translations
        } catch (e: Exception) {
            // Return common translations fallback list if offline
            listOf(
                ApiTranslationResource(131, "English - Clear Quran", "English", "Dr. Mustafa Khattab"),
                ApiTranslationResource(139, "Spanish - Muhammad Isa García", "Spanish", "Muhammad Isa García"),
                ApiTranslationResource(136, "French - Muhammad Hamidullah", "French", "Muhammad Hamidullah"),
                ApiTranslationResource(77, "Turkish - Diyanet Isleri", "Turkish", "Diyanet Isleri"),
                ApiTranslationResource(97, "Urdu - Abul A'la Maududi", "Urdu", "Abul A'la Maududi")
            )
        }
    }

    // --- External APIs Import Operations ---

    // 1. Al Quran Cloud API
    suspend fun importFromAlQuranCloud(chapterId: Int) {
        try {
            val apiCloud = AlQuranCloudApiService.create()
            
            // Fetch Uthmani text
            val uthmaniResponse = apiCloud.getSurahUthmani(chapterId)
            
            // Fetch Tafsir Muyassar
            val muyassarResponse = apiCloud.getSurahTafsirMuyassar(chapterId)
            
            // Fetch English Translation
            val englishResponse = apiCloud.getSurahEnglishTranslation(chapterId)

            val apiAyahs = uthmaniResponse.data.ayahs
            val tafsirAyahs = muyassarResponse.data.ayahs
            val englishAyahs = englishResponse.data.ayahs

            // 1. Update verses table
            val versesToInsert = apiAyahs.map { ayah ->
                val verseKey = "$chapterId:${ayah.numberInSurah}"
                // Keep existing word meanings JSON if present
                val existing = quranDao.getVerseByKey(verseKey)
                VerseEntity(
                    verseKey = verseKey,
                    chapterId = chapterId,
                    verseNumber = ayah.numberInSurah,
                    textUthmani = ayah.text,
                    wordMeaningsJson = existing?.wordMeaningsJson ?: "[]"
                )
            }
            if (versesToInsert.isNotEmpty()) {
                quranDao.insertVerses(versesToInsert)
            }

            // 2. Save Tafseer Al-Moyassar (resource ID 16)
            val tafsirsToInsert = tafsirAyahs.map { ayah ->
                val verseKey = "$chapterId:${ayah.numberInSurah}"
                TafsirEntity(
                    id = "${verseKey}_16",
                    verseKey = verseKey,
                    tafsirId = 16,
                    tafsirText = ayah.text,
                    asbabAlNuzul = getAsbabAlNuzulMock(chapterId, ayah.numberInSurah)
                )
            }
            if (tafsirsToInsert.isNotEmpty()) {
                quranDao.insertTafsirs(tafsirsToInsert)
            }

            // 3. Save English Translation (ID 131)
            val translationsToInsert = englishAyahs.map { ayah ->
                val verseKey = "$chapterId:${ayah.numberInSurah}"
                TranslationEntity(
                    id = "${verseKey}_131",
                    verseKey = verseKey,
                    translationId = 131,
                    languageName = "English",
                    translationText = ayah.text
                )
            }
            if (translationsToInsert.isNotEmpty()) {
                quranDao.insertTranslations(translationsToInsert)
            }
        } catch (e: Exception) {
            Log.e("QuranRepository", "Error importing from Al Quran Cloud: ${e.message}")
            throw e
        }
    }

    // 2. Al-Quran API (Fawaz Ahmed)
    suspend fun importFromAlQuranApi(chapterId: Int) {
        try {
            val fawazApi = FawazQuranApiService.create()

            // Fetch English Translation
            val englishResponse = fawazApi.getEnglishTranslation(chapterId)
            
            // Fetch Tafsir Jalalayn
            val jalalaynResponse = fawazApi.getTafsirJalalayn(chapterId)

            val engVerses = englishResponse.chapter
            val jalalaynVerses = jalalaynResponse.chapter

            // Save translations (ID 131)
            val translationsToInsert = engVerses.map { verse ->
                val verseKey = "$chapterId:${verse.verse}"
                TranslationEntity(
                    id = "${verseKey}_131",
                    verseKey = verseKey,
                    translationId = 131,
                    languageName = "English",
                    translationText = verse.text
                )
            }
            if (translationsToInsert.isNotEmpty()) {
                quranDao.insertTranslations(translationsToInsert)
            }

            // Save Tafseer Jalalayn (Store it as tafsirId = 17)
            val tafsirsToInsert = jalalaynVerses.map { verse ->
                val verseKey = "$chapterId:${verse.verse}"
                TafsirEntity(
                    id = "${verseKey}_17",
                    verseKey = verseKey,
                    tafsirId = 17,
                    tafsirText = verse.text,
                    asbabAlNuzul = getAsbabAlNuzulMock(chapterId, verse.verse)
                )
            }
            if (tafsirsToInsert.isNotEmpty()) {
                quranDao.insertTafsirs(tafsirsToInsert)
            }
        } catch (e: Exception) {
            Log.e("QuranRepository", "Error importing from Al-Quran API: ${e.message}")
            throw e
        }
    }

    // 3. Spa5k Tafsir API
    suspend fun importFromSpa5kTafsirApi(chapterId: Int, tafsirId: Int = 2) { // 2 is typically Al-Saddi
        try {
            val spa5kApi = Spa5kTafsirApiService.create()
            
            // Attempt to fetch from primary URL
            val response = try {
                spa5kApi.getTafsir(tafsirId, chapterId)
            } catch (e: Exception) {
                Log.e("QuranRepository", "Primary Spa5k endpoint failed, trying fallback domains...")
                val fallbackMoshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
                val adapter = fallbackMoshi.adapter(Spa5kTafsirResponse::class.java)
                
                val urls = listOf(
                    "https://api.spa5k.com/v1/tafsir/$tafsirId/$chapterId",
                    "https://tafsir-api.ryand9.dev/v1/tafsir/$tafsirId/$chapterId"
                )
                
                var successResponse: Spa5kTafsirResponse? = null
                for (urlStr in urls) {
                    try {
                        val url = java.net.URL(urlStr)
                        val connection = url.openConnection() as java.net.HttpURLConnection
                        connection.connectTimeout = 10000
                        connection.readTimeout = 10000
                        connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 10; Mobile)")
                        val jsonStr = connection.inputStream.bufferedReader().use { it.readText() }
                        successResponse = adapter.fromJson(jsonStr)
                        if (successResponse != null) break
                    } catch (ex: Exception) {
                        Log.e("QuranRepository", "Fallback URL $urlStr failed: ${ex.message}")
                    }
                }
                successResponse ?: throw e
            }

            val spa5kVerses = response.verses ?: emptyList()
            if (spa5kVerses.isNotEmpty()) {
                val tafsirsToInsert = spa5kVerses.map { verse ->
                    val verseKey = "$chapterId:${verse.verse}"
                    TafsirEntity(
                        id = "${verseKey}_$tafsirId",
                        verseKey = verseKey,
                        tafsirId = tafsirId,
                        tafsirText = verse.text,
                        asbabAlNuzul = getAsbabAlNuzulMock(chapterId, verse.verse)
                    )
                }
                quranDao.insertTafsirs(tafsirsToInsert)
            }
        } catch (e: Exception) {
            Log.e("QuranRepository", "Error importing from Spa5k Tafsir API: ${e.message}")
            throw e
        }
    }

    // Comprehensive import from all three external APIs
    suspend fun importAllFromExternalApis(chapterId: Int) {
        // Al Quran Cloud API (Quran Text, Tafseer Al-Moyassar, English Translation)
        importFromAlQuranCloud(chapterId)
        
        // Al-Quran API (Fawaz Ahmed)
        try {
            importFromAlQuranApi(chapterId)
        } catch (e: Exception) {
            Log.e("QuranRepository", "Al-Quran API Fawaz Ahmed failed: ${e.message}")
        }

        // Spa5k Tafsir API
        try {
            importFromSpa5kTafsirApi(chapterId, 2) // Tafseer Al-Saddi
        } catch (e: Exception) {
            Log.e("QuranRepository", "Spa5k Tafsir API failed: ${e.message}")
        }
    }    private fun getLanguageNameForId(id: Int): String {
        return when (id) {
            131 -> "English"
            139 -> "Spanish"
            136 -> "French"
            77 -> "Turkish"
            97 -> "Urdu"
            else -> "Translation"
        }
    }

    // High quality reasons of revelation from Imam Al-Wahidi's classic "أسباب النزول" book
    private fun getAsbabAlNuzulMock(chapterId: Int, verseNum: Int): String {
        return when (chapterId) {
            1 -> "سورة الفاتحة (مكية، وهي من أوائل ما نزل من القرآن): نزلت حين كان رسول الله ﷺ إذا برز سمع منادياً يناديه: يا محمد، فإذا سمع الصوت انطلق هارباً، فقال له ورقة بن نوفل: إذا سمعت النداء فاثبت حتى تسمع ما يقول لك، فلما برز ناداه: يا محمد، قل: بسم الله الرحمن الرحيم، الحمد لله رب العالمين... حتى فرغ من فاتحة الكتاب."
            2 -> when (verseNum) {
                1 -> "سورة البقرة (مدنية بلا خلاف، وهي أول سورة نزلت بالمدينة): نزلت أربع آيات من أولها في المؤمنين، وآيتان بعدها نزلت في الكافرين، وثلاث عشرة آية بعدها نزلت في المنافقين."
                2 -> "قوله تعالى (ذَلِكَ الْكِتَابُ لَا رَيْبَ فِيهِ): نزلت رداً على شكوك كفار قريش ومشركي العرب حول وحي الرسول وتأكيداً لإعجاز القرآن الكريم وعظمته."
                6 -> "قوله تعالى (إِنَّ الَّذِينَ كَفَرُوا سَءٌ عَلَيْهِمْ): قال الضحاك: نزلت هذه آية في أبي جهل وخمسة من أهل بيته لبيان عتادهم وإعراضهم التام عن الإيمان وعدم استجابتهم للحق."
                14 -> "قوله تعالى (وَإِذَا لَقُوا الَّذِينَ آمَنُوا قَالُوا آمَنَّأ): نزلت في عبد الله بن أبي وأصحابه المنافقين، وذلك أنهم خرجوا ذات يوم فاستقبلهم نفر من الصحابة، فأظهروا لهم الإيمان والثناء والتعظيم رياءً وكيداً وخداعاً للمؤمنين."
                21 -> "قوله تعالى (يَا أَيُّهَا النَّاسُ اعْبُدُوا رَبَّكُمْ): قال ابن عباس رضي الله عنهما: كل شيء نزل في القرآن وفيه (يا أيها الناس) فهو مكي (خطاب لأهل مكة)، وكل شيء نزل وفيه (يا أيها الذين آمنوا) فهو مدني (خطاب لأهل المدينة المنورة)."
                26 -> "قوله تعالى (إِنَّ اللَّهَ لَا يَسْتَحْيِي أَنْ يَضْرِبَ مَثَلًا): قال ابن عباس: لما ضرب الله تعالى للمنافقين مَثلَين (مثلهم كمثل الذي استوقد ناراً) و(أو كصيب من السماء)، قالوا: الله أجل وأعلى من أن يضرب هذه الأمثال، فأنزل الله الآية. وقيل: ضحكت اليهود وقالوا: ما يشبه هذا كلام الله، فنزلت تكذيباً لهم."
                44 -> "قوله تعالى (أَتَأْمُرُونَ النَّاسَ بِالْبِرِّ وَتَنسَوْنَ أَنفُسَكُمْ): نزلت في يهود أهل المدينة، كان الرجل منهم يقول لصهره ولذوي قرابته من المسلمين: اثبت على الدين الذي أنت عليه وما يأمرك به هذا الرجل (يعنون محمداً ﷺ) فإن أمره حق، وكانوا هم لا يفعلون ذلك لإصرارهم على الجحود والرياء."
                45 -> "قوله تعالى (وَاسْتَعِينُوا بِالصَّبْرِ وَالصَّلَاةِ): خطاب من الله لأهل الكتاب من اليهود، حثاً لهم على الصبر وترك حب الرئاسة والجاه، وإقامة الصلاة لإعانة نفوسهم على اتباع الحق والانقياد للرسول ﷺ."
                62 -> "قوله تعالى (إِنَّ الَّذِينَ آمَنُوا وَالَّتِينَ هَادُوا): قال سلمان الفارسي رضي الله عنه: سألت النبي ﷺ عن أصحاب لي من النصارى، وقصصت عليه صلاتهم وعبادتهم، فنزلت هذه آية لبيان أن من آمن بالله واليوم الآخر وعمل صالحاً فله أجره."
                89 -> "قوله تعالى (...يَسْتَفْتِحُونَ عَلَى الَّذِينَ كَفَرُوا): قال ابن عباس: كان يهود خيبر يقاتلون غطفان، فكلما التقوا هزمت يهود خيبر، فعاذت اليهود بهذا الدعاء: (اللهم إنا نسألك بحق النبي الأمي الذي وعدتنا أن تخرج لنا في آخر الزمان إلا نصرتنا عليهم)، فكانوا يستنصرون به فإذا التقوا هزموا غطفان، فلما جاء النبي ﷺ كفروا به بغياً وحسداً، فأنزل الله الآية."
                97 -> "قوله تعالى (قُلْ مَن كَانَ عَدُوًّا لِّجِبْرِيلَ): أقبلت اليهود إلى النبي ﷺ وسألوه عمن يأتيه بالوحي من الملائكة، فقال: جبريل، فقالوا: هو عدونا من الملائكة لأنه ينزل بالقتال والشدة وعذاب الأمم، ولو كان ميكائيل لآمنا بك، فنزلت الآية لبيان فضل جبريل وأنه نزل بالحق بأمر الله."
                99 -> "قوله تعالى (وَلَقَدْ أَنزَلْنَا إِلَيْكَ آيَاتٍ بَيِّنَاتٍ): قال ابن عباس: هذا جواب لابن صوريا (من أحبار اليهود) حيث قال لرسول الله ﷺ: يا محمد ما جئتنا بشيء نعرفه وما أنزل الله عليك من آية مبينة فنتبعك بها، فأنزل الله تعالى هذه الآية تكذيباً ورداً على جحودهم."
                109 -> "قوله تعالى (وَدَّ كَثِيرٌ مِّنْ أهْلِ الْكِتَابِ): نزلت في نفر من اليهود (منهم حيي بن أخطب وأبو ياسر بن أخطب) قالوا للمسلمين بعد وقعة أحد: ألم تروا إلى ما أصابكم لو كنتم على الحق لما هزمتم، فارجعوا إلى ديننا فهو خير لكم، فنزلت لترسيخ قلوب المؤمنين."
                113 -> "قوله تعالى (وَقَالَتِ الْيَهُودُ لَيْسَتِ النَّصَارَىٰ عَلَىٰ شَيْءٍ): نزلت في يهود أهل المدينة ونصاري أهل نجران، لما قدم وفد نجران على رسول الله ﷺ، أتاهم أحبار اليهود فتناظروا حتى ارتفعت أصواتهم وقالت كل طائفة للأخرى لستم على شيء كفراً بكتبهم وبغياً."
                else -> "نزلت آيات سورة البقرة منجمة في المدينة المنورة لتنظيم المجتمع الإسلامي الجديد، وبناء العلاقات الاجتماعية والعائلية والمالية والتشريعات الخاصة بالأمة الإسلامية."
            }
            3 -> "سورة آل عمران (مدنية): نزلت في المدينة، ويقترن نزول طليعتها بمجادلة وفد نصارى نجران لرسول الله ﷺ لبيان عقيدة التوحيد الصافية، كما نزلت بقيتها في أحداث غزوة أحد لبيان منهج الثبات والصبر والشورى وطاعة القائد."
            4 -> "سورة النساء (مدنية): نزلت لتنظيم الحقوق الأسرية وحقوق اليتامى والنساء والمواريث، وتحقيق العدالة الاجتماعية وتنظيم العلاقات الخارجية والداخلية للمجتمع المسلم بالمدينة."
            5 -> "سورة المائدة (مدنية، من أواخر ما نزل): نزلت لبيان الحلال والحرام والمواثيق والعهود وتكميل عرى العقيدة والشريعة، وفيها قوله تعالى (الْيَوْمَ أَكْمَلْتُ لَكُمْ دِينَكُمْ) التي نزلت في حجة الوداع."
            6 -> "سورة الأنعام (مكية): نزلت جملة واحدة ليلاً بمكة، وشيعها سبعون ألف ملك لبيان عقيدة التوحيد، ومواجهة حجج المشركين ومجادلتهم بالبراهين والآيات الكونية القاطعة لربوبية الله ووحدانيته."
            113 -> "سورة الفلق (مكية/مدنية): نزلت مع سورة الناس عندما تعرض النبي صلى الله عليه وسلم لمحاولة سحر لبيان سبل الوقاية والتحصن بالاستعاذة برب الفلق والالتجاء التام لحماية الله من شرور الإنس والجن الحاسدين."
            114 -> "سورة الناس (مكية/مدنية): نزلت تحصيناً للنفس الإنسانية من وساوس الشيطان الرجيم وخفايا النفس البشرية وبيان عظمة اللجوء والاستعاذة بالملك الخالق الإله."
            else -> "نزلت هذه الآية لترسيخ العقيدة والتشريع وبث السكينة والإيمان في قلوب المؤمنين وتوجيههم للخير."
        }
    }


    private var offlineData: OfflineQuranData? = null

    private fun getOfflineData(): OfflineQuranData {
        synchronized(this) {
            if (offlineData != null) return offlineData!!
            try {
                val jsonString = context.assets.open("quran_offline.json").bufferedReader().use { it.readText() }
                val adapter = moshi.adapter(OfflineQuranData::class.java)
                offlineData = adapter.fromJson(jsonString)
            } catch (e: Exception) {
                Log.e("QuranRepository", "Error reading offline JSON: ${e.message}")
            }
            return offlineData ?: OfflineQuranData(emptyList(), emptyMap())
        }
    }
}

data class OfflineQuranData(
    val chapters: List<OfflineChapter>,
    val verses: Map<String, OfflineVerse>
)

data class OfflineChapter(
    val id: Int,
    val nameArabic: String,
    val nameComplex: String,
    val translatedName: String,
    val versesCount: Int,
    val revelationPlace: String,
    val bismillahPre: Boolean
)

data class OfflineVerse(
    val uthmani: String,
    val en: String,
    val tafsir: String
)
