package com.example.data.repository

object QuranWordTranslator {
    private val translationMap = mapOf(
        // Al-Fatiha
        "name" to "اسم",
        "In (the) name" to "بِاسْمِ",
        "of Allah" to "الله",
        "Allah" to "الله",
        "the Most Gracious" to "الرَّحْمَنِ",
        "the Most Merciful" to "الرَّحِيمِ",
        "All praises and thanks" to "الْحَمْدُ",
        "All praises" to "الْحَمْدُ",
        "be to Allah" to "للهِ",
        "(is) for Allah" to "للهِ",
        "Lord" to "رَبِّ",
        "of the worlds" to "الْعَالَمِينَ",
        "the worlds" to "الْعَالَمِينَ",
        "Master" to "مَالِكِ",
        "Day" to "يَوْمِ",
        "of the Judgment" to "الدِّينِ",
        "You Alone" to "إِيَّاكَ",
        "we worship" to "نَعْبُدُ",
        "and You Alone" to "وَإِيَّاكَ",
        "we ask for help" to "نَسْتَعِينُ",
        "Guide us" to "اهْدِنَا",
        "the path" to "الصِّرَاطَ",
        "the straight" to "الْمُسْتَقِيمَ",
        "path" to "صِرَاطَ",
        "of those" to "الَّذِينَ",
        "You have bestowed (Your) Favors" to "أَنْعَمْتَ",
        "on them" to "عَلَيْهِمْ",
        "not (of)" to "غَيْرِ",
        "those who earned (Your) wrath" to "الْمَغْضُوبِ",
        "and not" to "وَلَا",
        "those who go astray" to "الضَّالِّينَ",

        // Al-Ikhlas
        "Say" to "قُلْ",
        "He" to "هُوَ",
        "one" to "أَحَدٌ",
        "the Eternal" to "الصَّمَدُ",
        "Absolute" to "الصَّمَدُ",
        "He begets" to "يَلِدْ",
        "and not" to "وَلَمْ",
        "He is begotten" to "يُولَدْ",
        "there is" to "يَكُنْ",
        "to Him" to "لَهُ",
        "equivalent" to "كُفُوًا",
        "anyone" to "أَحَدٌ",

        // Al-Falaq
        "I seek refuge" to "أَعُوذُ",
        "in (the) Lord" to "بِرَبِّ",
        "of the daybreak" to "الْفَلَقِ",
        "From (the) evil" to "من شَرِّ",
        "evil" to "شَرِّ",
        "of what" to "مَا",
        "He created" to "خَلَقَ",
        "and from" to "وَمِنْ",
        "darkness" to "غَاسِقٍ",
        "when" to "إِذَا",
        "it spreads" to "وَقَبَ",
        "of those who blow" to "النَّفَّاثَاتِ",
        "in" to "فِي",
        "the knots" to "الْعُقَدِ",
        "of an envier" to "حَاسِدٍ",
        "he envies" to "حَسَدَ",

        // An-Nas
        "of the mankind" to "النَّاسِ",
        "The King" to "مَلِكِ",
        "The God" to "إِلَهِ",
        "of the whisperer" to "الْوَسْوَاسِ",
        "the withdrawing" to "الْخَنَّاسِ",
        "The one who" to "الَّذِي",
        "whispers" to "يُوَسْوِسُ",
        "breasts" to "صُدُورِ",
        "the jinn" to "الْجِنَّةِ",
        "and the men" to "وَالنَّاسِ",

        // General / Common words
        "book" to "كتاب",
        "no" to "لا",
        "doubt" to "ريب",
        "guidance" to "هدى",
        "for those who fear" to "للمتقين",
        "believe" to "يؤمنون",
        "unseen" to "الغيب",
        "establish" to "يقيمون",
        "prayer" to "الصلاة",
        "we provided them" to "رزقناهم",
        "spend" to "ينفقون",
        "revealed" to "أنزل",
        "before you" to "من قبلك",
        "Hereafter" to "الآخرة",
        "they are certain" to "يوقنون",
        "successful" to "المفلحون",
        "disbelieved" to "كفروا",
        "same" to "سواء",
        "warn them" to "أنذرتهم",
        "warned them" to "أنذرتهم",
        "seal" to "ختم",
        "hearts" to "قلوب",
        "hearing" to "سمع",
        "eyes" to "أبصار",
        "great" to "عظيم",
        "punishment" to "عذاب",
        "people" to "الناس",
        "say" to "يقول",
        "believers" to "مؤمنين",
        "deceive" to "يخادعون",
        "themselves" to "أنفسهم",
        "perceive" to "يشعرون",
        "disease" to "مرض",
        "painful" to "أليم",
        "lie" to "يكذبون",
        "earth" to "الأرض",
        "peacemakers" to "مصلحون",
        "fools" to "سفهاء",
        "know" to "يعلمون",
        "meet" to "لقوا",
        "devils" to "شياطين",
        "with you" to "معكم",
        "mocking" to "مستهزؤون",
        "guidance" to "الهدى",
        "merchants" to "تجارة",
        "guided" to "مهتدين",
        "fire" to "نار",
        "light" to "نور",
        "deaf" to "صم",
        "dumb" to "بكم",
        "blind" to "عمي",
        "return" to "يرجعون",
        "rain" to "صيب",
        "sky" to "السماء",
        "thunder" to "رعد",
        "lightning" to "برق",
        "death" to "الموت",
        "fear" to "حذر",
        "knowing" to "عليم",
        "hearing" to "سميع",
        "everything" to "كل شيء",
        "capable" to "قدير",
        "worship" to "اعبدوا",
        "created you" to "خلقكم",
        "made" to "جعل",
        "water" to "ماء",
        "fruits" to "ثمرات",
        "partners" to "أنداداً",
        "slave" to "عبدنا",
        "surah" to "سورة",
        "witnesses" to "شهداء",
        "truthful" to "صادقين",
        "guard" to "اتقوا",
        "stones" to "الحجارة",
        "prepared" to "أعدت",
        "disbelievers" to "كافرين",
        "give glad tidings" to "بشر",
        "righteous" to "صالحات",
        "gardens" to "جنات",
        "rivers" to "الأنهار",
        "pure" to "مطهرة",
        "abide" to "خالدون",
        "mosquito" to "بعوضة",
        "covenant" to "عهد",
        "grace" to "فضل",
        "mercy" to "رحمة",
        "losers" to "خاسرون"
    )

    fun translate(english: String, arabicWord: String? = null): String {
        if (!arabicWord.isNullOrBlank()) {
            return QuranArabicSynonyms.getSynonym(arabicWord)
        }
        val cleaned = english.trim().removeSurrounding("(", ")").removeSurrounding("[", "]")
        
        // Match exact word from our rich translation dictionary
        val match = translationMap[cleaned] ?: translationMap[cleaned.lowercase()]
        if (match != null) return match

        // Search for partial matches
        for ((key, value) in translationMap) {
            if (cleaned.equals(key, ignoreCase = true)) {
                return value
            }
        }

        // Heuristic replacement
        var result = cleaned
            .replace("the Most Merciful", "الرحيم")
            .replace("the Most Gracious", "الرحمن")
            .replace("the ", "")
            .replace("In (the) name", "باسم")
            .replace("of Allah", "الله")
            .replace("to Allah", "لله")
            .replace("Allah", "الله")
            .replace("all praises", "الحمد")
            .replace("Lord", "رب")
            .replace("worlds", "العالمين")
            .replace("Master", "مالك")
            .replace("Day", "يوم")
            .replace("Judgment", "الدين")
            .replace("You Alone", "إياك")
            .replace("we worship", "نعبد")
            .replace("ask for help", "نستعين")
            .replace("Guide us", "اهدنا")
            .replace("path", "الصراط")
            .replace("straight", "المستقيم")
            .replace("those who", "الذين")
            .replace("earned wrath", "المغضوب")
            .replace("go astray", "الضالين")
            .replace("and ", "و")
            .replace("from ", "من ")
            .replace("to ", "إلى ")
            .replace("in ", "في ")
            .replace("with ", "بـ")
            .replace("not ", "لا ")
            .replace("say", "قل")
            .replace("He ", "هو ")
            .replace("one", "أحد")
            .replace("Eternal", "الصمد")
            .replace("begets", "يلد")
            .replace("begotten", "يولد")
            .replace("equivalent", "كفواً")
            .replace("any", "أحد")
            .replace("anyone", "أحد")

        // If it still contains English, fall back gracefully to the Arabic word itself!
        val hasEnglish = result.any { it in 'a'..'z' || it in 'A'..'Z' }
        if (hasEnglish && !arabicWord.isNullOrBlank()) {
            // Remove any digits or punctuation from the Arabic word itself
            val cleanArabicWord = arabicWord.replace(Regex("[0-9\\u0660-\\u0669\\u06F0-\\u06F9\\uFD3E\\uFD3F\\s\\p{Punct}]"), "")
            if (cleanArabicWord.isNotEmpty()) {
                return "معنى: $cleanArabicWord"
            }
        }
        return result
    }
}
