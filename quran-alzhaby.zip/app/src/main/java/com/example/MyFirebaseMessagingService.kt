package com.example

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class MyFirebaseMessagingService : FirebaseMessagingService() {

    companion object {
        var onNotificationReceived: ((String?, String?, String?) -> Unit)? = null
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        Log.d("FCM_SERVICE", "Message received from: ${remoteMessage.from}")

        // 1. Extract notification info
        var title = remoteMessage.notification?.title
        var body = remoteMessage.notification?.body

        // If notification block is null, fallback to data payload
        if (title.isNullOrBlank()) {
            title = remoteMessage.data["title"]
        }
        if (body.isNullOrBlank()) {
            body = remoteMessage.data["body"]
        }

        val url = remoteMessage.data["url"] ?: remoteMessage.data["link"] ?: remoteMessage.data["uri"]

        Log.d("FCM_SERVICE", "Title: $title, Body: $body, URL: $url")

        // 2. Save to SharedPreferences so it can be read inside the Settings Dialog
        if (!title.isNullOrBlank() || !body.isNullOrBlank()) {
            val prefs = getSharedPreferences("quran_prefs", Context.MODE_PRIVATE)
            prefs.edit().apply {
                putString("latest_notification_title", title ?: "")
                putString("latest_notification_body", body ?: "")
                putString("latest_notification_url", url ?: "")
                apply()
            }

            // Invoke live companion callback on main thread
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                onNotificationReceived?.invoke(title, body, url)
            }
        }

        // 3. Show System Notification
        if (!title.isNullOrBlank() || !body.isNullOrBlank()) {
            sendNotification(title ?: "تنبيه جديد", body ?: "", url)
        }
    }

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.d("FCM_SERVICE", "Refreshed FCM token: $token")
    }

    private fun sendNotification(title: String, messageBody: String, url: String?) {
        val channelId = "quran_fcm_channel"
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "إشعارات تطبيق القرآن الكريم",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "قناة إرسال الإشعارات والتنبيهات الدينية الهامة"
                enableVibration(true)
            }
            notificationManager.createNotificationChannel(channel)
        }

        val intent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra("url", url)
            putExtra("title", title)
            putExtra("body", messageBody)
        }

        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notificationBuilder = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(messageBody)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)

        notificationManager.notify(System.currentTimeMillis().toInt(), notificationBuilder.build())
    }
}
