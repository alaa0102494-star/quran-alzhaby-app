import urllib.request
import json
import os

def build_offline_data():
    print("Starting offline assets builder...")
    
    # 1. Download Surah list
    print("Downloading chapters/surahs list...")
    chapters_url = "https://api.alquran.cloud/v1/surah"
    urllib.request.urlretrieve(chapters_url, "chapters.json")
    
    # 2. Download Uthmani Text
    print("Downloading Uthmani text...")
    uthmani_url = "https://api.alquran.cloud/v1/quran/quran-uthmani"
    urllib.request.urlretrieve(uthmani_url, "uthmani.json")
    
    # 3. Download English translation (Sahih International)
    print("Downloading English translation...")
    en_url = "https://api.alquran.cloud/v1/quran/en.sahih"
    urllib.request.urlretrieve(en_url, "en.json")
    
    # 4. Download Tafsir Al-Muyassar
    print("Downloading Tafsir Al-Muyassar...")
    ar_url = "https://api.alquran.cloud/v1/quran/ar.muyassar"
    urllib.request.urlretrieve(ar_url, "ar.json")
    
    print("Loading downloaded files into memory...")
    with open("chapters.json", "r", encoding="utf-8") as f:
        chapters_data = json.load(f)["data"]
        
    with open("uthmani.json", "r", encoding="utf-8") as f:
        uthmani_data = json.load(f)["data"]["surahs"]
        
    with open("en.json", "r", encoding="utf-8") as f:
        en_data = json.load(f)["data"]["surahs"]
        
    with open("ar.json", "r", encoding="utf-8") as f:
        ar_data = json.load(f)["data"]["surahs"]
        
    print("Merging datasets...")
    
    # Standardize chapter fields
    chapters = []
    for ch in chapters_data:
        # Bismillah pre logic (all surahs except Al-Fatihah (1) and Al-Tawbah (9) have pre bismillah in AlQuran Cloud)
        bismillah_pre = True
        if ch["number"] == 1 or ch["number"] == 9:
            bismillah_pre = False
            
        chapters.append({
            "id": ch["number"],
            "nameArabic": ch["name"].replace("سُورَةُ ", "").strip(),
            "nameComplex": ch["englishName"],
            "translatedName": ch["englishNameTranslation"],
            "versesCount": ch["numberOfAyahs"],
            "revelationPlace": "makkah" if ch["revelationType"].lower() == "meccan" else "madinah",
            "bismillahPre": bismillah_pre
        })
        
    # Map of verseKey -> details
    verses = {}
    
    for s_idx in range(114):
        surah_uthmani = uthmani_data[s_idx]
        surah_en = en_data[s_idx]
        surah_ar = ar_data[s_idx]
        
        chapter_id = surah_uthmani["number"]
        
        for v_idx in range(len(surah_uthmani["ayahs"])):
            v_uthmani = surah_uthmani["ayahs"][v_idx]
            v_en = surah_en["ayahs"][v_idx]
            v_ar = surah_ar["ayahs"][v_idx]
            
            verse_num = v_uthmani["numberInSurah"]
            verse_key = f"{chapter_id}:{verse_num}"
            
            text_uthmani = v_uthmani["text"]
            
            # Strip prefix "بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ" if it is included at start of verse 1 (except Al-Fatihah 1:1)
            # AlQuran Cloud sometimes prepends Bismillah to verse 1 of each Surah
            bismillah_prefix = "بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ "
            if chapter_id != 1 and verse_num == 1 and text_uthmani.startswith(bismillah_prefix):
                text_uthmani = text_uthmani[len(bismillah_prefix):]
                
            verses[verse_key] = {
                "uthmani": text_uthmani,
                "en": v_en["text"],
                "tafsir": v_ar["text"]
            }
            
    output_data = {
        "chapters": chapters,
        "verses": verses
    }
    
    print("Writing merged data to assets/quran_offline.json...")
    with open("app/src/main/assets/quran_offline.json", "w", encoding="utf-8") as f:
        json.dump(output_data, f, ensure_ascii=False)
        
    print("Success! Merged file size is:", os.path.getsize("app/src/main/assets/quran_offline.json") / (1024*1024), "MB")
    
    # Cleanup temp files
    print("Cleaning up temp files...")
    for temp_file in ["chapters.json", "uthmani.json", "en.json", "ar.json", "test_en.json", "test_ar.json", "test_chapters.json", "test_uthmani.json"]:
        if os.path.exists(temp_file):
            os.remove(temp_file)
            
    print("Finished successfully.")

if __name__ == "__main__":
    build_offline_data()
