package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.db.AppDatabase
import com.example.data.db.TranslationEntity
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  private lateinit var db: AppDatabase

  @Before
  fun createDb() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
        .allowMainThreadQueries()
        .build()
  }

  @After
  fun closeDb() {
    db.close()
  }

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("القرآن الكريم الذهبي", appName)
  }

  @Test
  fun `test translations query fetches correct chapter only`() = runBlocking {
    val dao = db.quranDao()
    
    // Insert translations for various chapters
    val t1 = TranslationEntity("1:1_131", "1:1", 131, "english", "In the name of God")
    val t2 = TranslationEntity("1:2_131", "1:2", 131, "english", "Praise be to God")
    val t3 = TranslationEntity("10:1_131", "10:1", 131, "english", "Alif Lam Ra")
    val t4 = TranslationEntity("11:1_131", "11:1", 131, "english", "Alif Lam Ra Book")
    
    dao.insertTranslations(listOf(t1, t2, t3, t4))
    
    // Query translations for chapter 1
    val chapter1Trans = dao.getTranslationsForChapter(1, 131).first()
    assertEquals(2, chapter1Trans.size)
    assertEquals("1:1", chapter1Trans[0].verseKey)
    assertEquals("1:2", chapter1Trans[1].verseKey)

    // Query translations for chapter 10
    val chapter10Trans = dao.getTranslationsForChapter(10, 131).first()
    assertEquals(1, chapter10Trans.size)
    assertEquals("10:1", chapter10Trans[0].verseKey)
  }

  @Test
  fun `test real api translation call`() = runBlocking {
    try {
      val api = com.example.data.api.QuranApiService.create()
      val response = api.getTranslation(85, 1)
      println("API Response: ${response.translations.size} items, first text: ${response.translations.firstOrNull()?.text}")
      assert(response.translations.isNotEmpty())
    } catch (e: Exception) {
      println("API Error: ${e.message}")
      e.printStackTrace()
      throw e
    }
  }
}
